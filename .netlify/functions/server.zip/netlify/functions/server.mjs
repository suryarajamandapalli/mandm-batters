
import {createRequire as ___nfyCreateRequire} from "module";
import {fileURLToPath as ___nfyFileURLToPath} from "url";
import {dirname as ___nfyPathDirname} from "path";
let __filename=___nfyFileURLToPath(import.meta.url);
let __dirname=___nfyPathDirname(___nfyFileURLToPath(import.meta.url));
let require=___nfyCreateRequire(import.meta.url);

var __defProp = Object.defineProperty;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __esm = (fn, res) => function __init() {
  return fn && (res = (0, fn[__getOwnPropNames(fn)[0]])(fn = 0)), res;
};
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};

// dist/server/assets/_tanstack-start-manifest_v-D55eW8K9.js
var tanstack_start_manifest_v_D55eW8K9_exports = {};
__export(tanstack_start_manifest_v_D55eW8K9_exports, {
  tsrStartManifest: () => tsrStartManifest
});
var tsrStartManifest;
var init_tanstack_start_manifest_v_D55eW8K9 = __esm({
  "dist/server/assets/_tanstack-start-manifest_v-D55eW8K9.js"() {
    "use strict";
    tsrStartManifest = () => ({ routes: { __root__: { filePath: "C:/Users/Sai Kiran/OneDrive/Desktop/renuka-s-batter-hub-main/src/routes/__root.tsx", children: ["/", "/admin", "/checkout", "/delivery", "/order-success/$id"], assets: void 0, preloads: ["/assets/index-Jp-QfVm4.js"] }, "/": { filePath: "C:/Users/Sai Kiran/OneDrive/Desktop/renuka-s-batter-hub-main/src/routes/index.tsx", children: void 0, assets: void 0, preloads: ["/assets/index-BIJWjb58.js", "/assets/cart-Bp3DIAsJ.js", "/assets/Logo-C6zoR8PZ.js", "/assets/x-CKl43ya5.js", "/assets/menu-CLSmKP2D.js", "/assets/proxy-uIm-inZK.js", "/assets/imagekit-BqgPLIN_.js", "/assets/createLucideIcon-DL8kyhJF.js", "/assets/arrow-right-DbBlA9Bc.js", "/assets/products-CYBeSHLG.js", "/assets/plus-WlzkW7zU.js", "/assets/clock-bA2QMw_m.js", "/assets/youtube-ye2yXowb.js", "/assets/phone-Ciz6v_i6.js", "/assets/map-pin-eV51UK8V.js", "/assets/message-circle-BbOaLd7y.js", "/assets/utils-BQHNewu7.js"] }, "/admin": { filePath: "C:/Users/Sai Kiran/OneDrive/Desktop/renuka-s-batter-hub-main/src/routes/admin.tsx", children: ["/admin/cms", "/admin/dashboard", "/admin/delivery", "/admin/enquiries", "/admin/login", "/admin/orders", "/admin/payments", "/admin/products"], assets: void 0, preloads: ["/assets/admin-e_i5oWPN.js", "/assets/Logo-C6zoR8PZ.js", "/assets/index-BBCe16lP.js", "/assets/utils-BQHNewu7.js", "/assets/x-CKl43ya5.js", "/assets/adminFilter-C1vTlHQ1.js", "/assets/calendar-q3Q2-nkz.js", "/assets/menu-CLSmKP2D.js", "/assets/createLucideIcon-DL8kyhJF.js", "/assets/shopping-cart-ZkbJ_XH3.js", "/assets/package-BiAO_g5Y.js", "/assets/message-square-BeC5Otof.js", "/assets/log-out-BeztzJOd.js", "/assets/imagekit-BqgPLIN_.js", "/assets/index-CLLUh7Nh.js", "/assets/format-BkHSUBJ4.js"] }, "/checkout": { filePath: "C:/Users/Sai Kiran/OneDrive/Desktop/renuka-s-batter-hub-main/src/routes/checkout.tsx", children: void 0, assets: void 0, preloads: ["/assets/checkout-DgOGILg-.js", "/assets/cart-Bp3DIAsJ.js", "/assets/orders-BOXSU-Of.js", "/assets/createLucideIcon-DL8kyhJF.js", "/assets/play-NnSPPFXI.js", "/assets/trash-2-Bfp6MJUH.js", "/assets/imagekit-BqgPLIN_.js", "/assets/map-pin-eV51UK8V.js", "/assets/loader-circle-DBPfGOhE.js", "/assets/proxy-uIm-inZK.js", "/assets/circle-check-CVmpJbVg.js"] }, "/delivery": { filePath: "C:/Users/Sai Kiran/OneDrive/Desktop/renuka-s-batter-hub-main/src/routes/delivery.tsx", children: ["/delivery/login", "/delivery/"], assets: void 0, preloads: ["/assets/delivery-BuNBoEnS.js", "/assets/Logo-C6zoR8PZ.js", "/assets/log-out-BeztzJOd.js", "/assets/imagekit-BqgPLIN_.js", "/assets/utils-BQHNewu7.js", "/assets/createLucideIcon-DL8kyhJF.js"] }, "/admin/cms": { filePath: "C:/Users/Sai Kiran/OneDrive/Desktop/renuka-s-batter-hub-main/src/routes/admin/cms.tsx", children: void 0, assets: void 0, preloads: ["/assets/cms-DUjP2ubc.js", "/assets/ErrorBoundary-BNsQHScl.js", "/assets/MediaUpload-D2gd2vyz.js", "/assets/loader-circle-DBPfGOhE.js", "/assets/save-BbSjCwfc.js", "/assets/trash-2-Bfp6MJUH.js", "/assets/plus-WlzkW7zU.js", "/assets/youtube-ye2yXowb.js", "/assets/phone-Ciz6v_i6.js", "/assets/map-pin-eV51UK8V.js", "/assets/message-circle-BbOaLd7y.js", "/assets/circle-check-big-DAsIqVxN.js"] }, "/admin/dashboard": { filePath: "C:/Users/Sai Kiran/OneDrive/Desktop/renuka-s-batter-hub-main/src/routes/admin/dashboard.tsx", children: void 0, assets: void 0, preloads: ["/assets/dashboard-DuAnMVyT.js", "/assets/orders-BOXSU-Of.js", "/assets/products-CYBeSHLG.js", "/assets/card-C_q0sONs.js", "/assets/select-B_dYak7c.js", "/assets/ErrorBoundary-BNsQHScl.js", "/assets/parseISO-GdSY9j1A.js", "/assets/circle-check-big-DAsIqVxN.js", "/assets/clock-bA2QMw_m.js", "/assets/wallet-DcPgHTKk.js", "/assets/trending-up-C8Fl_W79.js"] }, "/admin/delivery": { filePath: "C:/Users/Sai Kiran/OneDrive/Desktop/renuka-s-batter-hub-main/src/routes/admin/delivery.tsx", children: void 0, assets: void 0, preloads: ["/assets/delivery-rdEwzp1x.js", "/assets/deliveryPartners-CJ5UR88U.js", "/assets/ErrorBoundary-BNsQHScl.js", "/assets/MediaUpload-D2gd2vyz.js", "/assets/plus-WlzkW7zU.js", "/assets/trash-2-Bfp6MJUH.js", "/assets/phone-Ciz6v_i6.js", "/assets/map-pin-eV51UK8V.js", "/assets/loader-circle-DBPfGOhE.js", "/assets/circle-check-big-DAsIqVxN.js"] }, "/admin/enquiries": { filePath: "C:/Users/Sai Kiran/OneDrive/Desktop/renuka-s-batter-hub-main/src/routes/admin/enquiries.tsx", children: void 0, assets: void 0, preloads: ["/assets/enquiries-CLLR3bwr.js", "/assets/ErrorBoundary-BNsQHScl.js", "/assets/loader-circle-DBPfGOhE.js", "/assets/user-DIEprxXW.js", "/assets/phone-Ciz6v_i6.js", "/assets/parseISO-GdSY9j1A.js", "/assets/trash-2-Bfp6MJUH.js"] }, "/admin/login": { filePath: "C:/Users/Sai Kiran/OneDrive/Desktop/renuka-s-batter-hub-main/src/routes/admin/login.tsx", children: void 0, assets: void 0, preloads: ["/assets/login-mTh4HTIe.js", "/assets/loader-circle-DBPfGOhE.js"] }, "/admin/orders": { filePath: "C:/Users/Sai Kiran/OneDrive/Desktop/renuka-s-batter-hub-main/src/routes/admin/orders.tsx", children: void 0, assets: void 0, preloads: ["/assets/orders-AKPlefv5.js", "/assets/orders-BOXSU-Of.js", "/assets/deliveryPartners-CJ5UR88U.js", "/assets/whatsapp-Dnm8FDR6.js", "/assets/select-B_dYak7c.js", "/assets/ErrorBoundary-BNsQHScl.js", "/assets/loader-circle-DBPfGOhE.js", "/assets/circle-check-big-DAsIqVxN.js", "/assets/square-pen-CJliFUgO.js", "/assets/phone-Ciz6v_i6.js", "/assets/message-circle-BbOaLd7y.js", "/assets/map-pin-eV51UK8V.js", "/assets/wallet-DcPgHTKk.js", "/assets/user-DIEprxXW.js", "/assets/play-NnSPPFXI.js", "/assets/save-BbSjCwfc.js"] }, "/admin/payments": { filePath: "C:/Users/Sai Kiran/OneDrive/Desktop/renuka-s-batter-hub-main/src/routes/admin/payments.tsx", children: void 0, assets: void 0, preloads: ["/assets/payments-AIaIhXAX.js", "/assets/orders-BOXSU-Of.js", "/assets/card-C_q0sONs.js", "/assets/ErrorBoundary-BNsQHScl.js", "/assets/circle-check-CVmpJbVg.js", "/assets/wallet-DcPgHTKk.js"] }, "/admin/products": { filePath: "C:/Users/Sai Kiran/OneDrive/Desktop/renuka-s-batter-hub-main/src/routes/admin/products.tsx", children: void 0, assets: void 0, preloads: ["/assets/products-BoYCOOeE.js", "/assets/products-CYBeSHLG.js", "/assets/ErrorBoundary-BNsQHScl.js", "/assets/MediaUpload-D2gd2vyz.js", "/assets/loader-circle-DBPfGOhE.js", "/assets/trash-2-Bfp6MJUH.js", "/assets/plus-WlzkW7zU.js", "/assets/save-BbSjCwfc.js", "/assets/square-pen-CJliFUgO.js", "/assets/circle-check-big-DAsIqVxN.js"] }, "/delivery/login": { filePath: "C:/Users/Sai Kiran/OneDrive/Desktop/renuka-s-batter-hub-main/src/routes/delivery/login.tsx", children: void 0, assets: void 0, preloads: ["/assets/login-C-xyPQak.js", "/assets/deliveryPartners-CJ5UR88U.js"] }, "/order-success/$id": { filePath: "C:/Users/Sai Kiran/OneDrive/Desktop/renuka-s-batter-hub-main/src/routes/order-success.$id.tsx", children: void 0, assets: void 0, preloads: ["/assets/order-success._id-CnyjHYaT.js", "/assets/proxy-uIm-inZK.js", "/assets/circle-check-CVmpJbVg.js", "/assets/phone-Ciz6v_i6.js", "/assets/arrow-right-DbBlA9Bc.js", "/assets/createLucideIcon-DL8kyhJF.js"] }, "/delivery/": { filePath: "C:/Users/Sai Kiran/OneDrive/Desktop/renuka-s-batter-hub-main/src/routes/delivery/index.tsx", children: void 0, assets: void 0, preloads: ["/assets/index-Cu0f3uht.js", "/assets/orders-BOXSU-Of.js", "/assets/whatsapp-Dnm8FDR6.js", "/assets/ErrorBoundary-BNsQHScl.js", "/assets/format-BkHSUBJ4.js", "/assets/loader-circle-DBPfGOhE.js", "/assets/calendar-q3Q2-nkz.js", "/assets/package-BiAO_g5Y.js", "/assets/circle-check-CVmpJbVg.js", "/assets/trending-up-C8Fl_W79.js", "/assets/wallet-DcPgHTKk.js", "/assets/map-pin-eV51UK8V.js", "/assets/phone-Ciz6v_i6.js", "/assets/message-circle-BbOaLd7y.js"] } }, clientEntry: "/assets/index-Jp-QfVm4.js" });
  }
});

// dist/server/assets/imagekit-78z04_ax.js
import { upload, buildSrc } from "@imagekit/javascript";
var IMAGEKIT_PUBLIC_KEY, IMAGEKIT_URL_ENDPOINT, getImageKitUrl, uploadFile;
var init_imagekit_78z04_ax = __esm({
  "dist/server/assets/imagekit-78z04_ax.js"() {
    "use strict";
    IMAGEKIT_PUBLIC_KEY = "public_HfPCnEfXY7ev27BPnAxffR7pSFk=";
    IMAGEKIT_URL_ENDPOINT = "https://ik.imagekit.io/h2batters";
    getImageKitUrl = (path, width, height) => {
      if (!path) return "";
      if (path.startsWith("http") && !path.includes("ik.imagekit.io")) return path;
      const cleanPath = path.replace(IMAGEKIT_URL_ENDPOINT, "");
      const transformation = [{ quality: "80" }];
      if (width) transformation.push({ width: String(width) });
      return buildSrc({
        urlEndpoint: IMAGEKIT_URL_ENDPOINT,
        src: cleanPath,
        transformation
      });
    };
    uploadFile = async (file, folder = "general") => {
      const fileName = file.name || `upload_${Date.now()}`;
      console.log(`[ImageKit] Starting upload for ${fileName}...`);
      try {
        console.log("[ImageKit] Fetching auth parameters from /api/imagekit-auth...");
        const response = await fetch("/api/imagekit-auth");
        if (!response.ok) {
          const errorData = await response.json().catch(() => ({}));
          throw new Error(errorData.error || `Auth server returned ${response.status}`);
        }
        const authData = await response.json();
        console.log("[ImageKit] Auth Response Received:", {
          token: authData.token ? "PRESENT" : "MISSING",
          signature: authData.signature ? "PRESENT" : "MISSING",
          expire: authData.expire ? "PRESENT" : "MISSING"
        });
        if (!authData.token || !authData.signature || !authData.expire) {
          throw new Error("Invalid authentication data received from server");
        }
        console.log("[ImageKit] Uploading to ImageKit...");
        const result = await upload({
          file,
          fileName,
          publicKey: IMAGEKIT_PUBLIC_KEY,
          signature: authData.signature,
          expire: authData.expire,
          token: authData.token,
          folder,
          useUniqueFileName: true
        });
        console.log("[ImageKit] Upload successful:", result.url);
        return {
          ...result,
          secure_url: result.url
        };
      } catch (error) {
        console.error("[ImageKit] Upload failed:", error.message);
        throw new Error(`Upload failed: ${error.message}`);
      }
    };
  }
});

// dist/server/assets/utils-H80jjgLf.js
import { clsx } from "clsx";
import { twMerge } from "tailwind-merge";
function cn(...inputs) {
  return twMerge(clsx(inputs));
}
var init_utils_H80jjgLf = __esm({
  "dist/server/assets/utils-H80jjgLf.js"() {
    "use strict";
  }
});

// dist/server/assets/Logo-DpDS75JT.js
import { jsx } from "react/jsx-runtime";
import { useState, useEffect, useMemo } from "react";
function Logo({ className, variant = "light", size = "md" }) {
  const { logoUrl: storeLogoUrl } = useSiteSettings();
  const [error, setError] = useState(false);
  useEffect(() => {
    setError(false);
  }, [storeLogoUrl]);
  const sizes = {
    sm: "size-8",
    md: "size-10",
    lg: "size-16",
    xl: "size-24"
  };
  const logoUrl = useMemo(() => {
    if (!storeLogoUrl) return null;
    return getImageKitUrl(storeLogoUrl, size === "sm" ? 100 : 300) + `?v=${(/* @__PURE__ */ new Date()).setMinutes(0, 0, 0)}`;
  }, [storeLogoUrl, size]);
  if (error || !logoUrl) {
    return /* @__PURE__ */ jsx("div", { className: cn(
      "rounded-xl bg-orange grid place-items-center font-display font-black text-navy shadow-lg shadow-orange/20 select-none",
      sizes[size],
      size === "sm" ? "text-xs" : size === "md" ? "text-lg" : "text-3xl",
      className
    ), children: "H2" });
  }
  return /* @__PURE__ */ jsx("div", { className: cn("relative group shrink-0", sizes[size], className), children: /* @__PURE__ */ jsx(
    "img",
    {
      src: logoUrl,
      alt: "H2 Batters",
      className: "w-full h-full object-contain drop-shadow-md group-hover:scale-105 transition-transform duration-300",
      onError: () => setError(true)
    }
  ) });
}
var init_Logo_DpDS75JT = __esm({
  "dist/server/assets/Logo-DpDS75JT.js"() {
    "use strict";
    init_router_B40ruYtd();
    init_imagekit_78z04_ax();
    init_utils_H80jjgLf();
  }
});

// dist/server/assets/delivery-C_y7eiYc.js
var delivery_C_y7eiYc_exports = {};
__export(delivery_C_y7eiYc_exports, {
  component: () => DeliveryLayout
});
import { jsxs, jsx as jsx2 } from "react/jsx-runtime";
import { useRouter, Outlet } from "@tanstack/react-router";
import { LogOut } from "lucide-react";
import "sonner";
import "react";
import "zustand";
import "firebase/database";
import "firebase/app";
import "firebase/auth";
import "firebase/firestore";
import "firebase/analytics";
import "zustand/middleware";
import "@imagekit/javascript";
import "clsx";
import "tailwind-merge";
function DeliveryLayout() {
  const currentPartner = useDeliveryAuth((s) => s.currentPartner);
  const logout = useDeliveryAuth((s) => s.logout);
  const router2 = useRouter();
  const handleLogout = () => {
    logout();
    router2.navigate({
      to: "/delivery/login"
    });
  };
  return /* @__PURE__ */ jsxs("div", { className: "min-h-[100svh] bg-secondary/30 flex flex-col", children: [
    currentPartner && /* @__PURE__ */ jsx2("header", { className: "bg-navy text-white sticky top-0 z-10 shadow-sm", children: /* @__PURE__ */ jsxs("div", { className: "container-px mx-auto max-w-3xl h-16 flex items-center justify-between", children: [
      /* @__PURE__ */ jsxs("div", { className: "flex items-center gap-3", children: [
        /* @__PURE__ */ jsx2(Logo, { size: "sm" }),
        /* @__PURE__ */ jsxs("span", { className: "font-display font-black tracking-tight", children: [
          "Partner ",
          /* @__PURE__ */ jsx2("span", { className: "text-orange", children: "HUB" })
        ] })
      ] }),
      /* @__PURE__ */ jsxs("div", { className: "flex items-center gap-4 text-sm", children: [
        /* @__PURE__ */ jsxs("div", { className: "flex items-center gap-2", children: [
          /* @__PURE__ */ jsx2("img", { src: currentPartner.image, alt: "", className: "size-8 rounded-full border border-white/20 object-cover" }),
          /* @__PURE__ */ jsx2("span", { className: "hidden sm:inline font-medium", children: currentPartner.name })
        ] }),
        /* @__PURE__ */ jsx2("button", { onClick: handleLogout, className: "p-2 hover:bg-white/10 rounded-full transition-colors", "aria-label": "Logout", children: /* @__PURE__ */ jsx2(LogOut, { className: "size-4" }) })
      ] })
    ] }) }),
    /* @__PURE__ */ jsx2("main", { className: "flex-1 w-full max-w-3xl mx-auto container-px py-6", children: /* @__PURE__ */ jsx2(Outlet, {}) })
  ] });
}
var init_delivery_C_y7eiYc = __esm({
  "dist/server/assets/delivery-C_y7eiYc.js"() {
    "use strict";
    init_router_B40ruYtd();
    init_Logo_DpDS75JT();
  }
});

// dist/server/assets/cart-CKZOh9VL.js
import { create } from "zustand";
import { persist } from "zustand/middleware";
var useCart, lineTotal, cartTotal, cartCount, cartWeight;
var init_cart_CKZOh9VL = __esm({
  "dist/server/assets/cart-CKZOh9VL.js"() {
    "use strict";
    useCart = create()(
      persist(
        (set5) => ({
          items: [],
          isOpen: false,
          open: () => set5({ isOpen: true }),
          close: () => set5({ isOpen: false }),
          toggle: () => set5((s) => ({ isOpen: !s.isOpen })),
          addKg: (p) => set5((s) => {
            const existing = s.items.find((i) => i.productId === p.id);
            if (existing) {
              return {
                items: s.items.map(
                  (i) => i.productId === p.id ? { ...i, kg: i.kg + 1 } : i
                )
              };
            }
            return {
              items: [
                ...s.items,
                {
                  productId: p.id,
                  name: p.name,
                  image: p.image,
                  pricePerKg: p.pricePerKg,
                  pricePerHalfKg: p.pricePerHalfKg,
                  kg: 1,
                  halfKg: 0
                }
              ]
            };
          }),
          addHalfKg: (p) => set5((s) => {
            const existing = s.items.find((i) => i.productId === p.id);
            if (existing) {
              return {
                items: s.items.map(
                  (i) => i.productId === p.id ? { ...i, halfKg: i.halfKg + 1 } : i
                )
              };
            }
            return {
              items: [
                ...s.items,
                {
                  productId: p.id,
                  name: p.name,
                  image: p.image,
                  pricePerKg: p.pricePerKg,
                  pricePerHalfKg: p.pricePerHalfKg,
                  kg: 0,
                  halfKg: 1
                }
              ]
            };
          }),
          setQty: (productId, kg, halfKg) => set5((s) => ({
            items: s.items.map((i) => i.productId === productId ? { ...i, kg, halfKg } : i).filter((i) => i.kg > 0 || i.halfKg > 0)
          })),
          remove: (productId) => set5((s) => ({ items: s.items.filter((i) => i.productId !== productId) })),
          clear: () => set5({ items: [] })
        }),
        { name: "rhb-cart" }
      )
    );
    lineTotal = (i) => i.kg * i.pricePerKg + i.halfKg * i.pricePerHalfKg;
    cartTotal = (items) => items.reduce((acc, i) => acc + lineTotal(i), 0);
    cartCount = (items) => items.reduce((acc, i) => acc + i.kg + i.halfKg, 0);
    cartWeight = (items) => items.reduce((acc, i) => acc + i.kg + i.halfKg * 0.5, 0);
  }
});

// dist/server/assets/orders-BJKg52UO.js
import { create as create2 } from "zustand";
import { remove, ref, update, set, onValue } from "firebase/database";
import { toast } from "sonner";
var getDailySequence, formatOrderId, useOrders, ordersRef;
var init_orders_BJKg52UO = __esm({
  "dist/server/assets/orders-BJKg52UO.js"() {
    "use strict";
    init_router_B40ruYtd();
    getDailySequence = (orders, dateStr) => {
      if (!dateStr || typeof dateStr !== "string") return 1;
      const today = dateStr.split("T")[0];
      const todaysOrders = orders.filter((o) => o.date && typeof o.date === "string" && o.date.startsWith(today));
      if (todaysOrders.length === 0) return 1;
      const sequences = todaysOrders.map((o) => o.dailySequence);
      return Math.max(...sequences) + 1;
    };
    formatOrderId = (sequence) => {
      return sequence.toString().padStart(2, "0");
    };
    useOrders = create2()((set$1, get) => ({
      orders: [],
      loading: true,
      _setOrders: (orders) => set$1({ orders, loading: false }),
      addOrder: async (orderData) => {
        console.log("[Store] addOrder initiated:", orderData.customerName);
        const now = (/* @__PURE__ */ new Date()).toISOString();
        const datePrefix = (now || "").split("T")[0]?.replace(/-/g, "") || "";
        const sequence = getDailySequence(get().orders, now);
        const shortId = formatOrderId(sequence);
        const uid = `${datePrefix}-${shortId}`;
        console.log("[Store] Generated IDs:", { shortId, uid, sequence });
        const newOrder = {
          ...orderData,
          id: shortId,
          uid,
          date: now,
          status: "new",
          isPaid: false,
          dailySequence: sequence
        };
        try {
          console.log("[Store] Attempting Firebase write for UID:", uid);
          await set(ref(rtdb, `orders/${uid}`), newOrder);
          console.log("[Store] Firebase write success.");
          set$1((state) => ({ orders: [newOrder, ...state.orders] }));
          return newOrder;
        } catch (error) {
          console.error("[Store] Firebase order save error:", error);
          throw error;
        }
      },
      updateOrderStatus: (uid, status) => {
        set$1((state) => ({
          orders: state.orders.map((o) => o.uid === uid ? { ...o, status } : o)
        }));
        update(ref(rtdb, `orders/${uid}`), { status });
      },
      assignPartner: (uid, partnerId) => {
        set$1((state) => ({
          orders: state.orders.map(
            (o) => o.uid === uid ? { ...o, assignedPartnerId: partnerId } : o
          )
        }));
        update(ref(rtdb, `orders/${uid}`), { assignedPartnerId: partnerId });
      },
      updateOrderAddress: (uid, address, mapsLocation) => {
        set$1((state) => ({
          orders: state.orders.map(
            (o) => o.uid === uid ? { ...o, address, mapsLocation } : o
          )
        }));
        update(ref(rtdb, `orders/${uid}`), { address, mapsLocation });
      },
      updateOrderPaymentStatus: (uid, isPaid, collectedBy) => {
        set$1((state) => ({
          orders: state.orders.map(
            (o) => o.uid === uid ? { ...o, isPaid, paymentCollectedBy: collectedBy } : o
          )
        }));
        update(ref(rtdb, `orders/${uid}`), { isPaid, paymentCollectedBy: collectedBy });
      },
      updateOrderDetails: (uid, updates) => {
        set$1((state) => ({
          orders: state.orders.map((o) => o.uid === uid ? { ...o, ...updates } : o)
        }));
        update(ref(rtdb, `orders/${uid}`), updates);
      },
      clearAllData: () => {
        set$1({ orders: [] });
        remove(ref(rtdb, "orders"));
        toast.success("All order data cleared!");
      }
    }));
    ordersRef = ref(rtdb, "orders");
    onValue(ordersRef, (snapshot) => {
      const data = snapshot.val();
      if (data) {
        const orders = Object.values(data).filter((o) => o && typeof o === "object");
        orders.sort((a, b) => {
          const da = a.date ? new Date(a.date).getTime() : 0;
          const db = b.date ? new Date(b.date).getTime() : 0;
          return db - da;
        });
        useOrders.getState()._setOrders(orders);
      } else {
        useOrders.getState()._setOrders([]);
      }
    });
  }
});

// dist/server/assets/checkout-CUR7wfVc.js
var checkout_CUR7wfVc_exports = {};
__export(checkout_CUR7wfVc_exports, {
  component: () => CheckoutPage
});
import { jsxs as jsxs2, jsx as jsx3, Fragment } from "react/jsx-runtime";
import { useNavigate, Link } from "@tanstack/react-router";
import { useState as useState2, useRef, useEffect as useEffect2, Suspense } from "react";
import { Square, Mic, Pause, Play, Trash2, MapPin, Loader2, Crosshair, ShoppingBag, ArrowLeft, Info, CheckCircle2 } from "lucide-react";
import { motion } from "framer-motion";
import { toast as toast2 } from "sonner";
import L from "leaflet";
import "zustand";
import "zustand/middleware";
import "firebase/database";
import "firebase/app";
import "firebase/auth";
import "firebase/firestore";
import "firebase/analytics";
import "@imagekit/javascript";
function VoiceRecorder({
  onChange
}) {
  const [recording, setRecording] = useState2(false);
  const [audioUrl, setAudioUrl] = useState2(null);
  const [playing, setPlaying] = useState2(false);
  const [duration, setDuration] = useState2(0);
  const mediaRecorderRef = useRef(null);
  const chunksRef = useRef([]);
  const audioRef = useRef(null);
  const timerRef = useRef(null);
  const start = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      const mr = new MediaRecorder(stream);
      chunksRef.current = [];
      mr.ondataavailable = (e) => {
        if (e.data.size > 0) chunksRef.current.push(e.data);
      };
      mr.onstop = () => {
        const types = ["audio/webm", "audio/mp4", "audio/ogg", "audio/wav", "audio/aac"];
        const type = types.find((t) => MediaRecorder.isTypeSupported(t)) || "audio/webm";
        const blob = new Blob(chunksRef.current, { type });
        const url = URL.createObjectURL(blob);
        setAudioUrl(url);
        onChange(blob);
        stream.getTracks().forEach((t) => t.stop());
      };
      mr.start();
      mediaRecorderRef.current = mr;
      setRecording(true);
      setDuration(0);
      timerRef.current = window.setInterval(() => {
        setDuration((d) => d + 1);
      }, 1e3);
    } catch {
      alert("Microphone permission required to record a voice note.");
    }
  };
  const stop = () => {
    mediaRecorderRef.current?.stop();
    setRecording(false);
    if (timerRef.current) {
      clearInterval(timerRef.current);
      timerRef.current = null;
    }
  };
  const remove5 = () => {
    if (audioUrl) URL.revokeObjectURL(audioUrl);
    setAudioUrl(null);
    setDuration(0);
    onChange(null);
  };
  const togglePlay = () => {
    if (!audioRef.current) return;
    if (playing) {
      audioRef.current.pause();
    } else {
      audioRef.current.play();
    }
  };
  const fmt = (s) => `${String(Math.floor(s / 60)).padStart(2, "0")}:${String(s % 60).padStart(2, "0")}`;
  return /* @__PURE__ */ jsxs2("div", { className: "space-y-2", children: [
    /* @__PURE__ */ jsxs2("div", { className: "text-sm font-semibold text-navy", children: [
      "Voice Note ",
      /* @__PURE__ */ jsx3("span", { className: "font-normal text-muted-foreground", children: "(optional)" })
    ] }),
    !audioUrl ? /* @__PURE__ */ jsx3(
      "button",
      {
        type: "button",
        onClick: recording ? stop : start,
        className: `w-full flex items-center justify-center gap-3 py-4 rounded-xl border-2 border-dashed transition-colors ${recording ? "border-destructive bg-destructive/5 text-destructive" : "border-border hover:border-orange hover:bg-orange/5 text-foreground"}`,
        children: recording ? /* @__PURE__ */ jsxs2(Fragment, { children: [
          /* @__PURE__ */ jsx3(Square, { className: "size-4 fill-current" }),
          /* @__PURE__ */ jsxs2("span", { className: "font-semibold", children: [
            "Stop recording \xB7 ",
            fmt(duration)
          ] }),
          /* @__PURE__ */ jsx3("span", { className: "size-2 rounded-full bg-destructive animate-pulse" })
        ] }) : /* @__PURE__ */ jsxs2(Fragment, { children: [
          /* @__PURE__ */ jsx3(Mic, { className: "size-4" }),
          /* @__PURE__ */ jsx3("span", { className: "font-semibold", children: "Tap to record voice note" })
        ] })
      }
    ) : /* @__PURE__ */ jsxs2("div", { className: "flex items-center gap-3 bg-secondary/60 rounded-xl p-3", children: [
      /* @__PURE__ */ jsx3(
        "button",
        {
          type: "button",
          onClick: togglePlay,
          className: "size-10 rounded-full bg-orange text-navy grid place-items-center",
          children: playing ? /* @__PURE__ */ jsx3(Pause, { className: "size-4" }) : /* @__PURE__ */ jsx3(Play, { className: "size-4 ml-0.5" })
        }
      ),
      /* @__PURE__ */ jsxs2("div", { className: "flex-1 text-sm", children: [
        /* @__PURE__ */ jsx3("div", { className: "font-semibold text-navy", children: "Voice note recorded" }),
        /* @__PURE__ */ jsx3("div", { className: "text-xs text-muted-foreground", children: fmt(duration) })
      ] }),
      /* @__PURE__ */ jsx3(
        "button",
        {
          type: "button",
          onClick: remove5,
          className: "size-9 rounded-full bg-background hover:bg-destructive hover:text-white grid place-items-center text-muted-foreground transition-colors",
          "aria-label": "Delete recording",
          children: /* @__PURE__ */ jsx3(Trash2, { className: "size-4" })
        }
      ),
      /* @__PURE__ */ jsx3(
        "audio",
        {
          ref: audioRef,
          src: audioUrl,
          onPlay: () => setPlaying(true),
          onPause: () => setPlaying(false),
          onEnded: () => setPlaying(false),
          className: "hidden"
        }
      )
    ] })
  ] });
}
function MapPicker({
  location,
  onChange
}) {
  const containerRef = useRef(null);
  const mapRef = useRef(null);
  const markerRef = useRef(null);
  const [detecting, setDetecting] = useState2(false);
  const [error, setError] = useState2(null);
  useEffect2(() => {
    if (!containerRef.current || mapRef.current) return;
    const initial = location ? [location.lat, location.lng] : [12.9716, 77.5946];
    const map = L.map(containerRef.current, {
      center: initial,
      zoom: location ? 16 : 12,
      scrollWheelZoom: false
    });
    L.tileLayer("https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png", {
      attribution: "\xA9 OpenStreetMap contributors",
      maxZoom: 19
    }).addTo(map);
    const marker = L.marker(initial, { draggable: true, icon: DefaultIcon }).addTo(
      map
    );
    marker.on("dragend", async () => {
      const { lat, lng } = marker.getLatLng();
      const address = await reverseGeocode(lat, lng);
      onChange({ lat, lng, address });
    });
    mapRef.current = map;
    markerRef.current = marker;
    return () => {
      map.remove();
      mapRef.current = null;
      markerRef.current = null;
    };
  }, []);
  useEffect2(() => {
    if (!mapRef.current || !markerRef.current || !location) return;
    const ll = [location.lat, location.lng];
    markerRef.current.setLatLng(ll);
    mapRef.current.setView(ll, 16);
  }, [location?.lat, location?.lng]);
  const detect = () => {
    if (!navigator.geolocation) {
      setError("Geolocation not supported on this browser.");
      return;
    }
    setDetecting(true);
    setError(null);
    navigator.geolocation.getCurrentPosition(
      async (pos) => {
        const { latitude, longitude } = pos.coords;
        const address = await reverseGeocode(latitude, longitude);
        onChange({ lat: latitude, lng: longitude, address });
        setDetecting(false);
      },
      (err) => {
        console.error("Geolocation error:", err);
        let msg = "Couldn't detect your location. Please drag the pin manually.";
        if (err.code === err.PERMISSION_DENIED) {
          msg = "Location permission denied. Please allow location access or drag the pin.";
        } else if (err.code === err.TIMEOUT) {
          msg = "Location request timed out. Drag the pin to your spot.";
        }
        setError(msg);
        setDetecting(false);
      },
      {
        enableHighAccuracy: true,
        timeout: 15e3,
        maximumAge: 0
      }
    );
  };
  useEffect2(() => {
    if (!location) detect();
  }, []);
  return /* @__PURE__ */ jsxs2("div", { className: "space-y-3", children: [
    /* @__PURE__ */ jsxs2("div", { className: "flex items-center justify-between gap-3", children: [
      /* @__PURE__ */ jsxs2("div", { className: "flex items-center gap-2 text-sm font-semibold text-navy", children: [
        /* @__PURE__ */ jsx3(MapPin, { className: "size-4 text-orange" }),
        "Delivery Location"
      ] }),
      /* @__PURE__ */ jsxs2(
        "button",
        {
          type: "button",
          onClick: detect,
          disabled: detecting,
          className: "inline-flex items-center gap-2 text-xs font-semibold px-3 py-2 rounded-full bg-secondary hover:bg-orange hover:text-navy transition-colors disabled:opacity-60",
          children: [
            detecting ? /* @__PURE__ */ jsx3(Loader2, { className: "size-3.5 animate-spin" }) : /* @__PURE__ */ jsx3(Crosshair, { className: "size-3.5" }),
            detecting ? "Detecting..." : "Auto-detect"
          ]
        }
      )
    ] }),
    /* @__PURE__ */ jsx3(
      "div",
      {
        ref: containerRef,
        className: "h-[280px] w-full rounded-2xl overflow-hidden border border-border"
      }
    ),
    error && /* @__PURE__ */ jsx3("div", { className: "text-xs text-destructive bg-destructive/10 px-3 py-2 rounded-lg", children: error }),
    location && /* @__PURE__ */ jsxs2("div", { className: "text-xs text-muted-foreground bg-secondary/60 px-3 py-2 rounded-lg", children: [
      /* @__PURE__ */ jsx3("span", { className: "font-semibold text-navy", children: "Pin:" }),
      " ",
      location.lat.toFixed(5),
      ", ",
      location.lng.toFixed(5),
      location.address && /* @__PURE__ */ jsx3("div", { className: "mt-1 text-foreground", children: location.address })
    ] }),
    /* @__PURE__ */ jsx3("div", { className: "text-[11px] text-muted-foreground", children: "Tip: drag the pin to fine-tune your exact spot." })
  ] });
}
async function reverseGeocode(lat, lng) {
  try {
    const res = await fetch(
      `https://nominatim.openstreetmap.org/reverse?format=json&lat=${lat}&lon=${lng}&zoom=18`,
      { headers: { Accept: "application/json" } }
    );
    if (!res.ok) return void 0;
    const data = await res.json();
    return data.display_name;
  } catch {
    return void 0;
  }
}
function CheckoutPage() {
  const items = useCart((s) => s.items);
  const clear = useCart((s) => s.clear);
  const navigate = useNavigate();
  const total = cartTotal(items);
  const [location, setLocation] = useState2(null);
  const [mounted, setMounted] = useState2(false);
  useEffect2(() => setMounted(true), []);
  const [voiceNote, setVoiceNote] = useState2(null);
  const [payment, setPayment] = useState2("");
  const [submitting, setSubmitting] = useState2(false);
  const addOrder = useOrders((s) => s.addOrder);
  const handleSubmit = async (e) => {
    e.preventDefault();
    console.log("Starting order submission...");
    if (items.length === 0) {
      toast2.error("Your cart is empty.");
      return;
    }
    if (!payment) {
      toast2.error("Please select a payment method.");
      return;
    }
    setSubmitting(true);
    try {
      const form = new FormData(e.currentTarget);
      const address = {
        apartment: form.get("apartment"),
        street: form.get("street"),
        door: form.get("door"),
        floor: form.get("floor") || ""
      };
      let voiceNoteUrl = "";
      if (voiceNote) {
        console.log("Uploading voice note to ImageKit...");
        try {
          const uploadResult = await uploadFile(voiceNote, "voice_notes");
          voiceNoteUrl = uploadResult.secure_url;
          console.log("Voice note uploaded:", voiceNoteUrl);
        } catch (err) {
          console.error("Voice note upload failed:", err);
        }
      }
      const orderData = {
        customerName: form.get("name"),
        phone: form.get("phone"),
        address,
        mapsLocation: location ? `${location.lat},${location.lng}` : "",
        mapsLink: location ? `https://www.google.com/maps?q=${location.lat},${location.lng}` : "",
        voiceNote: !!voiceNote,
        voiceNoteUrl,
        paymentMethod: payment === "cod" ? "Cash" : "UPI",
        items,
        totalAmount: total
      };
      console.log("Sending order to database...");
      const orderPromise = addOrder(orderData);
      const timeoutPromise = new Promise((_, reject) => setTimeout(() => reject(new Error("Request timed out. Please try again.")), 1e4));
      const newOrder = await Promise.race([orderPromise, timeoutPromise]);
      console.log("Order saved successfully:", newOrder.id);
      toast2.success("Order placed successfully!");
      clear();
      navigate({
        to: "/order-success/$id",
        params: {
          id: newOrder.id
        }
      });
    } catch (error) {
      console.error("Order submission error:", error);
      toast2.error("Failed to place order. Please check your connection and try again.");
    } finally {
      setSubmitting(false);
    }
  };
  if (items.length === 0) {
    return /* @__PURE__ */ jsx3("div", { className: "min-h-screen bg-secondary/30 grid place-items-center px-4", children: /* @__PURE__ */ jsxs2("div", { className: "text-center max-w-md", children: [
      /* @__PURE__ */ jsx3(ShoppingBag, { className: "size-16 mx-auto text-muted-foreground/50" }),
      /* @__PURE__ */ jsx3("h1", { className: "mt-4 font-display text-3xl text-navy", children: "Your cart is empty" }),
      /* @__PURE__ */ jsx3("p", { className: "mt-2 text-muted-foreground", children: "Add some delicious batter before checking out." }),
      /* @__PURE__ */ jsxs2(Link, { to: "/", className: "mt-6 inline-flex items-center gap-2 bg-navy text-white px-6 py-3 rounded-full font-semibold hover:bg-orange hover:text-navy transition-colors", children: [
        /* @__PURE__ */ jsx3(ArrowLeft, { className: "size-4" }),
        " Back to shop"
      ] })
    ] }) });
  }
  return /* @__PURE__ */ jsxs2("div", { className: "min-h-screen bg-secondary/30", children: [
    /* @__PURE__ */ jsx3("header", { className: "bg-navy text-white", children: /* @__PURE__ */ jsxs2("div", { className: "container-px mx-auto max-w-7xl py-5 flex items-center justify-between", children: [
      /* @__PURE__ */ jsxs2(Link, { to: "/", className: "inline-flex items-center gap-2 text-white/80 hover:text-orange text-sm", children: [
        /* @__PURE__ */ jsx3(ArrowLeft, { className: "size-4" }),
        " Back"
      ] }),
      /* @__PURE__ */ jsx3("div", { className: "font-display font-bold text-lg", children: "Checkout" }),
      /* @__PURE__ */ jsx3("div", { className: "w-16" })
    ] }) }),
    /* @__PURE__ */ jsxs2("form", { onSubmit: handleSubmit, className: "container-px mx-auto max-w-7xl py-8 lg:py-12 grid lg:grid-cols-3 gap-8", children: [
      /* @__PURE__ */ jsxs2("div", { className: "lg:col-span-2 space-y-6", children: [
        /* @__PURE__ */ jsx3(Section, { title: "Customer Details", step: "1", children: /* @__PURE__ */ jsxs2("div", { className: "grid sm:grid-cols-2 gap-4", children: [
          /* @__PURE__ */ jsx3(Field, { label: "Full Name", name: "name", required: true }),
          /* @__PURE__ */ jsx3(Field, { label: "Phone Number", name: "phone", type: "tel", required: true })
        ] }) }),
        /* @__PURE__ */ jsx3(Section, { title: "Delivery Address", step: "2", children: /* @__PURE__ */ jsxs2("div", { className: "grid sm:grid-cols-2 gap-4", children: [
          /* @__PURE__ */ jsx3(Field, { label: "Apartment / Home Name", name: "apartment", required: true }),
          /* @__PURE__ */ jsx3(Field, { label: "Street", name: "street", required: true }),
          /* @__PURE__ */ jsx3(Field, { label: "Door Number", name: "door", required: true }),
          /* @__PURE__ */ jsx3(Field, { label: "Floor", name: "floor" })
        ] }) }),
        /* @__PURE__ */ jsx3(Section, { title: "Pin Your Location", step: "3", children: mounted ? /* @__PURE__ */ jsx3(Suspense, { fallback: /* @__PURE__ */ jsx3("div", { className: "h-[280px] rounded-2xl bg-secondary/60 grid place-items-center", children: /* @__PURE__ */ jsx3(Loader2, { className: "size-6 animate-spin text-orange" }) }), children: /* @__PURE__ */ jsx3(MapPicker, { location, onChange: setLocation }) }) : /* @__PURE__ */ jsx3("div", { className: "h-[280px] rounded-2xl bg-secondary/60 grid place-items-center", children: /* @__PURE__ */ jsx3(Loader2, { className: "size-6 animate-spin text-orange" }) }) }),
        /* @__PURE__ */ jsx3(Section, { title: "Voice Note for Delivery", step: "4", children: /* @__PURE__ */ jsx3(VoiceRecorder, { onChange: setVoiceNote }) }),
        /* @__PURE__ */ jsx3(Section, { title: "Payment Method", step: "5", children: /* @__PURE__ */ jsxs2("div", { className: "space-y-3", children: [
          /* @__PURE__ */ jsxs2("label", { className: `flex items-center gap-3 p-4 rounded-xl border-2 cursor-pointer transition-colors ${payment === "cod" ? "border-orange bg-orange/5" : "border-border hover:border-orange/40"}`, children: [
            /* @__PURE__ */ jsx3("input", { type: "radio", name: "payment", value: "cod", checked: payment === "cod", onChange: (e) => setPayment(e.target.value), className: "accent-orange" }),
            /* @__PURE__ */ jsxs2("div", { className: "flex-1", children: [
              /* @__PURE__ */ jsx3("div", { className: "font-semibold text-navy", children: "Cash on Delivery" }),
              /* @__PURE__ */ jsx3("div", { className: "text-xs text-muted-foreground", children: "Pay with cash when your order arrives." })
            ] })
          ] }),
          /* @__PURE__ */ jsxs2("label", { className: `flex items-center gap-3 p-4 rounded-xl border-2 cursor-pointer transition-colors ${payment === "upi" ? "border-orange bg-orange/5" : "border-border hover:border-orange/40"}`, children: [
            /* @__PURE__ */ jsx3("input", { type: "radio", name: "payment", value: "upi", checked: payment === "upi", onChange: (e) => setPayment(e.target.value), className: "accent-orange" }),
            /* @__PURE__ */ jsxs2("div", { className: "flex-1", children: [
              /* @__PURE__ */ jsx3("div", { className: "font-semibold text-navy", children: "UPI" }),
              /* @__PURE__ */ jsx3("div", { className: "text-xs text-muted-foreground", children: "Pay via UPI \u2014 our team will share payment details after order confirmation." })
            ] })
          ] }),
          payment && /* @__PURE__ */ jsxs2(motion.div, { initial: {
            opacity: 0,
            y: 8
          }, animate: {
            opacity: 1,
            y: 0
          }, className: "flex items-start gap-3 p-4 rounded-xl bg-navy/5 border border-navy/10", children: [
            /* @__PURE__ */ jsx3(Info, { className: "size-5 text-navy flex-shrink-0 mt-0.5" }),
            /* @__PURE__ */ jsxs2("div", { className: "text-sm text-navy", children: [
              "Our team will contact you shortly to",
              " ",
              /* @__PURE__ */ jsx3("span", { className: "font-semibold", children: "confirm the order" }),
              "."
            ] })
          ] })
        ] }) })
      ] }),
      /* @__PURE__ */ jsx3("aside", { className: "lg:sticky lg:top-6 h-fit", children: /* @__PURE__ */ jsxs2("div", { className: "bg-card rounded-3xl border border-border p-6", children: [
        /* @__PURE__ */ jsx3("div", { className: "font-display font-bold text-xl text-navy", children: "Order Summary" }),
        /* @__PURE__ */ jsx3("div", { className: "mt-5 space-y-3 max-h-[300px] overflow-y-auto", children: items.map((it) => /* @__PURE__ */ jsxs2("div", { className: "flex gap-3", children: [
          /* @__PURE__ */ jsx3("img", { src: it.image, alt: it.name, className: "size-14 rounded-lg object-cover flex-shrink-0" }),
          /* @__PURE__ */ jsxs2("div", { className: "flex-1 min-w-0", children: [
            /* @__PURE__ */ jsx3("div", { className: "font-semibold text-sm text-navy leading-tight", children: it.name }),
            /* @__PURE__ */ jsxs2("div", { className: "text-xs text-muted-foreground mt-0.5", children: [
              it.kg > 0 && `${it.kg} \xD7 1KG`,
              it.kg > 0 && it.halfKg > 0 && " \xB7 ",
              it.halfKg > 0 && `${it.halfKg} \xD7 \xBDKG`
            ] })
          ] }),
          /* @__PURE__ */ jsxs2("div", { className: "font-semibold text-navy text-sm", children: [
            "\u20B9",
            lineTotal(it)
          ] })
        ] }, it.productId)) }),
        /* @__PURE__ */ jsxs2("div", { className: "mt-5 pt-5 border-t border-border space-y-2 text-sm", children: [
          /* @__PURE__ */ jsx3(Row, { label: "Subtotal", value: `\u20B9${total}` }),
          /* @__PURE__ */ jsx3(Row, { label: "Delivery", value: "Free" }),
          /* @__PURE__ */ jsxs2("div", { className: "pt-3 border-t border-border flex items-center justify-between", children: [
            /* @__PURE__ */ jsx3("span", { className: "font-display font-bold text-navy", children: "Total" }),
            /* @__PURE__ */ jsxs2("span", { className: "font-display font-bold text-2xl text-navy", children: [
              "\u20B9",
              total
            ] })
          ] })
        ] }),
        /* @__PURE__ */ jsx3("button", { type: "submit", disabled: submitting, className: "mt-6 w-full bg-orange text-navy py-4 rounded-full font-bold hover:shadow-xl hover:shadow-orange/30 hover:-translate-y-0.5 transition-all disabled:opacity-60 inline-flex items-center justify-center gap-2", children: submitting ? "Placing order..." : /* @__PURE__ */ jsxs2(Fragment, { children: [
          /* @__PURE__ */ jsx3(CheckCircle2, { className: "size-5" }),
          " Complete Order"
        ] }) }),
        /* @__PURE__ */ jsx3("p", { className: "mt-3 text-[11px] text-center text-muted-foreground", children: "By placing this order you agree to our terms." })
      ] }) })
    ] })
  ] });
}
function Section({
  title,
  step,
  children
}) {
  return /* @__PURE__ */ jsxs2("section", { className: "bg-card rounded-3xl border border-border p-6", children: [
    /* @__PURE__ */ jsxs2("div", { className: "flex items-center gap-3 mb-5", children: [
      /* @__PURE__ */ jsx3("div", { className: "size-8 rounded-full bg-navy text-white grid place-items-center text-sm font-bold", children: step }),
      /* @__PURE__ */ jsx3("h2", { className: "font-display font-bold text-xl text-navy", children: title })
    ] }),
    children
  ] });
}
function Field({
  label,
  name,
  type = "text",
  required
}) {
  return /* @__PURE__ */ jsxs2("div", { children: [
    /* @__PURE__ */ jsxs2("label", { className: "block text-xs uppercase tracking-wider font-semibold text-muted-foreground mb-2", children: [
      label,
      " ",
      required && /* @__PURE__ */ jsx3("span", { className: "text-orange", children: "*" })
    ] }),
    /* @__PURE__ */ jsx3("input", { name, type, required, className: "w-full bg-background border border-border rounded-xl px-4 py-3 text-sm focus:outline-none focus:ring-2 focus:ring-orange/40 focus:border-orange" })
  ] });
}
function Row({
  label,
  value
}) {
  return /* @__PURE__ */ jsxs2("div", { className: "flex items-center justify-between", children: [
    /* @__PURE__ */ jsx3("span", { className: "text-muted-foreground", children: label }),
    /* @__PURE__ */ jsx3("span", { className: "font-medium text-foreground", children: value })
  ] });
}
var DefaultIcon;
var init_checkout_CUR7wfVc = __esm({
  "dist/server/assets/checkout-CUR7wfVc.js"() {
    "use strict";
    init_cart_CKZOh9VL();
    init_orders_BJKg52UO();
    init_imagekit_78z04_ax();
    DefaultIcon = L.icon({
      iconUrl: "https://unpkg.com/leaflet@1.9.4/dist/images/marker-icon.png",
      iconRetinaUrl: "https://unpkg.com/leaflet@1.9.4/dist/images/marker-icon-2x.png",
      shadowUrl: "https://unpkg.com/leaflet@1.9.4/dist/images/marker-shadow.png",
      iconSize: [25, 41],
      iconAnchor: [12, 41]
    });
  }
});

// dist/server/assets/adminFilter-Clv2cQDi.js
import { create as create3 } from "zustand";
import { persist as persist2 } from "zustand/middleware";
import { format } from "date-fns";
var useAdminFilter;
var init_adminFilter_Clv2cQDi = __esm({
  "dist/server/assets/adminFilter-Clv2cQDi.js"() {
    "use strict";
    useAdminFilter = create3()(
      persist2(
        (set5) => ({
          selectedDate: format(/* @__PURE__ */ new Date(), "yyyy-MM-dd"),
          setSelectedDate: (date) => set5({ selectedDate: date }),
          resetDate: () => set5({ selectedDate: format(/* @__PURE__ */ new Date(), "yyyy-MM-dd") })
        }),
        {
          name: "rhb-admin-filter"
        }
      )
    );
  }
});

// dist/server/assets/admin-DnBpFsiP.js
var admin_DnBpFsiP_exports = {};
__export(admin_DnBpFsiP_exports, {
  component: () => AdminLayout
});
import { jsxs as jsxs3, jsx as jsx4 } from "react/jsx-runtime";
import { useRouter as useRouter2, Outlet as Outlet2, Link as Link2 } from "@tanstack/react-router";
import { X, Calendar, Menu, LayoutDashboard, ShoppingCart, IndianRupee, Package, Users, MessageSquare, Settings, ExternalLink, LogOut as LogOut2 } from "lucide-react";
import * as React from "react";
import { useState as useState3 } from "react";
import * as SheetPrimitive from "@radix-ui/react-dialog";
import { cva } from "class-variance-authority";
import "sonner";
import "zustand";
import "firebase/database";
import "firebase/app";
import "firebase/auth";
import "firebase/firestore";
import "firebase/analytics";
import "zustand/middleware";
import "@imagekit/javascript";
import "clsx";
import "tailwind-merge";
import "date-fns";
function AdminLayout() {
  const isAdmin = useAdminAuth((s) => s.isAdmin);
  const logout = useAdminAuth((s) => s.logout);
  const enquiries = useSiteSettings((s) => s.enquiries);
  const unreadEnquiries = enquiries.filter((e) => !e.isRead).length;
  const router2 = useRouter2();
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState3(false);
  const {
    selectedDate,
    setSelectedDate
  } = useAdminFilter();
  const navItems = [{
    label: "Dashboard",
    to: "/admin/dashboard",
    icon: LayoutDashboard
  }, {
    label: "Orders",
    to: "/admin/orders",
    icon: ShoppingCart
  }, {
    label: "Payments",
    to: "/admin/payments",
    icon: IndianRupee
  }, {
    label: "Products",
    to: "/admin/products",
    icon: Package
  }, {
    label: "Delivery Partners",
    to: "/admin/delivery",
    icon: Users
  }, {
    label: "Enquiries",
    to: "/admin/enquiries",
    icon: MessageSquare,
    badge: unreadEnquiries
  }, {
    label: "Website CMS",
    to: "/admin/cms",
    icon: Settings
  }];
  if (!isAdmin) {
    return /* @__PURE__ */ jsx4(AdminLogin, {});
  }
  const handleLogout = () => {
    logout();
    router2.navigate({
      to: "/admin/login"
    });
  };
  const SidebarContent = ({
    isMobile = false
  }) => /* @__PURE__ */ jsxs3("div", { className: "flex flex-col h-full", children: [
    /* @__PURE__ */ jsx4("div", { className: cn("h-20 flex items-center px-8 border-b border-white/5", isMobile ? "px-4" : "px-8"), children: /* @__PURE__ */ jsxs3("div", { className: "flex items-center gap-3", children: [
      /* @__PURE__ */ jsx4(Logo, { size: "sm" }),
      /* @__PURE__ */ jsxs3("div", { className: "font-display font-bold text-xl tracking-tight text-white", children: [
        "Admin ",
        /* @__PURE__ */ jsx4("span", { className: "text-orange", children: "HUB" })
      ] })
    ] }) }),
    /* @__PURE__ */ jsxs3("nav", { className: "flex-1 px-4 py-8 space-y-1 overflow-y-auto custom-scrollbar", children: [
      /* @__PURE__ */ jsx4("div", { className: "px-4 mb-4 text-[10px] font-black uppercase tracking-[0.2em] text-white/30", children: "Main Menu" }),
      navItems.map((item) => /* @__PURE__ */ jsxs3(Link2, { to: item.to, onClick: () => isMobile && setIsMobileMenuOpen(false), activeProps: {
        className: "bg-white/10 text-orange border-l-4 border-orange"
      }, activeOptions: item.to === "/admin/dashboard" ? {
        exact: true
      } : {}, className: "flex items-center justify-between gap-3 px-5 py-3.5 rounded-xl hover:bg-white/5 transition-all text-white/70 hover:text-white font-bold text-sm group", children: [
        /* @__PURE__ */ jsxs3("div", { className: "flex items-center gap-3", children: [
          /* @__PURE__ */ jsx4(item.icon, { className: "size-5 group-hover:scale-110 transition-transform" }),
          item.label
        ] }),
        item.badge > 0 && /* @__PURE__ */ jsx4("span", { className: "bg-orange text-navy text-[10px] font-black px-2 py-0.5 rounded-full shadow-lg", children: item.badge })
      ] }, item.label))
    ] }),
    /* @__PURE__ */ jsxs3("div", { className: "p-6 border-t border-white/5 space-y-3", children: [
      /* @__PURE__ */ jsxs3(Link2, { to: "/", className: "flex items-center gap-3 px-5 py-3.5 rounded-xl bg-white/5 hover:bg-white/10 transition-all text-white/60 hover:text-white font-bold text-xs uppercase tracking-widest", children: [
        /* @__PURE__ */ jsx4(ExternalLink, { className: "size-4" }),
        "Live Site"
      ] }),
      /* @__PURE__ */ jsxs3("button", { onClick: handleLogout, className: "w-full flex items-center gap-3 px-5 py-3.5 rounded-xl bg-red-500/10 hover:bg-red-500 transition-all text-red-500 hover:text-white font-bold text-xs uppercase tracking-widest", children: [
        /* @__PURE__ */ jsx4(LogOut2, { className: "size-4" }),
        "Sign Out"
      ] })
    ] })
  ] });
  return /* @__PURE__ */ jsxs3("div", { className: "min-h-screen bg-secondary flex flex-col lg:flex-row", children: [
    /* @__PURE__ */ jsx4("aside", { className: "hidden lg:flex w-72 bg-navy text-white flex-col fixed inset-y-0 left-0 shadow-2xl z-20", children: /* @__PURE__ */ jsx4(SidebarContent, {}) }),
    /* @__PURE__ */ jsxs3("div", { className: "lg:hidden h-16 bg-navy text-white flex items-center justify-between px-4 sticky top-0 z-30 shadow-md", children: [
      /* @__PURE__ */ jsxs3("div", { className: "flex items-center gap-2", children: [
        /* @__PURE__ */ jsx4(Logo, { size: "sm" }),
        /* @__PURE__ */ jsxs3("div", { className: "font-display font-bold text-lg tracking-tight", children: [
          "Admin ",
          /* @__PURE__ */ jsx4("span", { className: "text-orange", children: "HUB" })
        ] })
      ] }),
      /* @__PURE__ */ jsxs3("div", { className: "flex items-center gap-2", children: [
        /* @__PURE__ */ jsxs3("div", { className: "flex items-center gap-1.5 bg-white/10 rounded-lg px-2 py-1 border border-white/5", children: [
          /* @__PURE__ */ jsx4(Calendar, { className: "size-3.5 text-orange" }),
          /* @__PURE__ */ jsx4("input", { type: "date", value: selectedDate, onChange: (e) => setSelectedDate(e.target.value), className: "bg-transparent border-none text-[10px] font-bold text-white outline-none focus:ring-0 p-0" })
        ] }),
        /* @__PURE__ */ jsxs3(Sheet, { open: isMobileMenuOpen, onOpenChange: setIsMobileMenuOpen, children: [
          /* @__PURE__ */ jsx4(SheetTrigger, { asChild: true, children: /* @__PURE__ */ jsx4("button", { className: "p-2 hover:bg-white/10 rounded-lg transition-colors", children: /* @__PURE__ */ jsx4(Menu, { className: "size-6 text-white" }) }) }),
          /* @__PURE__ */ jsxs3(SheetContent, { side: "left", className: "p-0 bg-navy border-none w-[280px]", children: [
            /* @__PURE__ */ jsx4(SheetHeader, { className: "sr-only", children: /* @__PURE__ */ jsx4(SheetTitle, { children: "Admin Navigation" }) }),
            /* @__PURE__ */ jsx4(SidebarContent, { isMobile: true })
          ] })
        ] })
      ] })
    ] }),
    /* @__PURE__ */ jsxs3("main", { className: "flex-1 lg:ml-72 min-h-screen relative flex flex-col", children: [
      /* @__PURE__ */ jsxs3("div", { className: "h-20 bg-white/80 backdrop-blur-md border-b border-border hidden lg:flex items-center justify-between px-10 sticky top-0 z-10 shadow-sm", children: [
        /* @__PURE__ */ jsxs3("div", { className: "flex items-center gap-6", children: [
          /* @__PURE__ */ jsxs3("div", { className: "font-bold text-navy flex items-center gap-2", children: [
            /* @__PURE__ */ jsx4("div", { className: "size-2 bg-green-500 rounded-full animate-pulse" }),
            "System: ",
            /* @__PURE__ */ jsx4("span", { className: "text-muted-foreground font-medium ml-1", children: "Live" })
          ] }),
          /* @__PURE__ */ jsxs3("div", { className: "flex items-center gap-3 bg-secondary/50 rounded-2xl px-4 py-2 border border-border group hover:border-orange/30 transition-all", children: [
            /* @__PURE__ */ jsx4(Calendar, { className: "size-4 text-orange" }),
            /* @__PURE__ */ jsxs3("div", { className: "flex flex-col", children: [
              /* @__PURE__ */ jsx4("span", { className: "text-[9px] font-black uppercase tracking-widest text-muted-foreground leading-none mb-0.5", children: "Filtering Data For" }),
              /* @__PURE__ */ jsx4("input", { type: "date", value: selectedDate, onChange: (e) => setSelectedDate(e.target.value), className: "bg-transparent border-none text-sm font-black text-navy p-0 focus:ring-0 h-4" })
            ] })
          ] })
        ] }),
        /* @__PURE__ */ jsxs3("div", { className: "flex items-center gap-4", children: [
          /* @__PURE__ */ jsxs3("div", { className: "text-right hidden sm:block", children: [
            /* @__PURE__ */ jsx4("div", { className: "text-sm font-bold text-navy", children: "Administrator" }),
            /* @__PURE__ */ jsx4("div", { className: "text-[10px] text-muted-foreground font-bold uppercase tracking-widest", children: "Master Access" })
          ] }),
          /* @__PURE__ */ jsx4("div", { className: "size-10 rounded-2xl bg-secondary grid place-items-center text-navy font-black border border-border shadow-inner", children: "AD" })
        ] })
      ] }),
      /* @__PURE__ */ jsx4("div", { className: "flex-1 p-4 md:p-6 lg:p-10 w-full max-w-[1600px] mx-auto", children: /* @__PURE__ */ jsx4(Outlet2, {}) }),
      /* @__PURE__ */ jsx4("footer", { className: "p-6 text-center text-[10px] text-muted-foreground font-bold uppercase tracking-widest border-t border-border mt-auto", children: "Renuka's H2 Batters \u2014 Internal Administrative Panel" })
    ] })
  ] });
}
var Sheet, SheetTrigger, SheetPortal, SheetOverlay, sheetVariants, SheetContent, SheetHeader, SheetTitle, SheetDescription;
var init_admin_DnBpFsiP = __esm({
  "dist/server/assets/admin-DnBpFsiP.js"() {
    "use strict";
    init_router_B40ruYtd();
    init_Logo_DpDS75JT();
    init_utils_H80jjgLf();
    init_adminFilter_Clv2cQDi();
    Sheet = SheetPrimitive.Root;
    SheetTrigger = SheetPrimitive.Trigger;
    SheetPortal = SheetPrimitive.Portal;
    SheetOverlay = React.forwardRef(({ className, ...props }, ref5) => /* @__PURE__ */ jsx4(
      SheetPrimitive.Overlay,
      {
        className: cn(
          "fixed inset-0 z-50 bg-black/80  data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0",
          className
        ),
        ...props,
        ref: ref5
      }
    ));
    SheetOverlay.displayName = SheetPrimitive.Overlay.displayName;
    sheetVariants = cva(
      "fixed z-50 gap-4 bg-background p-6 shadow-lg transition ease-in-out data-[state=closed]:duration-300 data-[state=open]:duration-500 data-[state=open]:animate-in data-[state=closed]:animate-out",
      {
        variants: {
          side: {
            top: "inset-x-0 top-0 border-b data-[state=closed]:slide-out-to-top data-[state=open]:slide-in-from-top",
            bottom: "inset-x-0 bottom-0 border-t data-[state=closed]:slide-out-to-bottom data-[state=open]:slide-in-from-bottom",
            left: "inset-y-0 left-0 h-full w-3/4 border-r data-[state=closed]:slide-out-to-left data-[state=open]:slide-in-from-left sm:max-w-sm",
            right: "inset-y-0 right-0 h-full w-3/4 border-l data-[state=closed]:slide-out-to-right data-[state=open]:slide-in-from-right sm:max-w-sm"
          }
        },
        defaultVariants: {
          side: "right"
        }
      }
    );
    SheetContent = React.forwardRef(({ side = "right", className, children, ...props }, ref5) => /* @__PURE__ */ jsxs3(SheetPortal, { children: [
      /* @__PURE__ */ jsx4(SheetOverlay, {}),
      /* @__PURE__ */ jsxs3(SheetPrimitive.Content, { ref: ref5, className: cn(sheetVariants({ side }), className), ...props, children: [
        /* @__PURE__ */ jsxs3(SheetPrimitive.Close, { className: "absolute right-4 top-4 rounded-sm opacity-70 ring-offset-background transition-opacity hover:opacity-100 focus:outline-none focus:ring-2 focus:ring-ring focus:ring-offset-2 disabled:pointer-events-none data-[state=open]:bg-secondary", children: [
          /* @__PURE__ */ jsx4(X, { className: "h-4 w-4" }),
          /* @__PURE__ */ jsx4("span", { className: "sr-only", children: "Close" })
        ] }),
        children
      ] })
    ] }));
    SheetContent.displayName = SheetPrimitive.Content.displayName;
    SheetHeader = ({ className, ...props }) => /* @__PURE__ */ jsx4("div", { className: cn("flex flex-col space-y-2 text-center sm:text-left", className), ...props });
    SheetHeader.displayName = "SheetHeader";
    SheetTitle = React.forwardRef(({ className, ...props }, ref5) => /* @__PURE__ */ jsx4(
      SheetPrimitive.Title,
      {
        ref: ref5,
        className: cn("text-lg font-semibold text-foreground", className),
        ...props
      }
    ));
    SheetTitle.displayName = SheetPrimitive.Title.displayName;
    SheetDescription = React.forwardRef(({ className, ...props }, ref5) => /* @__PURE__ */ jsx4(
      SheetPrimitive.Description,
      {
        ref: ref5,
        className: cn("text-sm text-muted-foreground", className),
        ...props
      }
    ));
    SheetDescription.displayName = SheetPrimitive.Description.displayName;
  }
});

// dist/server/assets/products-DDA9Kbv3.js
import { create as create4 } from "zustand";
import { remove as remove2, ref as ref2, set as set2, update as update2, onValue as onValue2 } from "firebase/database";
var generateId, useProductsStore, productsRef, categoriesRef;
var init_products_DDA9Kbv3 = __esm({
  "dist/server/assets/products-DDA9Kbv3.js"() {
    "use strict";
    init_router_B40ruYtd();
    generateId = () => Math.random().toString(36).substr(2, 9);
    useProductsStore = create4()((set$1, get) => ({
      products: [],
      categories: [],
      loading: true,
      _setProducts: (products2) => set$1({ products: products2, loading: false }),
      _setCategories: (categories) => set$1({ categories }),
      addProduct: (productData) => {
        const id = generateId();
        const newProduct = { ...productData, id };
        set$1((state) => ({ products: [...state.products, newProduct] }));
        set2(ref2(rtdb, `products/${id}`), newProduct);
      },
      updateProduct: (id, updates) => {
        set$1((state) => ({
          products: state.products.map((p) => p.id === id ? { ...p, ...updates } : p)
        }));
        update2(ref2(rtdb, `products/${id}`), updates);
      },
      updateProductStock: (id, quantity) => {
        const product = get().products.find((p) => p.id === id);
        if (!product) return;
        const updates = {
          stockQuantity: quantity,
          inStock: quantity > 0 && product.inStock
          // Automatically disable if stock is 0, but keep "Live" status if possible
        };
        set$1((state) => ({
          products: state.products.map((p) => p.id === id ? { ...p, ...updates } : p)
        }));
        update2(ref2(rtdb, `products/${id}`), updates);
      },
      toggleStock: (id) => {
        const product = get().products.find((p) => p.id === id);
        if (!product) return;
        const newStockStatus = !product.inStock;
        set$1((state) => ({
          products: state.products.map(
            (p) => p.id === id ? { ...p, inStock: newStockStatus } : p
          )
        }));
        set2(ref2(rtdb, `products/${id}/inStock`), newStockStatus);
      },
      deleteProduct: (id) => {
        set$1((state) => ({ products: state.products.filter((p) => p.id !== id) }));
        remove2(ref2(rtdb, `products/${id}`));
      },
      addCategory: (name) => {
        const id = generateId();
        const newCategory = { id, name };
        set$1((state) => ({ categories: [...state.categories, newCategory] }));
        set2(ref2(rtdb, `categories/${id}`), newCategory);
      },
      removeCategory: (id) => {
        set$1((state) => ({ categories: state.categories.filter((c) => c.id !== id) }));
        remove2(ref2(rtdb, `categories/${id}`));
      }
    }));
    productsRef = ref2(rtdb, "products");
    onValue2(productsRef, (snapshot) => {
      const data = snapshot.val();
      if (data) {
        const products2 = Object.values(data);
        useProductsStore.getState()._setProducts(products2);
      } else {
        const seedData = {};
        products.forEach((p) => {
          seedData[p.id] = p;
        });
        set2(productsRef, seedData);
      }
    });
    categoriesRef = ref2(rtdb, "categories");
    onValue2(categoriesRef, (snapshot) => {
      const data = snapshot.val();
      if (data) {
        const categories = Object.values(data);
        useProductsStore.getState()._setCategories(categories);
      } else {
        const initialCategories = ["Idly Batter", "Dosa Batter", "Special Mixes", "Instant Mixes"];
        initialCategories.forEach((name) => {
          useProductsStore.getState().addCategory(name);
        });
      }
    });
  }
});

// dist/server/assets/index-BRS2E8Vh.js
var index_BRS2E8Vh_exports = {};
__export(index_BRS2E8Vh_exports, {
  component: () => Index
});
import { jsxs as jsxs4, jsx as jsx5, Fragment as Fragment2 } from "react/jsx-runtime";
import { Link as Link3, useNavigate as useNavigate2 } from "@tanstack/react-router";
import { ShoppingBag as ShoppingBag2, X as X2, Menu as Menu2, Sparkles, ArrowRight, ZoomIn, Zap, LayoutGrid, Minus, Plus, Leaf, Clock, Heart, Quote, Star, Phone, Mail, MapPin as MapPin2, Send, Instagram, Facebook, MessageCircle, Youtube, Twitter } from "lucide-react";
import { useState as useState4, useEffect as useEffect3, useMemo as useMemo2 } from "react";
import { AnimatePresence, motion as motion2 } from "framer-motion";
import { toast as toast3 } from "sonner";
import "zustand";
import "zustand/middleware";
import "clsx";
import "tailwind-merge";
import "firebase/database";
import "firebase/app";
import "firebase/auth";
import "firebase/firestore";
import "firebase/analytics";
import "@imagekit/javascript";
function Navbar() {
  const items = useCart((s) => s.items);
  const open = useCart((s) => s.open);
  const count = cartCount(items);
  const totalWeight = cartWeight(items);
  const isMinMet = totalWeight >= 1;
  const [scrolled, setScrolled] = useState4(false);
  const [mobileOpen, setMobileOpen] = useState4(false);
  useEffect3(() => {
    const onScroll = () => setScrolled(window.scrollY > 12);
    onScroll();
    window.addEventListener("scroll", onScroll);
    return () => window.removeEventListener("scroll", onScroll);
  }, []);
  return /* @__PURE__ */ jsxs4(
    "header",
    {
      className: `fixed top-0 inset-x-0 z-50 transition-all duration-300 ${scrolled ? "bg-background/85 backdrop-blur-md border-b border-border" : "bg-transparent"}`,
      children: [
        /* @__PURE__ */ jsxs4("div", { className: "container-px mx-auto max-w-7xl flex items-center justify-between h-16 md:h-20", children: [
          /* @__PURE__ */ jsxs4(Link3, { to: "/", className: "flex items-center gap-2.5 group", children: [
            /* @__PURE__ */ jsx5(Logo, { size: "sm" }),
            /* @__PURE__ */ jsxs4("div", { className: "leading-tight", children: [
              /* @__PURE__ */ jsx5(
                "div",
                {
                  className: `font-display font-black text-lg md:text-xl tracking-tight ${scrolled ? "text-navy" : "text-white"}`,
                  children: "H2 Batters"
                }
              ),
              /* @__PURE__ */ jsx5(
                "div",
                {
                  className: `text-[9px] md:text-[10px] uppercase tracking-[0.2em] font-black ${scrolled ? "text-muted-foreground" : "text-white/60"}`,
                  children: "Healthy & Homemade"
                }
              )
            ] })
          ] }),
          /* @__PURE__ */ jsx5("nav", { className: "hidden md:flex items-center gap-8", children: links.map((l) => /* @__PURE__ */ jsx5(
            "a",
            {
              href: l.href,
              className: `text-sm font-medium transition-colors hover:text-orange ${scrolled ? "text-foreground" : "text-white"}`,
              children: l.label
            },
            l.href
          )) }),
          /* @__PURE__ */ jsxs4("div", { className: "flex items-center gap-2", children: [
            /* @__PURE__ */ jsxs4(
              "button",
              {
                onClick: open,
                className: `relative grid place-items-center size-10 rounded-full transition-all duration-500 ${isMinMet ? "bg-orange text-navy scale-110 shadow-[0_0_20px_rgba(255,122,26,0.4)] ring-4 ring-orange/20 animate-bounce-subtle" : scrolled ? "bg-secondary text-foreground hover:bg-navy hover:text-white" : "bg-white/15 text-white hover:bg-orange hover:text-navy backdrop-blur"}`,
                "aria-label": "Open cart",
                children: [
                  /* @__PURE__ */ jsx5(ShoppingBag2, { className: "size-5" }),
                  count > 0 && /* @__PURE__ */ jsx5("span", { className: `absolute -top-1 -right-1 text-navy text-[10px] font-black size-5 rounded-full grid place-items-center transition-colors ${isMinMet ? "bg-white" : "bg-orange"}`, children: count })
                ]
              }
            ),
            /* @__PURE__ */ jsx5(
              "button",
              {
                onClick: () => setMobileOpen((v) => !v),
                className: `md:hidden grid place-items-center size-10 rounded-full ${scrolled ? "bg-secondary text-foreground" : "bg-white/15 text-white backdrop-blur"}`,
                "aria-label": "Menu",
                children: mobileOpen ? /* @__PURE__ */ jsx5(X2, { className: "size-5" }) : /* @__PURE__ */ jsx5(Menu2, { className: "size-5" })
              }
            )
          ] })
        ] }),
        /* @__PURE__ */ jsx5(AnimatePresence, { children: mobileOpen && /* @__PURE__ */ jsx5(
          motion2.div,
          {
            initial: { height: 0, opacity: 0 },
            animate: { height: "auto", opacity: 1 },
            exit: { height: 0, opacity: 0 },
            className: "md:hidden overflow-hidden bg-background border-t border-border",
            children: /* @__PURE__ */ jsx5("div", { className: "container-px py-4 flex flex-col gap-1", children: links.map((l) => /* @__PURE__ */ jsx5(
              "a",
              {
                href: l.href,
                onClick: () => setMobileOpen(false),
                className: "px-2 py-3 rounded-lg hover:bg-secondary text-foreground font-medium",
                children: l.label
              },
              l.href
            )) })
          }
        ) })
      ]
    }
  );
}
function getYouTubeId(url) {
  if (!url) return null;
  const patterns = [
    /(?:youtube\.com\/watch\?v=|youtu\.be\/|youtube\.com\/embed\/)([a-zA-Z0-9_-]{11})/,
    /youtube\.com\/shorts\/([a-zA-Z0-9_-]{11})/
  ];
  for (const p of patterns) {
    const m = url.match(p);
    if (m) return m[1];
  }
  return null;
}
function Hero() {
  const { heroVideoDesktop, heroVideoMobile, heroTagline, heroHeading, heroButtonText } = useSiteSettings();
  const desktopYoutubeId = getYouTubeId(heroVideoDesktop);
  const mobileYoutubeId = getYouTubeId(heroVideoMobile);
  const desktopEmbedUrl = desktopYoutubeId ? `https://www.youtube.com/embed/${desktopYoutubeId}?autoplay=1&mute=1&loop=1&playlist=${desktopYoutubeId}&controls=0&showinfo=0&rel=0&modestbranding=1&playsinline=1` : null;
  const mobileEmbedUrl = mobileYoutubeId ? `https://www.youtube.com/embed/${mobileYoutubeId}?autoplay=1&mute=1&loop=1&playlist=${mobileYoutubeId}&controls=0&showinfo=0&rel=0&modestbranding=1&playsinline=1` : null;
  return /* @__PURE__ */ jsxs4(
    "section",
    {
      id: "home",
      className: "relative h-[100svh] w-full overflow-hidden bg-navy text-white flex items-center justify-center text-center",
      children: [
        /* @__PURE__ */ jsxs4("div", { className: "absolute inset-0 z-0", children: [
          /* @__PURE__ */ jsx5("div", { className: "hidden md:block absolute inset-0", children: desktopEmbedUrl ? /* @__PURE__ */ jsx5(
            "iframe",
            {
              src: desktopEmbedUrl,
              className: "absolute inset-0 w-full h-full object-cover opacity-60 pointer-events-none",
              style: { border: "none", transform: "scale(1.2)", width: "100vw", height: "100vh" },
              allow: "autoplay; encrypted-media",
              title: "Hero desktop video"
            }
          ) : /* @__PURE__ */ jsx5(
            "video",
            {
              className: "absolute inset-0 w-full h-full object-cover opacity-60",
              autoPlay: true,
              muted: true,
              loop: true,
              playsInline: true,
              poster: getImageKitUrl("https://images.unsplash.com/photo-1668236543090-82eba5ee5976?w=1600&auto=format&fit=crop", 1600),
              children: /* @__PURE__ */ jsx5("source", { src: heroVideoDesktop, type: "video/mp4" })
            },
            heroVideoDesktop
          ) }),
          /* @__PURE__ */ jsx5("div", { className: "block md:hidden absolute inset-0", children: mobileEmbedUrl ? /* @__PURE__ */ jsx5(
            "iframe",
            {
              src: mobileEmbedUrl,
              className: "absolute inset-0 w-full h-full object-cover opacity-60 pointer-events-none",
              style: { border: "none", transform: "scale(1.5)", width: "100vw", height: "100vh" },
              allow: "autoplay; encrypted-media",
              title: "Hero mobile video"
            }
          ) : /* @__PURE__ */ jsx5(
            "video",
            {
              className: "absolute inset-0 w-full h-full object-cover opacity-60",
              autoPlay: true,
              muted: true,
              loop: true,
              playsInline: true,
              poster: getImageKitUrl("https://images.unsplash.com/photo-1668236543090-82eba5ee5976?w=1600&auto=format&fit=crop", 1600),
              children: /* @__PURE__ */ jsx5("source", { src: heroVideoMobile || heroVideoDesktop, type: "video/mp4" })
            },
            heroVideoMobile || heroVideoDesktop
          ) })
        ] }),
        /* @__PURE__ */ jsx5("div", { className: "absolute inset-0 bg-gradient-to-b from-navy/80 via-navy/40 to-navy z-10" }),
        /* @__PURE__ */ jsx5("div", { className: "absolute inset-0 bg-[radial-gradient(circle_at_center,rgba(255,122,26,0.15),transparent_70%)] z-10" }),
        /* @__PURE__ */ jsx5("div", { className: "absolute bottom-0 inset-x-0 h-64 bg-gradient-to-t from-navy via-navy/80 to-transparent z-10 pointer-events-none" }),
        /* @__PURE__ */ jsxs4("div", { className: "relative container-px mx-auto max-w-5xl z-20 flex flex-col items-center pt-20", children: [
          /* @__PURE__ */ jsxs4(
            motion2.div,
            {
              initial: { opacity: 0, scale: 0.9 },
              animate: { opacity: 1, scale: 1 },
              transition: { duration: 0.5 },
              className: "inline-flex items-center gap-2 px-4 py-2 rounded-full bg-white/10 backdrop-blur-md border border-white/20 text-[10px] md:text-xs uppercase tracking-[0.25em] font-black text-orange mb-8 shadow-2xl",
              children: [
                /* @__PURE__ */ jsx5(Sparkles, { className: "size-3.5 fill-orange" }),
                "Authentic \xB7 Traditional \xB7 Fresh"
              ]
            }
          ),
          /* @__PURE__ */ jsx5(
            motion2.h1,
            {
              initial: { opacity: 0, y: 30 },
              animate: { opacity: 1, y: 0 },
              transition: { duration: 0.8, delay: 0.1 },
              className: "font-display font-black fluid-h1 text-balance leading-[0.9] tracking-tighter",
              children: heroHeading || "Renuka's H2 Batters"
            }
          ),
          /* @__PURE__ */ jsx5(
            motion2.p,
            {
              initial: { opacity: 0, y: 20 },
              animate: { opacity: 1, y: 0 },
              transition: { duration: 0.7, delay: 0.25 },
              className: "mt-8 max-w-2xl text-lg md:text-2xl text-white/80 text-balance font-medium leading-relaxed px-4",
              children: heroTagline || "Fresh, hand-crafted idli & dosa batter \u2014 fermented to perfection and delivered to your door each morning."
            }
          ),
          /* @__PURE__ */ jsxs4(
            motion2.div,
            {
              initial: { opacity: 0, y: 20 },
              animate: { opacity: 1, y: 0 },
              transition: { duration: 0.7, delay: 0.4 },
              className: "mt-12 flex flex-col sm:flex-row items-center justify-center gap-4 w-full sm:w-auto px-6",
              children: [
                /* @__PURE__ */ jsxs4(
                  "a",
                  {
                    href: "#menu",
                    className: "group w-full sm:w-auto inline-flex items-center justify-center gap-3 bg-orange text-navy px-12 py-5 rounded-2xl font-black text-sm uppercase tracking-widest shadow-2xl shadow-orange/30 hover:shadow-orange/50 hover:scale-105 active:scale-95 transition-all",
                    children: [
                      heroButtonText || "Order Now",
                      /* @__PURE__ */ jsx5(ArrowRight, { className: "size-5 group-hover:translate-x-1 transition-transform" })
                    ]
                  }
                ),
                /* @__PURE__ */ jsx5(
                  "a",
                  {
                    href: "#about",
                    className: "w-full sm:w-auto inline-flex items-center justify-center gap-2 px-10 py-5 rounded-2xl font-black text-sm uppercase tracking-widest text-white border border-white/20 hover:bg-white/10 hover:border-white/40 transition-all backdrop-blur-md",
                    children: "Our Story"
                  }
                )
              ]
            }
          ),
          /* @__PURE__ */ jsx5(
            motion2.div,
            {
              initial: { opacity: 0, y: 20 },
              animate: { opacity: 1, y: 0 },
              transition: { duration: 0.7, delay: 0.6 },
              className: "mt-20 grid grid-cols-3 gap-8 md:gap-24 pt-12 border-t border-white/10 w-full",
              children: [
                { v: "10K+", l: "Happy homes" },
                { v: "100%", l: "Natural" },
                { v: "Daily", l: "Fresh" }
              ].map((s) => /* @__PURE__ */ jsxs4("div", { className: "flex flex-col items-center", children: [
                /* @__PURE__ */ jsx5("div", { className: "font-display font-black text-2xl md:text-4xl text-orange leading-none mb-2", children: s.v }),
                /* @__PURE__ */ jsx5("div", { className: "text-[10px] md:text-xs font-black uppercase tracking-widest text-white/30 whitespace-nowrap", children: s.l })
              ] }, s.l))
            }
          )
        ] })
      ]
    }
  );
}
function TodayMenu() {
  const todayMenu = useSiteSettings((s) => s.todayMenu);
  const [selectedImage, setSelectedImage] = useState4(null);
  if (!todayMenu || todayMenu.length === 0) return null;
  return /* @__PURE__ */ jsxs4("section", { id: "menu", className: "py-12 md:py-20 bg-background overflow-hidden", children: [
    /* @__PURE__ */ jsxs4("div", { className: "container-px mx-auto max-w-7xl", children: [
      /* @__PURE__ */ jsxs4(
        motion2.div,
        {
          initial: { opacity: 0, y: 20 },
          whileInView: { opacity: 1, y: 0 },
          viewport: { once: true },
          className: "text-center mb-10",
          children: [
            /* @__PURE__ */ jsx5("div", { className: "text-[10px] md:text-xs uppercase tracking-[0.25em] text-orange font-black mb-3", children: "Today's Menu" }),
            /* @__PURE__ */ jsx5("h2", { className: "font-display font-black text-3xl md:text-5xl text-navy", children: "Freshly prepared today" })
          ]
        }
      ),
      /* @__PURE__ */ jsx5("div", { className: "grid grid-cols-3 gap-3 md:gap-8 max-w-4xl mx-auto", children: todayMenu.slice(0, 3).map((item, i) => /* @__PURE__ */ jsxs4(
        motion2.div,
        {
          initial: { opacity: 0, y: 30 },
          whileInView: { opacity: 1, y: 0 },
          viewport: { once: true },
          transition: { delay: i * 0.1 },
          onClick: () => setSelectedImage(item.image),
          className: "relative aspect-[3/4] rounded-2xl md:rounded-[2.5rem] overflow-hidden group cursor-zoom-in shadow-xl shadow-navy/5 border border-border bg-secondary/30 transition-all hover:shadow-2xl hover:shadow-orange/10 hover:-translate-y-1 active:scale-95",
          children: [
            /* @__PURE__ */ jsx5(
              "img",
              {
                src: getImageKitUrl(item.image, 600),
                alt: "Today's Menu Item",
                className: "w-full h-full object-cover transition-transform duration-700 group-hover:scale-110"
              }
            ),
            /* @__PURE__ */ jsx5("div", { className: "absolute inset-0 bg-black/20 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center", children: /* @__PURE__ */ jsx5("div", { className: "size-10 rounded-full bg-white/20 backdrop-blur-md flex items-center justify-center text-white", children: /* @__PURE__ */ jsx5(ZoomIn, { className: "size-5" }) }) })
          ]
        },
        item.id
      )) })
    ] }),
    /* @__PURE__ */ jsx5(AnimatePresence, { children: selectedImage && /* @__PURE__ */ jsxs4(
      motion2.div,
      {
        initial: { opacity: 0 },
        animate: { opacity: 1 },
        exit: { opacity: 0 },
        className: "fixed inset-0 z-[100] bg-navy/95 backdrop-blur-xl flex items-center justify-center p-4 md:p-10",
        onClick: () => setSelectedImage(null),
        children: [
          /* @__PURE__ */ jsx5(
            "button",
            {
              className: "absolute top-6 right-6 size-12 rounded-full bg-white/10 flex items-center justify-center text-white hover:bg-white/20 transition-colors z-[110]",
              onClick: () => setSelectedImage(null),
              children: /* @__PURE__ */ jsx5(X2, { className: "size-6" })
            }
          ),
          /* @__PURE__ */ jsx5(
            motion2.div,
            {
              initial: { scale: 0.9, opacity: 0 },
              animate: { scale: 1, opacity: 1 },
              exit: { scale: 0.9, opacity: 0 },
              className: "relative max-w-full max-h-full rounded-3xl overflow-hidden shadow-2xl",
              onClick: (e) => e.stopPropagation(),
              children: /* @__PURE__ */ jsx5(
                "img",
                {
                  src: getImageKitUrl(selectedImage, 1200),
                  alt: "Full Menu Preview",
                  className: "w-auto h-auto max-w-full max-h-[85vh] object-contain rounded-2xl"
                }
              )
            }
          )
        ]
      }
    ) })
  ] });
}
function ProductCard({ p, i }) {
  const items = useCart((s) => s.items);
  const setQty = useCart((s) => s.setQty);
  const addKg = useCart((s) => s.addKg);
  const addHalfKg = useCart((s) => s.addHalfKg);
  const open = useCart((s) => s.open);
  const cartItem = items.find((it) => it.productId === p.id);
  const kg = cartItem?.kg ?? 0;
  const halfKg = cartItem?.halfKg ?? 0;
  const total = kg * p.pricePerKg + halfKg * p.pricePerHalfKg;
  const totalKg = kg + halfKg * 0.5;
  return /* @__PURE__ */ jsxs4(
    motion2.article,
    {
      layout: true,
      initial: { opacity: 0, y: 20 },
      whileInView: { opacity: 1, y: 0 },
      viewport: { once: true },
      transition: { duration: 0.5, delay: i * 0.05 },
      className: `group bg-white rounded-2xl md:rounded-[2rem] overflow-hidden border border-border/50 hover:border-orange/30 shadow-sm hover:shadow-2xl hover:shadow-navy/5 hover:-translate-y-1.5 transition-all duration-300 ${!p.inStock || p.stockQuantity <= 0 ? "opacity-75" : ""}`,
      children: [
        /* @__PURE__ */ jsxs4("div", { className: "relative aspect-[16/10] overflow-hidden bg-secondary", children: [
          /* @__PURE__ */ jsx5(
            "img",
            {
              src: getImageKitUrl(p.image, 600),
              alt: p.name,
              className: "absolute inset-0 w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
            }
          ),
          /* @__PURE__ */ jsx5("div", { className: "absolute top-2 left-2 bg-white/90 backdrop-blur text-navy text-[9px] font-black uppercase tracking-widest px-2 py-1 rounded-lg border border-navy/5", children: p.category }),
          /* @__PURE__ */ jsx5("div", { className: "absolute top-2 right-2 bg-orange text-navy shadow-lg px-3 py-1.5 rounded-xl border border-white/20 flex flex-col items-center leading-none", children: /* @__PURE__ */ jsxs4("div", { className: "font-display font-black text-base flex items-center gap-0.5", children: [
            /* @__PURE__ */ jsx5("span", { className: "text-[10px] font-bold mt-0.5", children: "\u20B9" }),
            p.pricePerKg,
            /* @__PURE__ */ jsx5("span", { className: "text-[8px] font-black ml-0.5 opacity-60", children: "/KG" })
          ] }) }),
          (!p.inStock || p.stockQuantity <= 0) && /* @__PURE__ */ jsx5("div", { className: "absolute inset-0 bg-navy/60 backdrop-blur-[2px] grid place-items-center", children: /* @__PURE__ */ jsx5("div", { className: "bg-red-500 text-white text-[10px] font-black px-4 py-2 rounded-xl rotate-[-5deg] shadow-lg border-2 border-white/10 uppercase tracking-widest", children: "OUT OF STOCK" }) })
        ] }),
        /* @__PURE__ */ jsxs4("div", { className: "p-3 md:p-4", children: [
          /* @__PURE__ */ jsxs4("div", { className: "flex justify-between items-center mb-1", children: [
            /* @__PURE__ */ jsx5("h3", { className: "font-display font-black text-base md:text-lg text-navy truncate flex-1 mr-2", children: p.name }),
            /* @__PURE__ */ jsx5("div", { className: `text-[8px] font-black uppercase tracking-widest px-1.5 py-0.5 rounded-md border ${p.stockQuantity < 5 ? "text-red-500 bg-red-50 border-red-100" : "text-green-600 bg-green-50 border-green-100"}`, children: p.stockQuantity > 0 ? `${p.stockQuantity} Left` : "Sold Out" })
          ] }),
          /* @__PURE__ */ jsxs4("div", { className: "mt-3 grid grid-cols-2 gap-2", children: [
            /* @__PURE__ */ jsx5(
              QtyControl,
              {
                label: "1 KG",
                value: kg,
                disabled: !p.inStock || p.stockQuantity <= 0,
                onMinus: () => setQty(p.id, Math.max(0, kg - 1), halfKg),
                onPlus: () => {
                  addKg(p);
                  toast3.success(`1 KG ${p.name} added`);
                }
              }
            ),
            /* @__PURE__ */ jsx5(
              QtyControl,
              {
                label: "\xBD KG",
                value: halfKg,
                disabled: !p.inStock || p.stockQuantity <= 0,
                onMinus: () => setQty(p.id, kg, Math.max(0, halfKg - 1)),
                onPlus: () => {
                  addHalfKg(p);
                  toast3.success(`\xBD KG ${p.name} added`);
                }
              }
            )
          ] }),
          /* @__PURE__ */ jsxs4("div", { className: "mt-4 pt-3 border-t border-secondary flex flex-col gap-2", children: [
            totalKg > 0 && totalKg < 1 && /* @__PURE__ */ jsx5("div", { className: "text-orange text-[9px] font-black uppercase tracking-[0.1em] text-center animate-pulse", children: "Min. 1 KG Required" }),
            /* @__PURE__ */ jsxs4("div", { className: "flex items-center justify-between gap-3", children: [
              /* @__PURE__ */ jsxs4("div", { className: "flex flex-col", children: [
                /* @__PURE__ */ jsx5("div", { className: "text-[8px] uppercase tracking-widest text-muted-foreground font-black leading-none mb-1", children: "Total" }),
                /* @__PURE__ */ jsxs4("div", { className: "font-display font-black text-xl text-navy flex items-baseline gap-0.5", children: [
                  /* @__PURE__ */ jsx5("span", { className: "text-orange text-xs", children: "\u20B9" }),
                  total || 0
                ] })
              ] }),
              /* @__PURE__ */ jsx5(
                "button",
                {
                  disabled: totalKg < 1 || !p.inStock || p.stockQuantity <= 0,
                  onClick: open,
                  className: `flex-1 h-10 rounded-xl text-[10px] uppercase tracking-widest font-black transition-all active:scale-95 shadow-md ${totalKg >= 1 ? "bg-orange text-navy shadow-orange/10" : "bg-navy text-white shadow-navy/5 opacity-50 grayscale cursor-not-allowed"}`,
                  children: totalKg < 1 && totalKg > 0 ? "Add more" : "Checkout"
                }
              )
            ] })
          ] })
        ] })
      ]
    }
  );
}
function QtyControl({
  label,
  value,
  disabled,
  onMinus,
  onPlus
}) {
  return /* @__PURE__ */ jsxs4("div", { className: `bg-secondary/40 rounded-xl p-1 flex items-center justify-between transition-opacity ${disabled ? "opacity-30 pointer-events-none" : ""}`, children: [
    /* @__PURE__ */ jsx5(
      "button",
      {
        type: "button",
        onClick: onMinus,
        disabled: value === 0 || disabled,
        className: "size-8 grid place-items-center rounded-lg bg-white text-navy shadow-sm hover:bg-navy hover:text-white disabled:opacity-30 transition-all active:scale-90",
        children: /* @__PURE__ */ jsx5(Minus, { className: "size-3" })
      }
    ),
    /* @__PURE__ */ jsxs4("div", { className: "text-center leading-none px-1", children: [
      /* @__PURE__ */ jsx5("div", { className: "font-display font-black text-sm text-navy", children: value }),
      /* @__PURE__ */ jsx5("div", { className: "text-[7px] font-black uppercase tracking-widest text-muted-foreground mt-0.5", children: label })
    ] }),
    /* @__PURE__ */ jsx5(
      "button",
      {
        type: "button",
        onClick: onPlus,
        disabled,
        className: "size-8 grid place-items-center rounded-lg bg-orange text-navy shadow-sm hover:shadow-orange/20 transition-all active:scale-90 disabled:opacity-30",
        children: /* @__PURE__ */ jsx5(Plus, { className: "size-3" })
      }
    )
  ] });
}
function Products() {
  const products2 = useProductsStore((s) => s.products);
  const [activeCategory, setActiveCategory] = useState4("All");
  const categories = useMemo2(() => {
    const cats = ["All", ...new Set(products2.map((p) => p.category).filter(Boolean))];
    return cats;
  }, [products2]);
  const groupedProducts = useMemo2(() => {
    const groups = {};
    const catsToProcess = activeCategory === "All" ? categories.filter((c) => c !== "All") : [activeCategory];
    catsToProcess.forEach((cat) => {
      groups[cat] = products2.filter((p) => p.category === cat);
    });
    return groups;
  }, [products2, activeCategory, categories]);
  return /* @__PURE__ */ jsx5("section", { id: "products", className: "py-12 md:py-20 bg-secondary/30 relative", children: /* @__PURE__ */ jsxs4("div", { className: "container-px mx-auto max-w-7xl", children: [
    /* @__PURE__ */ jsxs4("div", { className: "flex flex-col md:flex-row md:items-end justify-between gap-6 mb-12", children: [
      /* @__PURE__ */ jsxs4("div", { className: "max-w-2xl", children: [
        /* @__PURE__ */ jsxs4("div", { className: "inline-flex items-center gap-2 text-[10px] uppercase tracking-[0.2em] text-orange font-black px-3 py-1 rounded-full bg-orange/10 mb-3", children: [
          /* @__PURE__ */ jsx5(Zap, { className: "size-3 fill-orange" }),
          "Our Batters"
        ] }),
        /* @__PURE__ */ jsxs4("h2", { className: "font-display font-black text-3xl md:text-5xl text-navy text-balance leading-tight", children: [
          "Freshly ground, ",
          /* @__PURE__ */ jsx5("br", { className: "hidden md:block" }),
          " fermented for you."
        ] })
      ] }),
      /* @__PURE__ */ jsx5("div", { className: "flex flex-wrap gap-1.5", children: categories.map((cat) => /* @__PURE__ */ jsx5(
        "button",
        {
          onClick: () => setActiveCategory(cat),
          className: `px-4 py-2 rounded-full text-[10px] font-black uppercase tracking-widest transition-all ${activeCategory === cat ? "bg-navy text-white shadow-lg shadow-navy/20" : "bg-white text-navy hover:bg-orange/10 border border-border"}`,
          children: cat
        },
        cat
      )) })
    ] }),
    /* @__PURE__ */ jsx5("div", { className: "space-y-12 pb-16", children: /* @__PURE__ */ jsx5(AnimatePresence, { mode: "popLayout", children: Object.entries(groupedProducts).map(([category, catProducts]) => catProducts.length > 0 && /* @__PURE__ */ jsxs4(
      motion2.div,
      {
        layout: true,
        initial: { opacity: 0, y: 20 },
        animate: { opacity: 1, y: 0 },
        exit: { opacity: 0, y: -20 },
        transition: { duration: 0.5 },
        children: [
          /* @__PURE__ */ jsxs4("div", { className: "flex items-center gap-3 mb-6", children: [
            /* @__PURE__ */ jsx5("h3", { className: "font-display font-black text-xl md:text-3xl text-navy whitespace-nowrap uppercase tracking-tight", children: category }),
            /* @__PURE__ */ jsx5("div", { className: "h-px bg-navy/5 flex-1" })
          ] }),
          /* @__PURE__ */ jsx5("div", { className: "grid grid-cols-2 lg:grid-cols-3 gap-3 md:gap-6", children: catProducts.map((p, i) => /* @__PURE__ */ jsx5(ProductCard, { p, i }, p.id)) })
        ]
      },
      category
    )) }) }),
    Object.values(groupedProducts).every((g) => g.length === 0) && /* @__PURE__ */ jsxs4("div", { className: "mt-20 text-center py-16 bg-white/50 rounded-3xl border border-dashed border-border", children: [
      /* @__PURE__ */ jsx5(LayoutGrid, { className: "size-10 mx-auto text-muted-foreground/20 mb-3" }),
      /* @__PURE__ */ jsx5("h3", { className: "text-lg font-black text-navy", children: "No products found" }),
      /* @__PURE__ */ jsx5("p", { className: "text-xs text-muted-foreground", children: "Try a different category." })
    ] })
  ] }) });
}
function About() {
  return /* @__PURE__ */ jsx5("section", { id: "about", className: "py-12 md:py-20 bg-background overflow-hidden", children: /* @__PURE__ */ jsxs4("div", { className: "container-px mx-auto max-w-7xl grid lg:grid-cols-2 gap-10 lg:gap-20 items-center", children: [
    /* @__PURE__ */ jsxs4(
      motion2.div,
      {
        initial: { opacity: 0, scale: 0.95 },
        whileInView: { opacity: 1, scale: 1 },
        viewport: { once: true },
        transition: { duration: 0.6 },
        className: "relative",
        children: [
          /* @__PURE__ */ jsx5("div", { className: "aspect-[4/5] rounded-[2.5rem] overflow-hidden bg-secondary shadow-2xl shadow-navy/5 border border-border", children: /* @__PURE__ */ jsx5(
            "img",
            {
              src: getImageKitUrl("https://images.unsplash.com/photo-1631452180519-c014fe946bc7?w=1000&auto=format&fit=crop", 800),
              alt: "Traditional batter preparation",
              className: "w-full h-full object-cover transition-transform duration-700 hover:scale-110"
            }
          ) }),
          /* @__PURE__ */ jsxs4(
            motion2.div,
            {
              initial: { opacity: 0, y: 20 },
              whileInView: { opacity: 1, y: 0 },
              viewport: { once: true },
              transition: { delay: 0.3 },
              className: "hidden md:block absolute -bottom-6 -right-6 bg-orange text-navy p-8 rounded-[2rem] max-w-[240px] shadow-2xl shadow-orange/20 border-4 border-white",
              children: [
                /* @__PURE__ */ jsx5("div", { className: "font-display font-black text-4xl", children: "3 Gen." }),
                /* @__PURE__ */ jsx5("div", { className: "text-xs font-black uppercase tracking-widest mt-1 opacity-80 leading-tight", children: "Of perfecting our secret recipe" })
              ]
            }
          )
        ]
      }
    ),
    /* @__PURE__ */ jsxs4(
      motion2.div,
      {
        initial: { opacity: 0, y: 30 },
        whileInView: { opacity: 1, y: 0 },
        viewport: { once: true },
        transition: { duration: 0.6 },
        children: [
          /* @__PURE__ */ jsx5("div", { className: "text-[10px] md:text-xs uppercase tracking-[0.25em] text-orange font-black mb-4", children: "Our Heritage" }),
          /* @__PURE__ */ jsx5("h2", { className: "font-display font-black text-3xl md:text-5xl text-navy text-balance leading-[1.1]", children: "The taste you grew up with \u2014 delivered fresh." }),
          /* @__PURE__ */ jsx5("p", { className: "mt-6 text-muted-foreground text-base md:text-lg leading-relaxed", children: "What started in Renuka's home kitchen is now a small family-run obsession. We stone-grind premium urad dal and idli rice every single day, ferment it slowly overnight, and hand-pack it before sunrise." }),
          /* @__PURE__ */ jsx5("p", { className: "mt-4 text-muted-foreground text-base md:text-lg leading-relaxed", children: "No preservatives. No additives. Just real batter, the way it's supposed to taste." }),
          /* @__PURE__ */ jsx5("div", { className: "mt-10 grid sm:grid-cols-3 gap-3 md:gap-4", children: features.map((f, i) => /* @__PURE__ */ jsxs4(
            motion2.div,
            {
              initial: { opacity: 0, y: 20 },
              whileInView: { opacity: 1, y: 0 },
              viewport: { once: true },
              transition: { delay: i * 0.1 },
              className: "p-5 rounded-2xl bg-secondary/30 border border-border/50 group hover:bg-white hover:shadow-xl hover:shadow-navy/5 transition-all",
              children: [
                /* @__PURE__ */ jsx5("div", { className: "size-10 rounded-xl bg-orange grid place-items-center text-navy shadow-lg shadow-orange/20 group-hover:scale-110 transition-transform", children: /* @__PURE__ */ jsx5(f.icon, { className: "size-5" }) }),
                /* @__PURE__ */ jsx5("div", { className: "mt-4 font-display font-black text-navy text-sm uppercase tracking-tight", children: f.title }),
                /* @__PURE__ */ jsx5("div", { className: "mt-1.5 text-[10px] md:text-xs text-muted-foreground font-medium leading-relaxed", children: f.text })
              ]
            },
            f.title
          )) })
        ]
      }
    )
  ] }) });
}
function Reviews() {
  const reviews2 = useSiteSettings((s) => s.reviews);
  if (!reviews2 || reviews2.length === 0) return null;
  const slides = [...reviews2, ...reviews2];
  return /* @__PURE__ */ jsxs4("section", { id: "reviews", className: "py-12 md:py-20 bg-navy text-white relative overflow-hidden", children: [
    /* @__PURE__ */ jsx5("div", { className: "absolute inset-0 bg-[radial-gradient(circle_at_top_left,rgba(255,122,26,0.1),transparent_60%)]" }),
    /* @__PURE__ */ jsx5("div", { className: "relative container-px mx-auto max-w-7xl mb-12", children: /* @__PURE__ */ jsxs4(
      motion2.div,
      {
        initial: { opacity: 0, y: 20 },
        whileInView: { opacity: 1, y: 0 },
        viewport: { once: true },
        className: "max-w-2xl",
        children: [
          /* @__PURE__ */ jsx5("div", { className: "text-[10px] md:text-xs uppercase tracking-[0.25em] text-orange font-black mb-3", children: "Customer Love" }),
          /* @__PURE__ */ jsx5("h2", { className: "font-display font-black text-3xl md:text-6xl text-balance leading-none tracking-tight", children: "Loved by 10,000+ homes." })
        ]
      }
    ) }),
    /* @__PURE__ */ jsx5("div", { className: "relative flex overflow-hidden w-full group", children: /* @__PURE__ */ jsx5("div", { className: "flex gap-4 md:gap-6 py-4 animate-scroll whitespace-nowrap px-4 hover:[animation-play-state:paused]", children: slides.map((r, i) => /* @__PURE__ */ jsxs4(
      motion2.figure,
      {
        className: "w-[280px] md:w-[380px] bg-white/5 border border-white/10 backdrop-blur-md rounded-3xl p-6 md:p-8 shrink-0 transition-all hover:bg-white/10 hover:border-white/20 hover:scale-[1.02] shadow-2xl shadow-black/20",
        children: [
          /* @__PURE__ */ jsxs4("div", { className: "flex items-center justify-between mb-4", children: [
            /* @__PURE__ */ jsx5(Quote, { className: "size-6 md:size-8 text-orange opacity-50" }),
            /* @__PURE__ */ jsx5("div", { className: "flex gap-0.5", children: Array.from({ length: 5 }).map((_, idx) => /* @__PURE__ */ jsx5(
              Star,
              {
                className: `size-3 md:size-4 ${idx < r.rating ? "fill-orange text-orange" : "text-white/10"}`
              },
              idx
            )) })
          ] }),
          /* @__PURE__ */ jsxs4("blockquote", { className: "text-white/90 text-sm md:text-base leading-relaxed whitespace-normal italic font-medium", children: [
            '"',
            r.text,
            '"'
          ] }),
          /* @__PURE__ */ jsxs4("figcaption", { className: "mt-6 pt-6 border-t border-white/10 flex items-center gap-3", children: [
            /* @__PURE__ */ jsx5("div", { className: "size-10 rounded-full bg-orange/20 grid place-items-center text-orange font-black text-xs uppercase tracking-widest border border-orange/10", children: r.name.charAt(0) }),
            /* @__PURE__ */ jsxs4("div", { children: [
              /* @__PURE__ */ jsx5("div", { className: "font-display font-black text-sm uppercase tracking-tight", children: r.name }),
              /* @__PURE__ */ jsx5("div", { className: "text-[10px] text-white/40 font-bold uppercase tracking-widest", children: r.city })
            ] })
          ] })
        ]
      },
      `${r.id}-${i}`
    )) }) }),
    /* @__PURE__ */ jsx5("style", { children: `
        @keyframes scroll {
          0% { transform: translateX(0); }
          100% { transform: translateX(calc(-50% - 12px)); }
        }
        .animate-scroll {
          animation: scroll 40s linear infinite;
        }
        @media (max-width: 768px) {
          .animate-scroll {
            animation: scroll 25s linear infinite;
          }
        }
      ` })
  ] });
}
function Contact() {
  const [sending, setSending] = useState4(false);
  const { contactPhone, contactEmail, contactAddress } = useSiteSettings();
  const addEnquiry = useSiteSettings((s) => s.addEnquiry);
  const handleSubmit = (e) => {
    e.preventDefault();
    setSending(true);
    const form = new FormData(e.currentTarget);
    try {
      addEnquiry({
        name: form.get("name"),
        phone: form.get("phone"),
        email: form.get("email"),
        message: form.get("message")
      });
      toast3.success("Message sent! We'll get back to you soon.");
      e.target.reset();
    } catch (error) {
      toast3.error("Failed to send message. Please try again.");
    } finally {
      setSending(false);
    }
  };
  return /* @__PURE__ */ jsx5("section", { id: "contact", className: "py-12 md:py-20 bg-background", children: /* @__PURE__ */ jsxs4("div", { className: "container-px mx-auto max-w-7xl grid lg:grid-cols-5 gap-10 lg:gap-16", children: [
    /* @__PURE__ */ jsxs4(
      motion2.div,
      {
        initial: { opacity: 0, y: 30 },
        whileInView: { opacity: 1, y: 0 },
        viewport: { once: true },
        transition: { duration: 0.6 },
        className: "lg:col-span-2",
        children: [
          /* @__PURE__ */ jsx5("div", { className: "text-[10px] md:text-xs uppercase tracking-[0.25em] text-orange font-black mb-3", children: "Get In Touch" }),
          /* @__PURE__ */ jsx5("h2", { className: "font-display font-black text-3xl md:text-5xl text-navy text-balance leading-tight", children: "We'd love to hear from you." }),
          /* @__PURE__ */ jsx5("p", { className: "mt-6 text-muted-foreground leading-relaxed text-sm md:text-base", children: "Questions about our batters, bulk orders, or feedback \u2014 drop us a message and we'll get back within a few hours." }),
          /* @__PURE__ */ jsx5("div", { className: "mt-10 space-y-3", children: [
            { icon: Phone, label: "Call us", value: contactPhone },
            { icon: Mail, label: "Email", value: contactEmail },
            { icon: MapPin2, label: "Address", value: contactAddress }
          ].map((item, i) => /* @__PURE__ */ jsxs4(
            motion2.div,
            {
              initial: { opacity: 0, x: -20 },
              whileInView: { opacity: 1, x: 0 },
              viewport: { once: true },
              transition: { delay: 0.2 + i * 0.1 },
              className: "flex items-center gap-4 p-4 rounded-2xl border border-transparent hover:bg-secondary/50 hover:border-border transition-all",
              children: [
                /* @__PURE__ */ jsx5("div", { className: "size-12 rounded-xl bg-secondary grid place-items-center text-navy shadow-sm", children: /* @__PURE__ */ jsx5(item.icon, { className: "size-5" }) }),
                /* @__PURE__ */ jsxs4("div", { children: [
                  /* @__PURE__ */ jsx5("div", { className: "text-[9px] uppercase tracking-widest text-muted-foreground font-black mb-1", children: item.label }),
                  /* @__PURE__ */ jsx5("div", { className: "font-bold text-navy", children: item.value })
                ] })
              ]
            },
            item.label
          )) })
        ]
      }
    ),
    /* @__PURE__ */ jsxs4(
      motion2.form,
      {
        initial: { opacity: 0, y: 30 },
        whileInView: { opacity: 1, y: 0 },
        viewport: { once: true },
        transition: { duration: 0.6, delay: 0.2 },
        onSubmit: handleSubmit,
        className: "lg:col-span-3 bg-secondary/30 rounded-[2.5rem] p-6 md:p-10 border border-border shadow-2xl shadow-navy/5",
        children: [
          /* @__PURE__ */ jsxs4("div", { className: "grid sm:grid-cols-2 gap-4", children: [
            /* @__PURE__ */ jsx5(Field2, { label: "Name", name: "name", type: "text", required: true }),
            /* @__PURE__ */ jsx5(Field2, { label: "Phone", name: "phone", type: "tel", required: true })
          ] }),
          /* @__PURE__ */ jsx5("div", { className: "mt-4", children: /* @__PURE__ */ jsx5(Field2, { label: "Email", name: "email", type: "email" }) }),
          /* @__PURE__ */ jsxs4("div", { className: "mt-4", children: [
            /* @__PURE__ */ jsx5("label", { className: "block text-[10px] uppercase tracking-widest font-black text-muted-foreground mb-2", children: "Message" }),
            /* @__PURE__ */ jsx5(
              "textarea",
              {
                name: "message",
                required: true,
                rows: 5,
                className: "w-full bg-white border border-border rounded-2xl px-4 py-3 text-sm focus:outline-none focus:ring-4 focus:ring-orange/10 focus:border-orange/50 resize-none transition-all placeholder:text-muted-foreground/30",
                placeholder: "Tell us how we can help..."
              }
            )
          ] }),
          /* @__PURE__ */ jsxs4(
            "button",
            {
              type: "submit",
              disabled: sending,
              className: "mt-6 w-full sm:w-auto inline-flex items-center justify-center gap-2 bg-navy text-white px-10 py-4 rounded-2xl font-black uppercase tracking-widest text-xs shadow-xl shadow-navy/20 hover:bg-orange hover:text-navy hover:shadow-orange/20 transition-all disabled:opacity-60 active:scale-95",
              children: [
                sending ? "Sending..." : "Send Message",
                /* @__PURE__ */ jsx5(Send, { className: "size-4" })
              ]
            }
          )
        ]
      }
    )
  ] }) });
}
function Field2({
  label,
  name,
  type,
  required
}) {
  return /* @__PURE__ */ jsxs4("div", { children: [
    /* @__PURE__ */ jsxs4("label", { className: "block text-xs uppercase tracking-wider font-semibold text-muted-foreground mb-2", children: [
      label,
      " ",
      required && /* @__PURE__ */ jsx5("span", { className: "text-orange", children: "*" })
    ] }),
    /* @__PURE__ */ jsx5(
      "input",
      {
        name,
        type,
        required,
        className: "w-full bg-background border border-border rounded-xl px-4 py-3 text-sm focus:outline-none focus:ring-2 focus:ring-orange/40 focus:border-orange"
      }
    )
  ] });
}
function Footer() {
  const {
    contactPhone,
    contactEmail,
    contactAddress,
    footerDescription,
    footerCopyright,
    mapsLink,
    mapsLabel,
    socialLinks
  } = useSiteSettings();
  const socials = [
    { key: "instagram", icon: Instagram, href: socialLinks?.instagram, label: "Instagram" },
    { key: "facebook", icon: Facebook, href: socialLinks?.facebook, label: "Facebook" },
    { key: "whatsapp", icon: MessageCircle, href: socialLinks?.whatsapp ? `https://wa.me/${(socialLinks.whatsapp || "").replace(/\D/g, "")}` : "", label: "WhatsApp" },
    { key: "youtube", icon: Youtube, href: socialLinks?.youtube, label: "YouTube" },
    { key: "twitter", icon: Twitter, href: socialLinks?.twitter, label: "Twitter / X" }
  ].filter((s) => s.href);
  return /* @__PURE__ */ jsxs4("footer", { className: "bg-ink text-white/80", children: [
    /* @__PURE__ */ jsxs4("div", { className: "container-px mx-auto max-w-7xl py-12 md:py-16 grid md:grid-cols-4 gap-10", children: [
      /* @__PURE__ */ jsxs4("div", { className: "md:col-span-2", children: [
        /* @__PURE__ */ jsxs4("div", { className: "flex items-center gap-4", children: [
          /* @__PURE__ */ jsx5(Logo, { size: "md" }),
          /* @__PURE__ */ jsxs4("div", { children: [
            /* @__PURE__ */ jsx5("div", { className: "font-display font-black text-xl text-white tracking-tight", children: "H2 Batters" }),
            /* @__PURE__ */ jsx5("div", { className: "text-[10px] uppercase tracking-[0.2em] text-white/40 font-black", children: "Healthy & Homemade" })
          ] })
        ] }),
        /* @__PURE__ */ jsx5("p", { className: "mt-6 max-w-md text-sm text-white/50 leading-relaxed", children: footerDescription || "Stone-ground, naturally fermented batter delivered to your door every morning." }),
        socials.length > 0 && /* @__PURE__ */ jsx5("div", { className: "mt-6 flex gap-3 flex-wrap", children: socials.map(({ key, icon: Icon2, href, label }) => /* @__PURE__ */ jsx5(
          "a",
          {
            href,
            target: "_blank",
            rel: "noopener noreferrer",
            "aria-label": label,
            className: "size-10 grid place-items-center rounded-full bg-white/5 hover:bg-orange hover:text-navy transition-colors",
            children: /* @__PURE__ */ jsx5(Icon2, { className: "size-4" })
          },
          key
        )) }),
        mapsLink && /* @__PURE__ */ jsxs4(
          "a",
          {
            href: mapsLink,
            target: "_blank",
            rel: "noopener noreferrer",
            className: "mt-5 inline-flex items-center gap-2 text-xs text-orange hover:underline font-semibold",
            children: [
              /* @__PURE__ */ jsx5(MapPin2, { className: "size-3.5" }),
              mapsLabel || "Find us on Maps"
            ]
          }
        )
      ] }),
      /* @__PURE__ */ jsxs4("div", { children: [
        /* @__PURE__ */ jsx5("div", { className: "text-xs uppercase tracking-[0.18em] text-orange font-semibold", children: "Explore" }),
        /* @__PURE__ */ jsx5("ul", { className: "mt-4 space-y-2 text-sm", children: ["Home", "Products", "About", "Reviews", "Contact"].map((l) => /* @__PURE__ */ jsx5("li", { children: /* @__PURE__ */ jsx5(
          "a",
          {
            href: `#${l.toLowerCase()}`,
            className: "hover:text-orange transition-colors",
            children: l
          }
        ) }, l)) })
      ] }),
      /* @__PURE__ */ jsxs4("div", { children: [
        /* @__PURE__ */ jsx5("div", { className: "text-xs uppercase tracking-[0.18em] text-orange font-semibold", children: "Contact" }),
        /* @__PURE__ */ jsxs4("ul", { className: "mt-4 space-y-3 text-sm", children: [
          contactPhone && /* @__PURE__ */ jsxs4("li", { className: "flex items-center gap-2", children: [
            /* @__PURE__ */ jsx5(Phone, { className: "size-3.5 text-orange shrink-0" }),
            /* @__PURE__ */ jsx5("a", { href: `tel:${contactPhone}`, className: "hover:text-orange transition-colors", children: contactPhone })
          ] }),
          contactEmail && /* @__PURE__ */ jsxs4("li", { className: "flex items-center gap-2", children: [
            /* @__PURE__ */ jsx5(Mail, { className: "size-3.5 text-orange shrink-0" }),
            /* @__PURE__ */ jsx5("a", { href: `mailto:${contactEmail}`, className: "hover:text-orange transition-colors", children: contactEmail })
          ] }),
          contactAddress && /* @__PURE__ */ jsxs4("li", { className: "flex items-start gap-2", children: [
            /* @__PURE__ */ jsx5(MapPin2, { className: "size-3.5 text-orange shrink-0 mt-0.5" }),
            /* @__PURE__ */ jsx5("span", { className: "text-white/60", children: contactAddress })
          ] })
        ] })
      ] })
    ] }),
    /* @__PURE__ */ jsx5("div", { className: "border-t border-white/10", children: /* @__PURE__ */ jsxs4("div", { className: "container-px mx-auto max-w-7xl py-5 flex flex-col sm:flex-row items-center justify-between gap-3 text-xs text-white/50", children: [
      /* @__PURE__ */ jsxs4("div", { children: [
        "\xA9 ",
        (/* @__PURE__ */ new Date()).getFullYear(),
        " ",
        footerCopyright || "Renuka's H2 Batters. All rights reserved."
      ] }),
      /* @__PURE__ */ jsxs4("div", { className: "flex gap-4 font-medium text-white/70", children: [
        /* @__PURE__ */ jsx5("a", { href: "/admin", className: "hover:text-orange transition-colors", children: "Admin Login" }),
        /* @__PURE__ */ jsx5("a", { href: "/delivery", className: "hover:text-orange transition-colors", children: "Delivery Login" })
      ] }),
      /* @__PURE__ */ jsxs4("div", { children: [
        "Made by ",
        /* @__PURE__ */ jsx5("span", { className: "text-orange font-semibold", children: "WEBDEN" })
      ] })
    ] }) })
  ] });
}
function CartDrawer() {
  const isOpen = useCart((s) => s.isOpen);
  const close = useCart((s) => s.close);
  const items = useCart((s) => s.items);
  const setQty = useCart((s) => s.setQty);
  const remove5 = useCart((s) => s.remove);
  const navigate = useNavigate2();
  useEffect3(() => {
    if (isOpen) {
      document.body.style.overflow = "hidden";
    } else {
      document.body.style.overflow = "auto";
    }
    return () => {
      document.body.style.overflow = "auto";
    };
  }, [isOpen]);
  const total = cartTotal(items);
  const totalWeight = cartWeight(items);
  const isMinWeightMet = totalWeight >= 1;
  return /* @__PURE__ */ jsx5(AnimatePresence, { children: isOpen && /* @__PURE__ */ jsxs4(Fragment2, { children: [
    /* @__PURE__ */ jsx5(
      motion2.div,
      {
        initial: { opacity: 0 },
        animate: { opacity: 1 },
        exit: { opacity: 0 },
        onClick: close,
        className: "fixed inset-0 z-[10001] bg-navy/80 backdrop-blur-md"
      }
    ),
    /* @__PURE__ */ jsxs4(
      motion2.aside,
      {
        initial: { x: "100%" },
        animate: { x: 0 },
        exit: { x: "100%" },
        transition: { type: "spring", damping: 30, stiffness: 300 },
        className: "fixed right-0 top-0 bottom-0 z-[10002] w-full sm:w-[480px] bg-background shadow-[0_0_100px_rgba(0,0,0,0.5)] flex flex-col",
        children: [
          /* @__PURE__ */ jsxs4("div", { className: "flex items-center justify-between p-5 border-b border-border", children: [
            /* @__PURE__ */ jsxs4("div", { className: "flex items-center gap-3", children: [
              /* @__PURE__ */ jsx5("div", { className: "size-9 rounded-lg bg-orange grid place-items-center text-navy", children: /* @__PURE__ */ jsx5(ShoppingBag2, { className: "size-4" }) }),
              /* @__PURE__ */ jsxs4("div", { children: [
                /* @__PURE__ */ jsx5("div", { className: "font-display font-bold text-lg text-navy", children: "Your Cart" }),
                /* @__PURE__ */ jsxs4("div", { className: "text-xs text-muted-foreground", children: [
                  items.length,
                  " ",
                  items.length === 1 ? "item" : "items",
                  " \xB7 ",
                  totalWeight,
                  " KG"
                ] })
              ] })
            ] }),
            /* @__PURE__ */ jsx5(
              "button",
              {
                onClick: close,
                className: "size-9 grid place-items-center rounded-full hover:bg-secondary",
                children: /* @__PURE__ */ jsx5(X2, { className: "size-5" })
              }
            )
          ] }),
          /* @__PURE__ */ jsx5("div", { className: "flex-1 overflow-y-auto p-5 space-y-4", children: items.length === 0 ? /* @__PURE__ */ jsx5("div", { className: "h-full grid place-items-center text-center text-muted-foreground", children: /* @__PURE__ */ jsxs4("div", { children: [
            /* @__PURE__ */ jsx5(ShoppingBag2, { className: "size-12 mx-auto opacity-30" }),
            /* @__PURE__ */ jsx5("p", { className: "mt-3 text-sm", children: "Your cart is empty" })
          ] }) }) : items.map((it) => /* @__PURE__ */ jsxs4(
            "div",
            {
              className: "bg-secondary/50 rounded-2xl p-3 flex gap-3",
              children: [
                /* @__PURE__ */ jsx5(
                  "img",
                  {
                    src: it.image,
                    alt: it.name,
                    className: "size-20 rounded-xl object-cover flex-shrink-0"
                  }
                ),
                /* @__PURE__ */ jsxs4("div", { className: "flex-1 min-w-0", children: [
                  /* @__PURE__ */ jsxs4("div", { className: "flex items-start justify-between gap-2", children: [
                    /* @__PURE__ */ jsx5("div", { className: "font-display font-semibold text-navy text-sm leading-tight", children: it.name }),
                    /* @__PURE__ */ jsx5(
                      "button",
                      {
                        onClick: () => remove5(it.productId),
                        className: "text-muted-foreground hover:text-destructive text-xs",
                        children: "Remove"
                      }
                    )
                  ] }),
                  /* @__PURE__ */ jsxs4("div", { className: "mt-2 grid grid-cols-2 gap-2", children: [
                    /* @__PURE__ */ jsx5(
                      QtyMini,
                      {
                        label: "KG",
                        value: it.kg,
                        onChange: (v) => setQty(it.productId, v, it.halfKg)
                      }
                    ),
                    /* @__PURE__ */ jsx5(
                      QtyMini,
                      {
                        label: "\xBD KG",
                        value: it.halfKg,
                        onChange: (v) => setQty(it.productId, it.kg, v)
                      }
                    )
                  ] }),
                  /* @__PURE__ */ jsxs4("div", { className: "mt-2 flex items-center justify-between", children: [
                    /* @__PURE__ */ jsxs4("div", { className: "text-[10px] text-muted-foreground", children: [
                      "\u20B9",
                      it.pricePerKg,
                      "/KG \xB7 \u20B9",
                      it.pricePerHalfKg,
                      "/\xBDKG"
                    ] }),
                    /* @__PURE__ */ jsxs4("div", { className: "font-display font-bold text-navy", children: [
                      "\u20B9",
                      lineTotal(it)
                    ] })
                  ] })
                ] })
              ]
            },
            it.productId
          )) }),
          items.length > 0 && /* @__PURE__ */ jsxs4("div", { className: "border-t border-border p-5 bg-background space-y-4", children: [
            !isMinWeightMet && /* @__PURE__ */ jsxs4("div", { className: "bg-orange/10 border border-orange/20 rounded-xl p-3 text-center", children: [
              /* @__PURE__ */ jsx5("p", { className: "text-[10px] font-black uppercase tracking-widest text-orange animate-pulse", children: "Minimum order weight is 1 KG" }),
              /* @__PURE__ */ jsxs4("p", { className: "text-[9px] text-muted-foreground mt-0.5", children: [
                "Current weight: ",
                totalWeight,
                " KG. Please add more to proceed."
              ] })
            ] }),
            /* @__PURE__ */ jsxs4("div", { className: "flex items-center justify-between", children: [
              /* @__PURE__ */ jsx5("span", { className: "text-sm text-muted-foreground", children: "Total" }),
              /* @__PURE__ */ jsxs4("span", { className: "font-display font-bold text-3xl text-navy", children: [
                "\u20B9",
                total
              ] })
            ] }),
            /* @__PURE__ */ jsxs4(
              "button",
              {
                disabled: !isMinWeightMet,
                onClick: () => {
                  close();
                  navigate({ to: "/checkout" });
                },
                className: `w-full py-4 rounded-full font-black uppercase tracking-widest text-xs flex items-center justify-center gap-2 transition-all group ${isMinWeightMet ? "bg-navy text-white hover:bg-orange hover:text-navy shadow-xl shadow-navy/20" : "bg-secondary text-muted-foreground cursor-not-allowed opacity-60"}`,
                children: [
                  isMinWeightMet ? "Proceed to Checkout" : "Minimum 1 KG Required",
                  /* @__PURE__ */ jsx5(ArrowRight, { className: "size-4 group-hover:translate-x-1 transition-transform" })
                ]
              }
            )
          ] })
        ]
      }
    )
  ] }) });
}
function QtyMini({
  label,
  value,
  onChange
}) {
  return /* @__PURE__ */ jsxs4("div", { className: "bg-background rounded-lg flex items-center justify-between p-1", children: [
    /* @__PURE__ */ jsx5(
      "button",
      {
        onClick: () => onChange(Math.max(0, value - 1)),
        className: "size-7 grid place-items-center rounded-md hover:bg-secondary",
        children: /* @__PURE__ */ jsx5(Minus, { className: "size-3" })
      }
    ),
    /* @__PURE__ */ jsxs4("div", { className: "text-center leading-none", children: [
      /* @__PURE__ */ jsx5("div", { className: "font-bold text-sm text-navy", children: value }),
      /* @__PURE__ */ jsx5("div", { className: "text-[9px] uppercase text-muted-foreground", children: label })
    ] }),
    /* @__PURE__ */ jsx5(
      "button",
      {
        onClick: () => onChange(value + 1),
        className: "size-7 grid place-items-center rounded-md bg-orange text-navy",
        children: /* @__PURE__ */ jsx5(Plus, { className: "size-3" })
      }
    )
  ] });
}
function FloatingCart() {
  const items = useCart((s) => s.items);
  const open = useCart((s) => s.open);
  const isOpen = useCart((s) => s.isOpen);
  const count = cartCount(items);
  const total = cartTotal(items);
  const totalWeight = cartWeight(items);
  const isMinMet = totalWeight >= 1;
  return /* @__PURE__ */ jsx5(AnimatePresence, { children: count > 0 && !isOpen && /* @__PURE__ */ jsxs4(
    motion2.div,
    {
      initial: { y: 120, opacity: 0, scale: 0.9 },
      animate: { y: 0, opacity: 1, scale: 1 },
      exit: { y: 120, opacity: 0, scale: 0.9 },
      transition: { type: "spring", damping: 25, stiffness: 400 },
      className: "fixed bottom-4 left-4 right-4 md:left-1/2 md:-translate-x-1/2 md:w-[480px] z-[9999]",
      children: [
        /* @__PURE__ */ jsx5("div", { className: "absolute inset-0 bg-orange/20 blur-3xl -z-10 animate-pulse" }),
        /* @__PURE__ */ jsxs4("div", { className: "bg-navy/95 backdrop-blur-xl rounded-[2.5rem] shadow-[0_30px_70px_rgba(0,0,0,0.5)] border border-white/10 p-2.5 flex items-center justify-between gap-3 group/cart", children: [
          /* @__PURE__ */ jsxs4("div", { className: "flex items-center gap-4 pl-4", children: [
            /* @__PURE__ */ jsxs4("div", { className: "relative", children: [
              /* @__PURE__ */ jsx5("div", { className: `size-12 rounded-2xl bg-orange grid place-items-center text-navy shadow-lg shadow-orange/20 transition-transform ${isMinMet ? "animate-bounce-subtle" : "scale-95 grayscale"}`, children: /* @__PURE__ */ jsx5(ShoppingBag2, { className: "size-6" }) }),
              /* @__PURE__ */ jsx5(AnimatePresence, { children: count > 0 && /* @__PURE__ */ jsx5(
                motion2.span,
                {
                  initial: { scale: 0 },
                  animate: { scale: 1 },
                  className: "absolute -top-1.5 -right-1.5 bg-white text-navy text-[10px] font-black size-5 rounded-full grid place-items-center border-2 border-navy shadow-lg",
                  children: count
                }
              ) })
            ] }),
            /* @__PURE__ */ jsxs4("div", { className: "flex flex-col", children: [
              /* @__PURE__ */ jsxs4("div", { className: "text-white font-display font-black text-xl leading-none flex items-center gap-1.5", children: [
                "\u20B9",
                total
              ] }),
              /* @__PURE__ */ jsxs4("div", { className: "text-white/40 text-[10px] font-black uppercase tracking-widest mt-1", children: [
                totalWeight,
                " KG \xB7 ",
                count,
                " Items"
              ] })
            ] })
          ] }),
          /* @__PURE__ */ jsxs4(
            "button",
            {
              onClick: open,
              className: `h-14 px-10 rounded-full font-black uppercase tracking-widest text-xs flex items-center gap-2 transition-all active:scale-95 overflow-hidden relative ${isMinMet ? "bg-orange text-navy shadow-xl shadow-orange/20" : "bg-white/5 text-white/20 border border-white/5 cursor-not-allowed"}`,
              children: [
                isMinMet && /* @__PURE__ */ jsx5("div", { className: "absolute inset-0 bg-white/20 translate-x-[-100%] hover:translate-x-[100%] transition-transform duration-500 skew-x-12" }),
                /* @__PURE__ */ jsx5("span", { className: "relative flex items-center gap-2", children: isMinMet ? /* @__PURE__ */ jsxs4(Fragment2, { children: [
                  "View Cart",
                  /* @__PURE__ */ jsx5(ArrowRight, { className: "size-4 group-hover/cart:translate-x-1 transition-transform" })
                ] }) : "Add Min. 1 KG" })
              ]
            }
          )
        ] })
      ]
    }
  ) });
}
function Index() {
  return /* @__PURE__ */ jsxs4("main", { className: "bg-background text-foreground", children: [
    /* @__PURE__ */ jsx5(Navbar, {}),
    /* @__PURE__ */ jsx5(Hero, {}),
    /* @__PURE__ */ jsx5(TodayMenu, {}),
    /* @__PURE__ */ jsx5(Products, {}),
    /* @__PURE__ */ jsx5(About, {}),
    /* @__PURE__ */ jsx5(Reviews, {}),
    /* @__PURE__ */ jsx5(Contact, {}),
    /* @__PURE__ */ jsx5(Footer, {}),
    /* @__PURE__ */ jsx5(CartDrawer, {}),
    /* @__PURE__ */ jsx5(FloatingCart, {})
  ] });
}
var links, features;
var init_index_BRS2E8Vh = __esm({
  "dist/server/assets/index-BRS2E8Vh.js"() {
    "use strict";
    init_cart_CKZOh9VL();
    init_Logo_DpDS75JT();
    init_router_B40ruYtd();
    init_imagekit_78z04_ax();
    init_products_DDA9Kbv3();
    links = [
      { href: "/#menu", label: "Menu" },
      { href: "/#about", label: "About" },
      { href: "/#contact", label: "Contact" }
    ];
    features = [
      {
        icon: Leaf,
        title: "100% Natural",
        text: "No preservatives, no shortcuts. Just rice, urad dal & patience."
      },
      {
        icon: Clock,
        title: "Fermented Overnight",
        text: "Slow, traditional fermentation for that perfect tangy taste."
      },
      {
        icon: Heart,
        title: "Made With Love",
        text: "A family recipe passed down three generations."
      }
    ];
  }
});

// dist/server/assets/whatsapp-ClGNEJKh.js
import { jsx as jsx6 } from "react/jsx-runtime";
import * as React2 from "react";
var Input, openWhatsApp;
var init_whatsapp_ClGNEJKh = __esm({
  "dist/server/assets/whatsapp-ClGNEJKh.js"() {
    "use strict";
    init_utils_H80jjgLf();
    Input = React2.forwardRef(
      ({ className, type, ...props }, ref5) => {
        return /* @__PURE__ */ jsx6(
          "input",
          {
            type,
            className: cn(
              "flex h-9 w-full rounded-md border border-input bg-transparent px-3 py-1 text-base shadow-sm transition-colors file:border-0 file:bg-transparent file:text-sm file:font-medium file:text-foreground placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring disabled:cursor-not-allowed disabled:opacity-50 md:text-sm",
              className
            ),
            ref: ref5,
            ...props
          }
        );
      }
    );
    Input.displayName = "Input";
    openWhatsApp = (phone, message) => {
      let cleanPhone = phone.replace(/\D/g, "");
      if (cleanPhone.length === 10) {
        cleanPhone = "91" + cleanPhone;
      }
      if (cleanPhone.length < 10) {
        console.error("Invalid phone number for WhatsApp:", phone);
        return;
      }
      const url = `https://wa.me/${cleanPhone}?text=${encodeURIComponent(message)}`;
      window.open(url, "whatsapp_window");
    };
  }
});

// dist/server/assets/ErrorBoundary-BtGZJTax.js
import { jsxs as jsxs5, jsx as jsx7 } from "react/jsx-runtime";
import { Component } from "react";
import { AlertTriangle, RefreshCw, Home } from "lucide-react";
import { Link as Link4 } from "@tanstack/react-router";
var ErrorBoundary;
var init_ErrorBoundary_BtGZJTax = __esm({
  "dist/server/assets/ErrorBoundary-BtGZJTax.js"() {
    "use strict";
    ErrorBoundary = class extends Component {
      state = {
        hasError: false
      };
      static getDerivedStateFromError(error) {
        return { hasError: true, error };
      }
      componentDidCatch(error, errorInfo) {
        console.error("Uncaught error:", error, errorInfo);
      }
      render() {
        if (this.state.hasError) {
          if (this.fallback) {
            return this.fallback;
          }
          return /* @__PURE__ */ jsxs5("div", { className: "min-h-[400px] flex flex-col items-center justify-center p-8 text-center bg-white rounded-[2rem] border border-border shadow-sm m-4", children: [
            /* @__PURE__ */ jsx7("div", { className: "size-16 bg-red-50 rounded-full flex items-center justify-center mb-6", children: /* @__PURE__ */ jsx7(AlertTriangle, { className: "size-8 text-red-500" }) }),
            /* @__PURE__ */ jsx7("h2", { className: "text-2xl font-display font-bold text-navy mb-2", children: "Something went wrong" }),
            /* @__PURE__ */ jsx7("p", { className: "text-muted-foreground max-w-md mb-8", children: "An unexpected error occurred while rendering this component. We've been notified and are looking into it." }),
            /* @__PURE__ */ jsxs5("div", { className: "flex flex-wrap items-center justify-center gap-4", children: [
              /* @__PURE__ */ jsxs5(
                "button",
                {
                  onClick: () => window.location.reload(),
                  className: "inline-flex items-center gap-2 px-6 py-3 bg-navy text-white rounded-full font-bold hover:bg-orange hover:text-navy transition-all",
                  children: [
                    /* @__PURE__ */ jsx7(RefreshCw, { className: "size-4" }),
                    " Try Again"
                  ]
                }
              ),
              /* @__PURE__ */ jsxs5(
                Link4,
                {
                  to: "/",
                  className: "inline-flex items-center gap-2 px-6 py-3 border border-border rounded-full font-bold text-navy hover:bg-secondary transition-all",
                  children: [
                    /* @__PURE__ */ jsx7(Home, { className: "size-4" }),
                    " Go Home"
                  ]
                }
              )
            ] }),
            false
          ] });
        }
        return this.props.children;
      }
    };
  }
});

// dist/server/assets/index-DuJXXynU.js
var index_DuJXXynU_exports = {};
__export(index_DuJXXynU_exports, {
  component: () => DeliveryDashboard
});
import { jsx as jsx8, jsxs as jsxs6 } from "react/jsx-runtime";
import { useState as useState5, useMemo as useMemo3 } from "react";
import { Loader2 as Loader22, Calendar as Calendar2, Package as Package2, CheckCircle2 as CheckCircle22, TrendingUp, Wallet, CreditCard, MapPin as MapPin3, Phone as Phone2, MessageCircle as MessageCircle2, Navigation } from "lucide-react";
import { toast as toast4 } from "sonner";
import { format as format2 } from "date-fns";
import "zustand";
import "firebase/database";
import "@tanstack/react-router";
import "firebase/app";
import "firebase/auth";
import "firebase/firestore";
import "firebase/analytics";
import "zustand/middleware";
import "clsx";
import "tailwind-merge";
function DeliveryDashboard() {
  const partner = useDeliveryAuth((s) => s.currentPartner);
  const {
    orders,
    updateOrderStatus,
    updateOrderPaymentStatus,
    loading
  } = useOrders();
  const [selectedDate, setSelectedDate] = useState5(format2(/* @__PURE__ */ new Date(), "yyyy-MM-dd"));
  const filteredOrders = useMemo3(() => {
    if (!partner?.id || !orders) return [];
    const selectedDateStr = selectedDate;
    return (orders || []).filter((o) => {
      if (!o?.assignedPartnerId || o.assignedPartnerId !== partner.id) return false;
      if (!o?.date) return false;
      const oDateStr = o.date.split("T")[0];
      return oDateStr === selectedDateStr;
    });
  }, [orders, selectedDate, partner?.id]);
  const stats = useMemo3(() => {
    const pending = filteredOrders.filter((o) => o.status === "dispatched").length;
    const completed = filteredOrders.filter((o) => o.status === "delivered").length;
    const cashCollected = filteredOrders.filter((o) => o.paymentMethod === "Cash" && o.isPaid).reduce((acc, o) => acc + o.totalAmount, 0);
    const upiCollected = filteredOrders.filter((o) => o.paymentMethod === "UPI" && o.isPaid).reduce((acc, o) => acc + o.totalAmount, 0);
    return {
      pending,
      completed,
      cashCollected,
      upiCollected
    };
  }, [filteredOrders]);
  if (loading) {
    return /* @__PURE__ */ jsx8("div", { className: "h-[60vh] grid place-items-center", children: /* @__PURE__ */ jsx8(Loader22, { className: "size-10 animate-spin text-orange" }) });
  }
  if (!partner) return null;
  const handleComplete = (order) => {
    updateOrderStatus(order.uid, "delivered");
    toast4.success("Order marked as delivered!");
    openWhatsApp(order.phone, `Thanks ${order.customerName}! Your order ${order.id} has been successfully delivered by Renuka's H2 Batters. Enjoy!`);
  };
  return /* @__PURE__ */ jsx8(ErrorBoundary, { children: /* @__PURE__ */ jsxs6("div", { className: "space-y-6 pb-24", children: [
    /* @__PURE__ */ jsx8("div", { className: "flex flex-col gap-4", children: /* @__PURE__ */ jsxs6("div", { className: "flex items-center justify-between", children: [
      /* @__PURE__ */ jsx8("h2", { className: "font-display font-bold text-2xl text-navy", children: "Partner Portal" }),
      /* @__PURE__ */ jsxs6("div", { className: "bg-white border border-border rounded-xl px-3 py-1 flex items-center gap-2", children: [
        /* @__PURE__ */ jsx8(Calendar2, { className: "size-4 text-orange" }),
        /* @__PURE__ */ jsx8(Input, { type: "date", value: selectedDate, onChange: (e) => setSelectedDate(e.target.value), className: "border-none bg-transparent focus-visible:ring-0 h-8 text-xs font-bold" })
      ] })
    ] }) }),
    /* @__PURE__ */ jsxs6("div", { className: "grid grid-cols-2 gap-4", children: [
      /* @__PURE__ */ jsxs6("div", { className: "bg-navy text-white rounded-[2rem] p-5 shadow-lg shadow-navy/10 relative overflow-hidden", children: [
        /* @__PURE__ */ jsx8("div", { className: "text-[10px] uppercase tracking-wider text-white/50 font-bold mb-1", children: "Pending" }),
        /* @__PURE__ */ jsx8("div", { className: "text-3xl font-bold", children: stats.pending || 0 }),
        /* @__PURE__ */ jsx8(Package2, { className: "absolute -bottom-2 -right-2 size-16 opacity-10 rotate-12" })
      ] }),
      /* @__PURE__ */ jsxs6("div", { className: "bg-orange text-navy rounded-[2rem] p-5 shadow-lg shadow-orange/10 relative overflow-hidden", children: [
        /* @__PURE__ */ jsx8("div", { className: "text-[10px] uppercase tracking-wider text-navy/50 font-bold mb-1", children: "Delivered" }),
        /* @__PURE__ */ jsx8("div", { className: "text-3xl font-bold", children: stats.completed || 0 }),
        /* @__PURE__ */ jsx8(CheckCircle22, { className: "absolute -bottom-2 -right-2 size-16 opacity-10 rotate-12" })
      ] })
    ] }),
    /* @__PURE__ */ jsxs6("div", { className: "bg-white rounded-[2rem] p-6 border border-border shadow-sm", children: [
      /* @__PURE__ */ jsxs6("h3", { className: "text-sm font-bold text-navy uppercase tracking-widest mb-4 flex items-center gap-2", children: [
        /* @__PURE__ */ jsx8(TrendingUp, { className: "size-4 text-orange" }),
        "Collection Summary"
      ] }),
      /* @__PURE__ */ jsxs6("div", { className: "grid grid-cols-2 gap-6", children: [
        /* @__PURE__ */ jsxs6("div", { className: "flex items-center gap-3", children: [
          /* @__PURE__ */ jsx8("div", { className: "size-10 rounded-2xl bg-green-50 text-green-600 grid place-items-center", children: /* @__PURE__ */ jsx8(Wallet, { className: "size-5" }) }),
          /* @__PURE__ */ jsxs6("div", { children: [
            /* @__PURE__ */ jsx8("div", { className: "text-[10px] font-bold text-muted-foreground uppercase", children: "Cash" }),
            /* @__PURE__ */ jsxs6("div", { className: "text-lg font-bold text-navy", children: [
              "\u20B9",
              stats.cashCollected || 0
            ] })
          ] })
        ] }),
        /* @__PURE__ */ jsxs6("div", { className: "flex items-center gap-3", children: [
          /* @__PURE__ */ jsx8("div", { className: "size-10 rounded-2xl bg-blue-50 text-blue-600 grid place-items-center", children: /* @__PURE__ */ jsx8(CreditCard, { className: "size-5" }) }),
          /* @__PURE__ */ jsxs6("div", { children: [
            /* @__PURE__ */ jsx8("div", { className: "text-[10px] font-bold text-muted-foreground uppercase", children: "UPI" }),
            /* @__PURE__ */ jsxs6("div", { className: "text-lg font-bold text-navy", children: [
              "\u20B9",
              stats.upiCollected || 0
            ] })
          ] })
        ] })
      ] })
    ] }),
    /* @__PURE__ */ jsxs6("div", { children: [
      /* @__PURE__ */ jsx8("h3", { className: "font-display font-bold text-lg text-navy mb-4", children: "Assigned Routes" }),
      /* @__PURE__ */ jsxs6("div", { className: "space-y-4", children: [
        (filteredOrders || []).filter((o) => o.status === "dispatched").map((order) => /* @__PURE__ */ jsxs6("div", { className: "bg-white rounded-3xl p-5 border-2 border-orange/20 shadow-xl shadow-orange/5 relative overflow-hidden", children: [
          /* @__PURE__ */ jsxs6("div", { className: "flex justify-between items-start mb-4", children: [
            /* @__PURE__ */ jsxs6("div", { children: [
              /* @__PURE__ */ jsxs6("div", { className: "text-[10px] font-black text-orange uppercase tracking-widest mb-1", children: [
                "Order ",
                order.id
              ] }),
              /* @__PURE__ */ jsx8("div", { className: "font-display font-bold text-xl text-navy", children: order.customerName })
            ] }),
            /* @__PURE__ */ jsxs6("div", { className: "text-right", children: [
              /* @__PURE__ */ jsx8("div", { className: "text-[10px] font-bold text-muted-foreground uppercase mb-1", children: "Collect" }),
              /* @__PURE__ */ jsxs6("div", { className: "font-bold text-navy text-xl", children: [
                "\u20B9",
                order.totalAmount
              ] }),
              /* @__PURE__ */ jsx8("div", { className: `text-[10px] font-bold uppercase ${order.paymentMethod === "Cash" ? "text-green-600" : "text-blue-600"}`, children: order.paymentMethod })
            ] })
          ] }),
          /* @__PURE__ */ jsxs6("div", { className: "space-y-3 bg-secondary/30 p-4 rounded-2xl border border-secondary mb-5", children: [
            /* @__PURE__ */ jsxs6("div", { className: "flex items-start gap-3", children: [
              /* @__PURE__ */ jsx8(MapPin3, { className: "size-4 text-orange shrink-0 mt-1" }),
              /* @__PURE__ */ jsxs6("div", { className: "text-sm text-navy font-medium leading-relaxed", children: [
                order.address?.door,
                ", ",
                order.address?.apartment,
                ", ",
                order.address?.floor && `Floor ${order.address.floor}, `,
                order.address?.street
              ] })
            ] }),
            /* @__PURE__ */ jsxs6("div", { className: "flex items-center gap-3", children: [
              /* @__PURE__ */ jsx8(Phone2, { className: "size-4 text-orange shrink-0" }),
              /* @__PURE__ */ jsx8("div", { className: "text-sm text-navy font-bold", children: order.phone })
            ] })
          ] }),
          /* @__PURE__ */ jsxs6("div", { className: "flex flex-col gap-3", children: [
            /* @__PURE__ */ jsxs6("div", { className: "grid grid-cols-2 gap-2", children: [
              /* @__PURE__ */ jsxs6("a", { href: `tel:${order.phone}`, className: "flex justify-center items-center gap-2 py-3.5 rounded-2xl bg-secondary text-navy font-bold text-xs hover:bg-navy hover:text-white transition-all", children: [
                /* @__PURE__ */ jsx8(Phone2, { className: "size-4" }),
                " CALL"
              ] }),
              /* @__PURE__ */ jsxs6("button", { onClick: () => openWhatsApp(order.phone, `Hello ${order.customerName}, this is your delivery partner from Renuka's H2 Batters...`), className: "flex justify-center items-center gap-2 py-3.5 rounded-2xl bg-green-500 text-white font-bold text-xs hover:bg-green-600 transition-all shadow-lg shadow-green-500/20", children: [
                /* @__PURE__ */ jsx8(MessageCircle2, { className: "size-4" }),
                " WHATSAPP"
              ] })
            ] }),
            order.mapsLocation && /* @__PURE__ */ jsxs6("a", { href: `https://maps.google.com/?q=${order.mapsLocation}`, target: "_blank", className: "flex justify-center items-center gap-2 py-3.5 rounded-2xl bg-blue-500 text-white font-bold text-xs hover:bg-blue-600 transition-all shadow-lg shadow-blue-500/20", children: [
              /* @__PURE__ */ jsx8(Navigation, { className: "size-4" }),
              " NAVIGATE TO MAPS"
            ] }),
            /* @__PURE__ */ jsxs6("div", { className: "mt-2 pt-4 border-t border-secondary flex flex-col gap-3", children: [
              /* @__PURE__ */ jsxs6("label", { className: "flex items-center justify-between p-4 rounded-2xl bg-green-50 border border-green-100 cursor-pointer select-none", children: [
                /* @__PURE__ */ jsxs6("div", { className: "flex items-center gap-3", children: [
                  /* @__PURE__ */ jsx8("input", { type: "checkbox", checked: order.isPaid, onChange: (e) => updateOrderPaymentStatus(order.uid, e.target.checked, partner.name), className: "size-5 rounded border-green-300 text-green-600 focus:ring-green-500" }),
                  /* @__PURE__ */ jsx8("span", { className: "text-xs font-bold text-green-900 uppercase", children: "Payment Collected" })
                ] }),
                /* @__PURE__ */ jsxs6("div", { className: "font-bold text-green-700", children: [
                  "\u20B9",
                  order.totalAmount
                ] })
              ] }),
              /* @__PURE__ */ jsxs6("button", { disabled: !order.isPaid, onClick: () => handleComplete(order), className: "w-full bg-navy text-white py-5 rounded-[1.5rem] font-bold flex justify-center items-center gap-2 hover:bg-orange hover:text-navy transition-all disabled:opacity-20 disabled:grayscale", children: [
                /* @__PURE__ */ jsx8(CheckCircle22, { className: "size-5" }),
                " COMPLETE DELIVERY"
              ] })
            ] })
          ] })
        ] }, order.id)),
        (filteredOrders || []).filter((o) => o.status === "dispatched").length === 0 && /* @__PURE__ */ jsxs6("div", { className: "text-center py-20 bg-white rounded-[2rem] border border-dashed border-border text-muted-foreground shadow-sm", children: [
          /* @__PURE__ */ jsx8(Package2, { className: "size-12 mx-auto opacity-10 mb-4" }),
          /* @__PURE__ */ jsx8("p", { className: "font-bold text-navy/40 uppercase tracking-widest text-xs", children: "No pending deliveries" })
        ] })
      ] })
    ] }),
    (filteredOrders || []).filter((o) => o.status === "delivered").length > 0 && /* @__PURE__ */ jsxs6("div", { className: "mt-12", children: [
      /* @__PURE__ */ jsx8("h3", { className: "font-display font-bold text-lg text-navy mb-4 opacity-60", children: "Delivered Today" }),
      /* @__PURE__ */ jsx8("div", { className: "space-y-3", children: (filteredOrders || []).filter((o) => o.status === "delivered").map((order) => /* @__PURE__ */ jsxs6("div", { className: "bg-white/60 rounded-2xl p-4 border border-border flex justify-between items-center group", children: [
        /* @__PURE__ */ jsxs6("div", { children: [
          /* @__PURE__ */ jsx8("div", { className: "font-bold text-navy text-sm", children: order.customerName }),
          /* @__PURE__ */ jsxs6("div", { className: "text-[10px] text-muted-foreground font-bold uppercase tracking-wider", children: [
            order.id,
            " \xB7 ",
            order.address?.apartment || "Unknown"
          ] })
        ] }),
        /* @__PURE__ */ jsxs6("div", { className: "text-right", children: [
          /* @__PURE__ */ jsxs6("div", { className: "text-xs font-bold text-navy", children: [
            "\u20B9",
            order.totalAmount
          ] }),
          /* @__PURE__ */ jsxs6("div", { className: "flex items-center gap-1 text-green-600 text-[10px] font-bold uppercase", children: [
            /* @__PURE__ */ jsx8(CheckCircle22, { className: "size-3" }),
            " Delivered"
          ] })
        ] })
      ] }, order.id)) })
    ] })
  ] }) });
}
var init_index_DuJXXynU = __esm({
  "dist/server/assets/index-DuJXXynU.js"() {
    "use strict";
    init_orders_BJKg52UO();
    init_router_B40ruYtd();
    init_whatsapp_ClGNEJKh();
    init_ErrorBoundary_BtGZJTax();
  }
});

// dist/server/assets/order-success._id-DOhIX4X4.js
var order_success_id_DOhIX4X4_exports = {};
__export(order_success_id_DOhIX4X4_exports, {
  component: () => OrderSuccess
});
import { jsxs as jsxs7, jsx as jsx9 } from "react/jsx-runtime";
import { Link as Link5 } from "@tanstack/react-router";
import { CheckCircle2 as CheckCircle23, Phone as Phone3, ArrowRight as ArrowRight2 } from "lucide-react";
import { motion as motion3 } from "framer-motion";
import "sonner";
import "react";
import "zustand";
import "firebase/database";
import "firebase/app";
import "firebase/auth";
import "firebase/firestore";
import "firebase/analytics";
import "zustand/middleware";
function OrderSuccess() {
  const {
    id
  } = Route$9.useParams();
  return /* @__PURE__ */ jsxs7("div", { className: "min-h-screen bg-navy text-white relative overflow-hidden grid place-items-center px-5 py-16", children: [
    /* @__PURE__ */ jsx9("div", { className: "absolute inset-0 bg-[radial-gradient(ellipse_at_top,rgba(255,122,26,0.18),transparent_55%)]" }),
    /* @__PURE__ */ jsxs7(motion3.div, { initial: {
      opacity: 0,
      y: 30
    }, animate: {
      opacity: 1,
      y: 0
    }, transition: {
      duration: 0.6
    }, className: "relative max-w-lg w-full text-center", children: [
      /* @__PURE__ */ jsx9(motion3.div, { initial: {
        scale: 0
      }, animate: {
        scale: 1
      }, transition: {
        type: "spring",
        damping: 14,
        stiffness: 200,
        delay: 0.15
      }, className: "size-24 rounded-full bg-orange grid place-items-center mx-auto shadow-2xl shadow-orange/40", children: /* @__PURE__ */ jsx9(CheckCircle23, { className: "size-12 text-navy", strokeWidth: 2.5 }) }),
      /* @__PURE__ */ jsx9("h1", { className: "mt-8 font-display font-bold text-4xl md:text-5xl", children: "Order Confirmed!" }),
      /* @__PURE__ */ jsx9("p", { className: "mt-3 text-white/80 text-lg", children: "Thank you for ordering with us. Our team will contact you shortly to confirm the details." }),
      /* @__PURE__ */ jsxs7("div", { className: "mt-8 inline-block bg-white/10 backdrop-blur border border-white/15 rounded-2xl px-6 py-4", children: [
        /* @__PURE__ */ jsx9("div", { className: "text-xs uppercase tracking-[0.18em] text-orange font-semibold", children: "Your Order ID" }),
        /* @__PURE__ */ jsx9("div", { className: "mt-1 font-display font-bold text-3xl tracking-wider", children: id })
      ] }),
      /* @__PURE__ */ jsxs7("div", { className: "mt-8 flex items-center justify-center gap-3 text-sm text-white/70", children: [
        /* @__PURE__ */ jsx9(Phone3, { className: "size-4 text-orange" }),
        "We'll call you within 30 minutes to confirm."
      ] }),
      /* @__PURE__ */ jsx9("div", { className: "mt-10 flex flex-col sm:flex-row gap-3 justify-center", children: /* @__PURE__ */ jsxs7(Link5, { to: "/", className: "inline-flex items-center justify-center gap-2 bg-orange text-navy px-7 py-4 rounded-full font-bold hover:shadow-xl hover:shadow-orange/30 transition-all", children: [
        "Back to Home",
        /* @__PURE__ */ jsx9(ArrowRight2, { className: "size-4" })
      ] }) })
    ] })
  ] });
}
var init_order_success_id_DOhIX4X4 = __esm({
  "dist/server/assets/order-success._id-DOhIX4X4.js"() {
    "use strict";
    init_router_B40ruYtd();
  }
});

// dist/server/assets/deliveryPartners-DwkfBo1h.js
import { create as create5 } from "zustand";
import { remove as remove3, ref as ref3, update as update3, set as set3, onValue as onValue3 } from "firebase/database";
var useDeliveryPartners, partnersRef;
var init_deliveryPartners_DwkfBo1h = __esm({
  "dist/server/assets/deliveryPartners-DwkfBo1h.js"() {
    "use strict";
    init_router_B40ruYtd();
    useDeliveryPartners = create5()((set$1) => ({
      partners: [],
      loading: true,
      _setPartners: (partners) => set$1({ partners, loading: false }),
      addPartner: (partner) => {
        set$1((state) => ({ partners: [...state.partners, partner] }));
        set3(ref3(rtdb, `deliveryPartners/${partner.id}`), partner);
      },
      updatePartner: (id, updates) => {
        set$1((state) => ({
          partners: state.partners.map((p) => p.id === id ? { ...p, ...updates } : p)
        }));
        update3(ref3(rtdb, `deliveryPartners/${id}`), updates);
      },
      deletePartner: (id) => {
        set$1((state) => ({ partners: state.partners.filter((p) => p.id !== id) }));
        remove3(ref3(rtdb, `deliveryPartners/${id}`));
      }
    }));
    partnersRef = ref3(rtdb, "deliveryPartners");
    onValue3(partnersRef, (snapshot) => {
      const data = snapshot.val();
      if (data) {
        const partners = Object.values(data);
        useDeliveryPartners.getState()._setPartners(partners);
      } else {
        useDeliveryPartners.getState()._setPartners([]);
      }
    });
  }
});

// dist/server/assets/login-CWe5ffew.js
var login_CWe5ffew_exports = {};
__export(login_CWe5ffew_exports, {
  component: () => LoginPage
});
import { jsx as jsx10, jsxs as jsxs8 } from "react/jsx-runtime";
import { useRouter as useRouter3 } from "@tanstack/react-router";
import { useState as useState6 } from "react";
import { toast as toast5 } from "sonner";
import "zustand";
import "firebase/database";
import "firebase/app";
import "firebase/auth";
import "firebase/firestore";
import "firebase/analytics";
import "zustand/middleware";
import "@imagekit/javascript";
import "clsx";
import "tailwind-merge";
function LoginPage() {
  const partners = useDeliveryPartners((s) => s.partners);
  const login = useDeliveryAuth((s) => s.login);
  const router2 = useRouter3();
  const [loading, setLoading] = useState6(false);
  const handleLogin = (e) => {
    e.preventDefault();
    setLoading(true);
    const form = new FormData(e.currentTarget);
    const id = form.get("id");
    const passcode = form.get("passcode");
    setTimeout(() => {
      setLoading(false);
      const partner = partners.find((p) => p.id === id && p.passcode === passcode);
      if (partner) {
        login(partner);
        toast5.success(`Welcome back, ${partner.name}!`);
        router2.navigate({
          to: "/delivery"
        });
      } else {
        toast5.error("Invalid Partner ID or Passcode.");
      }
    }, 600);
  };
  return /* @__PURE__ */ jsx10("div", { className: "flex-1 flex flex-col items-center justify-center min-h-[80vh]", children: /* @__PURE__ */ jsxs8("div", { className: "w-full max-w-sm bg-card rounded-3xl border border-border p-8 shadow-xl shadow-navy/5", children: [
    /* @__PURE__ */ jsx10("div", { className: "flex justify-center mb-8", children: /* @__PURE__ */ jsx10(Logo, { size: "xl" }) }),
    /* @__PURE__ */ jsxs8("div", { className: "text-center mb-8", children: [
      /* @__PURE__ */ jsx10("h1", { className: "font-display font-bold text-2xl text-navy", children: "Partner Portal" }),
      /* @__PURE__ */ jsx10("p", { className: "text-muted-foreground text-sm mt-1", children: "Sign in to view your assigned deliveries." })
    ] }),
    /* @__PURE__ */ jsxs8("form", { onSubmit: handleLogin, className: "space-y-6", autoComplete: "off", children: [
      /* @__PURE__ */ jsxs8("div", { children: [
        /* @__PURE__ */ jsx10("label", { className: "block text-xs uppercase tracking-[0.2em] font-black text-navy/40 mb-2 ml-1", children: "Partner ID" }),
        /* @__PURE__ */ jsx10("input", { name: "id", required: true, autoComplete: "off", className: "w-full bg-secondary/50 border-2 border-transparent rounded-2xl px-5 py-4 text-sm font-bold text-navy focus:outline-none focus:border-orange focus:bg-white transition-all", placeholder: "e.g. DP001" })
      ] }),
      /* @__PURE__ */ jsxs8("div", { children: [
        /* @__PURE__ */ jsx10("label", { className: "block text-xs uppercase tracking-[0.2em] font-black text-navy/40 mb-2 ml-1", children: "Secure Passcode" }),
        /* @__PURE__ */ jsx10("input", { name: "passcode", type: "password", required: true, autoComplete: "new-password", className: "w-full bg-secondary/50 border-2 border-transparent rounded-2xl px-5 py-4 text-sm font-bold text-navy focus:outline-none focus:border-orange focus:bg-white transition-all", placeholder: "\u2022\u2022\u2022\u2022" })
      ] }),
      /* @__PURE__ */ jsx10("button", { type: "submit", disabled: loading, className: "w-full mt-4 bg-navy text-white py-4 rounded-2xl font-black uppercase tracking-widest hover:bg-orange hover:text-navy hover:scale-[1.02] active:scale-95 transition-all disabled:opacity-60 shadow-xl shadow-navy/10", children: loading ? "Authenticating..." : "Enter Portal" })
    ] })
  ] }) });
}
var init_login_CWe5ffew = __esm({
  "dist/server/assets/login-CWe5ffew.js"() {
    "use strict";
    init_deliveryPartners_DwkfBo1h();
    init_router_B40ruYtd();
    init_Logo_DpDS75JT();
  }
});

// dist/server/assets/MediaUpload-C6I_6V8U.js
import { jsxs as jsxs9, jsx as jsx11 } from "react/jsx-runtime";
import { useState as useState7, useRef as useRef2 } from "react";
import { Video, X as X3, Loader2 as Loader23, Upload, Link as Link6, CheckCircle } from "lucide-react";
import { toast as toast6 } from "sonner";
function MediaUpload({
  value,
  onChange,
  label = "Media",
  mediaType = "image",
  className = "",
  onClear,
  folder = "cms"
}) {
  const [urlInput, setUrlInput] = useState7(value || "");
  const [isUploading, setIsUploading] = useState7(false);
  const fileInputRef = useRef2(null);
  const isVideo = mediaType === "video" || value && /\.(mp4|webm|mov|ogg)$/i.test(value) || value && value.includes("youtube.com");
  const handleUrlApply = () => {
    if (!urlInput.trim()) return;
    onChange(urlInput.trim());
    toast6.success(`${label} URL applied!`);
  };
  const handleClear = () => {
    onChange("");
    setUrlInput("");
    onClear?.();
  };
  const handleFileChange = async (e) => {
    const file = e.target.files?.[0];
    if (!file) return;
    if (mediaType === "image" && !file.type.startsWith("image/")) {
      toast6.error("Please upload an image file.");
      return;
    }
    if (mediaType === "video" && !file.type.startsWith("video/")) {
      toast6.error("Please upload a video file.");
      return;
    }
    setIsUploading(true);
    const toastId = toast6.loading(`Uploading ${label}...`);
    try {
      const result = await uploadFile(file, folder);
      onChange(result.secure_url);
      toast6.success(`${label} uploaded successfully!`, { id: toastId });
    } catch (error) {
      console.error("Upload failed:", error);
      toast6.error(`Upload failed: ${error.message || "Unknown error"}`, { id: toastId });
    } finally {
      setIsUploading(false);
      if (fileInputRef.current) fileInputRef.current.value = "";
    }
  };
  return /* @__PURE__ */ jsxs9("div", { className: `space-y-3 ${className}`, children: [
    /* @__PURE__ */ jsx11("label", { className: "text-xs font-bold uppercase text-muted-foreground block", children: label }),
    value ? /* @__PURE__ */ jsxs9("div", { className: "relative rounded-2xl overflow-hidden bg-secondary border border-border group", children: [
      isVideo ? /* @__PURE__ */ jsx11("div", { className: "aspect-video w-full bg-black flex items-center justify-center", children: value.includes("youtube.com") || value.includes("youtu.be") ? /* @__PURE__ */ jsx11(Video, { className: "size-10 text-white/20" }) : /* @__PURE__ */ jsx11(
        "video",
        {
          src: value,
          className: "w-full h-full object-cover",
          muted: true,
          loop: true,
          playsInline: true
        }
      ) }) : /* @__PURE__ */ jsx11(
        "img",
        {
          src: value,
          alt: label,
          className: "w-full aspect-video object-cover"
        }
      ),
      /* @__PURE__ */ jsx11("div", { className: "absolute inset-0 bg-black/50 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center gap-4", children: /* @__PURE__ */ jsxs9(
        "button",
        {
          type: "button",
          onClick: handleClear,
          className: "bg-red-500 text-white px-4 py-2 rounded-xl text-xs font-bold flex items-center gap-2 hover:bg-red-600 transition-colors shadow-lg",
          children: [
            /* @__PURE__ */ jsx11(X3, { className: "size-4" }),
            " Remove"
          ]
        }
      ) })
    ] }) : /* @__PURE__ */ jsxs9("div", { className: "border border-border rounded-2xl overflow-hidden bg-secondary/30 p-4 space-y-4", children: [
      /* @__PURE__ */ jsxs9("div", { className: "grid grid-cols-2 gap-3", children: [
        /* @__PURE__ */ jsxs9(
          "button",
          {
            type: "button",
            disabled: isUploading,
            onClick: () => fileInputRef.current?.click(),
            className: "flex flex-col items-center justify-center gap-2 p-4 rounded-xl border-2 border-dashed border-border hover:border-orange hover:bg-orange/5 transition-all group",
            children: [
              isUploading ? /* @__PURE__ */ jsx11(Loader23, { className: "size-6 text-orange animate-spin" }) : /* @__PURE__ */ jsx11(Upload, { className: "size-6 text-muted-foreground group-hover:text-orange" }),
              /* @__PURE__ */ jsx11("span", { className: "text-xs font-bold text-navy", children: "Upload File" }),
              /* @__PURE__ */ jsx11(
                "input",
                {
                  type: "file",
                  ref: fileInputRef,
                  onChange: handleFileChange,
                  className: "hidden",
                  accept: mediaType === "image" ? "image/*" : mediaType === "video" ? "video/*" : "*/*"
                }
              )
            ]
          }
        ),
        /* @__PURE__ */ jsxs9("div", { className: "flex flex-col items-center justify-center gap-2 p-4 rounded-xl border-2 border-dashed border-border", children: [
          /* @__PURE__ */ jsx11(Link6, { className: "size-6 text-muted-foreground" }),
          /* @__PURE__ */ jsx11("span", { className: "text-xs font-bold text-navy", children: "Paste Link" })
        ] })
      ] }),
      /* @__PURE__ */ jsxs9("div", { className: "space-y-2", children: [
        /* @__PURE__ */ jsxs9("div", { className: "relative", children: [
          /* @__PURE__ */ jsx11(
            "input",
            {
              type: "url",
              value: urlInput,
              onChange: (e) => setUrlInput(e.target.value),
              placeholder: mediaType === "video" ? "YouTube or MP4 link" : "Image URL (PNG, JPG, etc.)",
              className: "w-full border rounded-xl p-3 pr-12 text-sm outline-none focus:border-orange focus:ring-2 focus:ring-orange/10 bg-white",
              onKeyDown: (e) => e.key === "Enter" && handleUrlApply()
            }
          ),
          /* @__PURE__ */ jsx11(
            "button",
            {
              type: "button",
              onClick: handleUrlApply,
              disabled: !urlInput.trim() || isUploading,
              className: "absolute right-2 top-1/2 -translate-y-1/2 size-8 bg-navy text-white rounded-lg flex items-center justify-center hover:bg-orange transition-colors disabled:opacity-40",
              children: /* @__PURE__ */ jsx11(CheckCircle, { className: "size-4" })
            }
          )
        ] }),
        /* @__PURE__ */ jsxs9("p", { className: "text-[10px] text-muted-foreground text-center", children: [
          "Powered by ",
          /* @__PURE__ */ jsx11("strong", { children: "ImageKit.io" })
        ] })
      ] })
    ] })
  ] });
}
var init_MediaUpload_C6I_6V8U = __esm({
  "dist/server/assets/MediaUpload-C6I_6V8U.js"() {
    "use strict";
    init_imagekit_78z04_ax();
  }
});

// dist/server/assets/products-BVhow1KF.js
var products_BVhow1KF_exports = {};
__export(products_BVhow1KF_exports, {
  component: () => ProductsPage
});
import { jsx as jsx12, jsxs as jsxs10 } from "react/jsx-runtime";
import { useState as useState8 } from "react";
import { Loader2 as Loader24, Tag, Trash2 as Trash22, Layers, Plus as Plus2, X as X4, Save, Edit } from "lucide-react";
import { toast as toast7 } from "sonner";
import "zustand";
import "firebase/database";
import "@tanstack/react-router";
import "firebase/app";
import "firebase/auth";
import "firebase/firestore";
import "firebase/analytics";
import "zustand/middleware";
import "@imagekit/javascript";
function ProductsPage() {
  const {
    products: products2,
    categories,
    loading,
    toggleStock,
    deleteProduct,
    addProduct,
    updateProduct,
    addCategory,
    removeCategory
  } = useProductsStore();
  const [isAdding, setIsAdding] = useState8(false);
  const [isAddingCategory, setIsAddingCategory] = useState8(false);
  const [editingProduct, setEditingProduct] = useState8(null);
  const [newProductImage, setNewProductImage] = useState8("");
  const [editingProductImage, setEditingProductImage] = useState8("");
  if (loading) {
    return /* @__PURE__ */ jsx12("div", { className: "h-[60vh] grid place-items-center", children: /* @__PURE__ */ jsxs10("div", { className: "flex flex-col items-center gap-4", children: [
      /* @__PURE__ */ jsx12(Loader24, { className: "size-10 animate-spin text-orange" }),
      /* @__PURE__ */ jsx12("p", { className: "text-muted-foreground animate-pulse", children: "Loading product catalog..." })
    ] }) });
  }
  return /* @__PURE__ */ jsx12(ErrorBoundary, { children: /* @__PURE__ */ jsxs10("div", { className: "space-y-10", children: [
    /* @__PURE__ */ jsxs10("section", { className: "bg-white rounded-3xl border border-border overflow-hidden shadow-sm", children: [
      /* @__PURE__ */ jsxs10("div", { className: "p-6 border-b border-border bg-secondary/30 flex items-center justify-between", children: [
        /* @__PURE__ */ jsxs10("div", { className: "flex items-center gap-3", children: [
          /* @__PURE__ */ jsx12(Tag, { className: "size-5 text-orange" }),
          /* @__PURE__ */ jsx12("h2", { className: "font-bold text-xl text-navy", children: "Manage Categories" })
        ] }),
        /* @__PURE__ */ jsx12("button", { onClick: () => setIsAddingCategory(!isAddingCategory), className: "text-xs font-bold uppercase tracking-widest text-navy hover:text-orange transition-colors", children: isAddingCategory ? "Close" : "+ Add New Category" })
      ] }),
      /* @__PURE__ */ jsxs10("div", { className: "p-6 space-y-6", children: [
        isAddingCategory && /* @__PURE__ */ jsxs10("form", { className: "flex gap-3 bg-secondary/20 p-4 rounded-2xl border border-border", onSubmit: (e) => {
          e.preventDefault();
          const form = new FormData(e.currentTarget);
          const name = form.get("categoryName");
          if (!name) return;
          addCategory(name);
          setIsAddingCategory(false);
          toast7.success(`Category "${name}" created!`);
        }, children: [
          /* @__PURE__ */ jsx12("input", { name: "categoryName", placeholder: "e.g. Dosa Batter", required: true, className: "flex-1 bg-white border border-border rounded-xl px-4 py-2 text-sm outline-none focus:border-orange" }),
          /* @__PURE__ */ jsx12("button", { type: "submit", className: "bg-navy text-white px-6 rounded-xl font-bold text-sm hover:bg-orange transition-colors", children: "Create" })
        ] }),
        /* @__PURE__ */ jsxs10("div", { className: "flex flex-wrap gap-3", children: [
          (categories || []).map((cat) => /* @__PURE__ */ jsxs10("div", { className: "flex items-center gap-2 bg-secondary/50 border border-border px-4 py-2 rounded-xl group transition-all hover:border-orange/50", children: [
            /* @__PURE__ */ jsx12("span", { className: "font-bold text-navy text-sm", children: cat.name }),
            /* @__PURE__ */ jsx12("button", { onClick: () => {
              if (confirm(`Remove category "${cat.name}"? Products in this category will remain but will be uncategorized.`)) {
                removeCategory(cat.id);
              }
            }, className: "text-muted-foreground hover:text-red-500 opacity-0 group-hover:opacity-100 transition-opacity", children: /* @__PURE__ */ jsx12(Trash22, { className: "size-3.5" }) })
          ] }, cat.id)),
          (categories || []).length === 0 && /* @__PURE__ */ jsx12("p", { className: "text-sm text-muted-foreground italic", children: "No categories created yet. Create one to add products." })
        ] })
      ] })
    ] }),
    /* @__PURE__ */ jsxs10("div", { className: "space-y-6", children: [
      /* @__PURE__ */ jsxs10("div", { className: "flex flex-col sm:flex-row sm:items-center justify-between gap-4", children: [
        /* @__PURE__ */ jsxs10("div", { className: "flex items-center gap-3", children: [
          /* @__PURE__ */ jsx12(Layers, { className: "size-5 text-orange" }),
          /* @__PURE__ */ jsx12("h2", { className: "font-bold text-xl md:text-2xl text-navy", children: "Product Catalog" })
        ] }),
        /* @__PURE__ */ jsxs10("button", { onClick: () => {
          if ((categories || []).length === 0) {
            toast7.error("Please create at least one category first.");
            setIsAddingCategory(true);
            return;
          }
          setEditingProduct(null);
          setIsAdding(!isAdding);
        }, className: "bg-navy text-white px-5 py-2.5 rounded-full font-bold hover:bg-orange transition-all flex items-center justify-center gap-2 shadow-lg shadow-navy/10 active:scale-95", children: [
          /* @__PURE__ */ jsx12(Plus2, { className: "size-4" }),
          " Add Product"
        ] })
      ] }),
      isAdding && /* @__PURE__ */ jsxs10("form", { className: "bg-white p-8 rounded-3xl border-2 border-orange/20 grid sm:grid-cols-2 gap-6 shadow-xl relative", onSubmit: (e) => {
        e.preventDefault();
        const form = new FormData(e.currentTarget);
        addProduct({
          name: form.get("name"),
          description: form.get("description"),
          image: newProductImage,
          pricePerKg: Number(form.get("pricePerKg")),
          pricePerHalfKg: Number(form.get("pricePerHalfKg")),
          category: form.get("category"),
          stockQuantity: Number(form.get("stockQuantity")) || 0,
          inStock: true
        });
        setIsAdding(false);
        setNewProductImage("");
        toast7.success("Product added successfully!");
      }, children: [
        /* @__PURE__ */ jsxs10("div", { className: "sm:col-span-2 flex items-center justify-between mb-2", children: [
          /* @__PURE__ */ jsx12("h3", { className: "font-bold text-navy text-lg", children: "New Product Details" }),
          /* @__PURE__ */ jsx12("button", { type: "button", onClick: () => setIsAdding(false), className: "text-muted-foreground hover:text-navy", children: /* @__PURE__ */ jsx12(X4, { className: "size-5" }) })
        ] }),
        /* @__PURE__ */ jsxs10("div", { className: "space-y-2", children: [
          /* @__PURE__ */ jsx12("label", { className: "text-xs font-bold uppercase text-muted-foreground", children: "Category" }),
          /* @__PURE__ */ jsxs10("select", { name: "category", required: true, className: "w-full border rounded-xl p-3 bg-secondary/20 font-bold text-navy outline-none focus:border-orange", children: [
            /* @__PURE__ */ jsx12("option", { value: "", children: "Select Category" }),
            (categories || []).map((c) => /* @__PURE__ */ jsx12("option", { value: c.name, children: c.name }, c.id))
          ] })
        ] }),
        /* @__PURE__ */ jsxs10("div", { className: "space-y-2", children: [
          /* @__PURE__ */ jsx12("label", { className: "text-xs font-bold uppercase text-muted-foreground", children: "Product Name" }),
          /* @__PURE__ */ jsx12("input", { name: "name", required: true, placeholder: "e.g. Special Dosa Batter", className: "w-full border rounded-xl p-3 outline-none focus:border-orange" })
        ] }),
        /* @__PURE__ */ jsx12("div", { className: "sm:col-span-2", children: /* @__PURE__ */ jsx12(MediaUpload, { label: "Product Image", value: newProductImage, onChange: setNewProductImage }) }),
        /* @__PURE__ */ jsxs10("div", { className: "space-y-2", children: [
          /* @__PURE__ */ jsx12("label", { className: "text-xs font-bold uppercase text-muted-foreground", children: "Initial Stock Quantity" }),
          /* @__PURE__ */ jsx12("input", { type: "number", name: "stockQuantity", defaultValue: 50, required: true, className: "w-full border rounded-xl p-3 outline-none focus:border-orange" })
        ] }),
        /* @__PURE__ */ jsxs10("div", { className: "grid grid-cols-2 gap-4", children: [
          /* @__PURE__ */ jsxs10("div", { className: "space-y-2", children: [
            /* @__PURE__ */ jsx12("label", { className: "text-xs font-bold uppercase text-muted-foreground", children: "Price 1KG (\u20B9)" }),
            /* @__PURE__ */ jsx12("input", { type: "number", name: "pricePerKg", required: true, className: "w-full border rounded-xl p-3 outline-none focus:border-orange" })
          ] }),
          /* @__PURE__ */ jsxs10("div", { className: "space-y-2", children: [
            /* @__PURE__ */ jsx12("label", { className: "text-xs font-bold uppercase text-muted-foreground", children: "Price \xBDKG (\u20B9)" }),
            /* @__PURE__ */ jsx12("input", { type: "number", name: "pricePerHalfKg", required: true, className: "w-full border rounded-xl p-3 outline-none focus:border-orange" })
          ] })
        ] }),
        /* @__PURE__ */ jsxs10("div", { className: "space-y-2", children: [
          /* @__PURE__ */ jsx12("label", { className: "text-xs font-bold uppercase text-muted-foreground", children: "Description" }),
          /* @__PURE__ */ jsx12("textarea", { name: "description", required: true, rows: 3, className: "w-full border rounded-xl p-3 outline-none focus:border-orange" })
        ] }),
        /* @__PURE__ */ jsxs10("div", { className: "sm:col-span-2 flex justify-end gap-3 pt-4 border-t border-border", children: [
          /* @__PURE__ */ jsx12("button", { type: "button", onClick: () => setIsAdding(false), className: "px-6 py-3 rounded-full border border-border font-bold hover:bg-secondary transition-colors", children: "Cancel" }),
          /* @__PURE__ */ jsxs10("button", { type: "submit", className: "px-10 py-3 rounded-full bg-navy text-white font-bold hover:bg-orange hover:text-navy transition-all shadow-lg shadow-navy/10 flex items-center gap-2", children: [
            /* @__PURE__ */ jsx12(Save, { className: "size-4" }),
            " Save & Publish"
          ] })
        ] })
      ] }),
      editingProduct && /* @__PURE__ */ jsxs10("form", { className: "bg-white p-8 rounded-3xl border-2 border-blue-200 grid sm:grid-cols-2 gap-6 shadow-xl relative", onSubmit: (e) => {
        e.preventDefault();
        const form = new FormData(e.currentTarget);
        updateProduct(editingProduct.id, {
          name: form.get("name"),
          description: form.get("description"),
          image: editingProductImage || editingProduct.image,
          pricePerKg: Number(form.get("pricePerKg")),
          pricePerHalfKg: Number(form.get("pricePerHalfKg")),
          category: form.get("category"),
          stockQuantity: Number(form.get("stockQuantity")),
          inStock: form.get("inStock") === "true"
        });
        setEditingProduct(null);
        setEditingProductImage("");
        toast7.success("\u2705 Product updated! Changes are live on the website.");
      }, children: [
        /* @__PURE__ */ jsxs10("div", { className: "sm:col-span-2 flex items-center justify-between mb-2", children: [
          /* @__PURE__ */ jsxs10("div", { children: [
            /* @__PURE__ */ jsx12("h3", { className: "font-bold text-navy text-lg", children: "Edit Product" }),
            /* @__PURE__ */ jsxs10("p", { className: "text-xs text-muted-foreground", children: [
              "Editing: ",
              /* @__PURE__ */ jsx12("span", { className: "font-bold text-orange", children: editingProduct.name })
            ] })
          ] }),
          /* @__PURE__ */ jsx12("button", { type: "button", onClick: () => setEditingProduct(null), className: "text-muted-foreground hover:text-navy", children: /* @__PURE__ */ jsx12(X4, { className: "size-5" }) })
        ] }),
        /* @__PURE__ */ jsxs10("div", { className: "space-y-2", children: [
          /* @__PURE__ */ jsx12("label", { className: "text-xs font-bold uppercase text-muted-foreground", children: "Category" }),
          /* @__PURE__ */ jsx12("select", { name: "category", defaultValue: editingProduct.category, className: "w-full border rounded-xl p-3 bg-secondary/20 font-bold text-navy outline-none focus:border-orange", children: (categories || []).map((c) => /* @__PURE__ */ jsx12("option", { value: c.name, children: c.name }, c.id)) })
        ] }),
        /* @__PURE__ */ jsxs10("div", { className: "space-y-2", children: [
          /* @__PURE__ */ jsx12("label", { className: "text-xs font-bold uppercase text-muted-foreground", children: "Product Name" }),
          /* @__PURE__ */ jsx12("input", { name: "name", required: true, defaultValue: editingProduct.name, className: "w-full border rounded-xl p-3 outline-none focus:border-orange" })
        ] }),
        /* @__PURE__ */ jsx12("div", { className: "sm:col-span-2", children: /* @__PURE__ */ jsx12(MediaUpload, { label: "Product Image", value: editingProductImage || editingProduct.image, onChange: setEditingProductImage }) }),
        /* @__PURE__ */ jsxs10("div", { className: "space-y-2", children: [
          /* @__PURE__ */ jsx12("label", { className: "text-xs font-bold uppercase text-muted-foreground", children: "Stock Quantity" }),
          /* @__PURE__ */ jsx12("input", { type: "number", name: "stockQuantity", required: true, defaultValue: editingProduct.stockQuantity, className: "w-full border rounded-xl p-3 outline-none focus:border-orange" })
        ] }),
        /* @__PURE__ */ jsxs10("div", { className: "grid grid-cols-2 gap-4", children: [
          /* @__PURE__ */ jsxs10("div", { className: "space-y-2", children: [
            /* @__PURE__ */ jsx12("label", { className: "text-xs font-bold uppercase text-muted-foreground", children: "Price 1KG (\u20B9)" }),
            /* @__PURE__ */ jsx12("input", { type: "number", name: "pricePerKg", required: true, defaultValue: editingProduct.pricePerKg, className: "w-full border rounded-xl p-3 outline-none focus:border-orange" })
          ] }),
          /* @__PURE__ */ jsxs10("div", { className: "space-y-2", children: [
            /* @__PURE__ */ jsx12("label", { className: "text-xs font-bold uppercase text-muted-foreground", children: "Price \xBDKG (\u20B9)" }),
            /* @__PURE__ */ jsx12("input", { type: "number", name: "pricePerHalfKg", required: true, defaultValue: editingProduct.pricePerHalfKg, className: "w-full border rounded-xl p-3 outline-none focus:border-orange" })
          ] })
        ] }),
        /* @__PURE__ */ jsxs10("div", { className: "space-y-2", children: [
          /* @__PURE__ */ jsx12("label", { className: "text-xs font-bold uppercase text-muted-foreground", children: "Description" }),
          /* @__PURE__ */ jsx12("textarea", { name: "description", required: true, rows: 3, defaultValue: editingProduct.description, className: "w-full border rounded-xl p-3 outline-none focus:border-orange" })
        ] }),
        /* @__PURE__ */ jsxs10("div", { className: "space-y-2", children: [
          /* @__PURE__ */ jsx12("label", { className: "text-xs font-bold uppercase text-muted-foreground", children: "Visibility" }),
          /* @__PURE__ */ jsxs10("select", { name: "inStock", defaultValue: editingProduct.inStock ? "true" : "false", className: "w-full border rounded-xl p-3 bg-secondary/20 font-bold text-navy outline-none focus:border-orange", children: [
            /* @__PURE__ */ jsx12("option", { value: "true", children: "\u{1F7E2} Live (Visible on website)" }),
            /* @__PURE__ */ jsx12("option", { value: "false", children: "\u{1F534} Hidden (Not visible)" })
          ] })
        ] }),
        /* @__PURE__ */ jsxs10("div", { className: "sm:col-span-2 flex justify-end gap-3 pt-4 border-t border-border", children: [
          /* @__PURE__ */ jsx12("button", { type: "button", onClick: () => setEditingProduct(null), className: "px-6 py-3 rounded-full border border-border font-bold hover:bg-secondary transition-colors", children: "Cancel" }),
          /* @__PURE__ */ jsxs10("button", { type: "submit", className: "px-10 py-3 rounded-full bg-orange text-navy font-bold hover:bg-orange/80 transition-all shadow-lg shadow-orange/10 flex items-center gap-2", children: [
            /* @__PURE__ */ jsx12(Save, { className: "size-4" }),
            " Save Changes"
          ] })
        ] })
      ] }, editingProduct.id),
      /* @__PURE__ */ jsx12("div", { className: "bg-white rounded-3xl border border-border shadow-sm overflow-x-auto custom-scrollbar", children: /* @__PURE__ */ jsxs10("table", { className: "w-full text-sm text-left", children: [
        /* @__PURE__ */ jsx12("thead", { className: "text-xs text-muted-foreground uppercase bg-secondary/50", children: /* @__PURE__ */ jsxs10("tr", { children: [
          /* @__PURE__ */ jsx12("th", { className: "px-6 py-5", children: "Product" }),
          /* @__PURE__ */ jsx12("th", { className: "px-6 py-5", children: "Category" }),
          /* @__PURE__ */ jsx12("th", { className: "px-6 py-5", children: "Pricing" }),
          /* @__PURE__ */ jsx12("th", { className: "px-6 py-5", children: "Stock" }),
          /* @__PURE__ */ jsx12("th", { className: "px-6 py-5 text-right", children: "Actions" })
        ] }) }),
        /* @__PURE__ */ jsxs10("tbody", { className: "divide-y divide-border", children: [
          (products2 || []).map((p) => /* @__PURE__ */ jsxs10("tr", { className: `hover:bg-secondary/30 transition-colors ${editingProduct?.id === p.id ? "bg-orange/5 border-l-4 border-orange" : ""}`, children: [
            /* @__PURE__ */ jsxs10("td", { className: "px-6 py-4 flex items-center gap-4", children: [
              /* @__PURE__ */ jsx12("img", { src: p.image, className: "size-14 rounded-2xl object-cover shadow-sm" }),
              /* @__PURE__ */ jsxs10("div", { children: [
                /* @__PURE__ */ jsx12("div", { className: "font-bold text-navy text-base", children: p.name }),
                /* @__PURE__ */ jsx12("div", { className: "text-xs text-muted-foreground max-w-[200px] truncate", children: p.description })
              ] })
            ] }),
            /* @__PURE__ */ jsx12("td", { className: "px-6 py-4", children: /* @__PURE__ */ jsx12("span", { className: "bg-orange/10 text-orange px-3 py-1 rounded-full text-[10px] font-bold uppercase tracking-wider", children: p.category || "Uncategorized" }) }),
            /* @__PURE__ */ jsxs10("td", { className: "px-6 py-4", children: [
              /* @__PURE__ */ jsxs10("div", { className: "font-bold text-navy", children: [
                "\u20B9",
                p.pricePerKg,
                " / KG"
              ] }),
              /* @__PURE__ */ jsxs10("div", { className: "text-[10px] text-muted-foreground font-semibold", children: [
                "\u20B9",
                p.pricePerHalfKg,
                " / \xBDKG"
              ] })
            ] }),
            /* @__PURE__ */ jsx12("td", { className: "px-6 py-4", children: /* @__PURE__ */ jsxs10("div", { className: "flex flex-col gap-2", children: [
              /* @__PURE__ */ jsx12("button", { onClick: () => toggleStock(p.id), title: "Click to toggle visibility", className: `w-fit inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-[10px] font-black uppercase tracking-widest transition-colors ${p.inStock ? "bg-green-100 text-green-700 hover:bg-green-200" : "bg-red-100 text-red-700 hover:bg-red-200"}`, children: p.inStock ? "\u{1F7E2} Live" : "\u{1F534} Hidden" }),
              /* @__PURE__ */ jsxs10("div", { className: "text-xs font-bold text-navy", children: [
                p.stockQuantity,
                " units left"
              ] })
            ] }) }),
            /* @__PURE__ */ jsx12("td", { className: "px-6 py-4 text-right", children: /* @__PURE__ */ jsxs10("div", { className: "flex items-center justify-end gap-2", children: [
              /* @__PURE__ */ jsx12("button", { onClick: () => {
                setEditingProduct(p);
                setIsAdding(false);
                window.scrollTo({
                  top: 0,
                  behavior: "smooth"
                });
              }, className: `p-2.5 rounded-xl transition-colors ${editingProduct?.id === p.id ? "bg-orange text-white" : "text-muted-foreground hover:text-navy hover:bg-secondary"}`, title: "Edit Product", children: /* @__PURE__ */ jsx12(Edit, { className: "size-4" }) }),
              /* @__PURE__ */ jsx12("button", { onClick: () => {
                if (confirm(`Delete "${p.name}"?`)) deleteProduct(p.id);
              }, className: "p-2.5 text-red-500 hover:bg-red-50 rounded-xl transition-colors", title: "Delete Product", children: /* @__PURE__ */ jsx12(Trash22, { className: "size-4" }) })
            ] }) })
          ] }, p.id)),
          (products2 || []).length === 0 && /* @__PURE__ */ jsx12("tr", { children: /* @__PURE__ */ jsx12("td", { colSpan: 5, className: "px-6 py-20 text-center", children: /* @__PURE__ */ jsxs10("div", { className: "flex flex-col items-center gap-2 text-muted-foreground", children: [
            /* @__PURE__ */ jsx12(Layers, { className: "size-12 opacity-10" }),
            /* @__PURE__ */ jsx12("p", { className: "font-bold uppercase tracking-widest text-xs", children: "No products in catalog" })
          ] }) }) })
        ] })
      ] }) })
    ] })
  ] }) });
}
var init_products_BVhow1KF = __esm({
  "dist/server/assets/products-BVhow1KF.js"() {
    "use strict";
    init_products_DDA9Kbv3();
    init_ErrorBoundary_BtGZJTax();
    init_MediaUpload_C6I_6V8U();
  }
});

// dist/server/assets/card-DK4TJU2r.js
import { jsx as jsx13 } from "react/jsx-runtime";
import * as React3 from "react";
var Card, CardHeader, CardTitle, CardDescription, CardContent, CardFooter;
var init_card_DK4TJU2r = __esm({
  "dist/server/assets/card-DK4TJU2r.js"() {
    "use strict";
    init_utils_H80jjgLf();
    Card = React3.forwardRef(
      ({ className, ...props }, ref5) => /* @__PURE__ */ jsx13(
        "div",
        {
          ref: ref5,
          className: cn("rounded-xl border bg-card text-card-foreground shadow", className),
          ...props
        }
      )
    );
    Card.displayName = "Card";
    CardHeader = React3.forwardRef(
      ({ className, ...props }, ref5) => /* @__PURE__ */ jsx13("div", { ref: ref5, className: cn("flex flex-col space-y-1.5 p-6", className), ...props })
    );
    CardHeader.displayName = "CardHeader";
    CardTitle = React3.forwardRef(
      ({ className, ...props }, ref5) => /* @__PURE__ */ jsx13(
        "div",
        {
          ref: ref5,
          className: cn("font-semibold leading-none tracking-tight", className),
          ...props
        }
      )
    );
    CardTitle.displayName = "CardTitle";
    CardDescription = React3.forwardRef(
      ({ className, ...props }, ref5) => /* @__PURE__ */ jsx13("div", { ref: ref5, className: cn("text-sm text-muted-foreground", className), ...props })
    );
    CardDescription.displayName = "CardDescription";
    CardContent = React3.forwardRef(
      ({ className, ...props }, ref5) => /* @__PURE__ */ jsx13("div", { ref: ref5, className: cn("p-6 pt-0", className), ...props })
    );
    CardContent.displayName = "CardContent";
    CardFooter = React3.forwardRef(
      ({ className, ...props }, ref5) => /* @__PURE__ */ jsx13("div", { ref: ref5, className: cn("flex items-center p-6 pt-0", className), ...props })
    );
    CardFooter.displayName = "CardFooter";
  }
});

// dist/server/assets/payments-B4kqMjE2.js
var payments_B4kqMjE2_exports = {};
__export(payments_B4kqMjE2_exports, {
  component: () => PaymentsPage
});
import { jsx as jsx14, jsxs as jsxs11 } from "react/jsx-runtime";
import { useMemo as useMemo4 } from "react";
import { CheckCircle2 as CheckCircle24, XCircle, Wallet as Wallet2, CreditCard as CreditCard2 } from "lucide-react";
import { toast as toast8 } from "sonner";
import "zustand";
import "firebase/database";
import "@tanstack/react-router";
import "firebase/app";
import "firebase/auth";
import "firebase/firestore";
import "firebase/analytics";
import "zustand/middleware";
import "clsx";
import "tailwind-merge";
import "date-fns";
function PaymentsPage() {
  const {
    orders,
    updateOrderPaymentStatus
  } = useOrders();
  const {
    selectedDate
  } = useAdminFilter();
  const filteredOrders = useMemo4(() => {
    const selectedDateStr = selectedDate;
    const safeOrders = Array.isArray(orders) ? orders : [];
    return safeOrders.filter((o) => {
      if (!o.date) return false;
      const oDateStr = o.date.split("T")[0];
      return oDateStr === selectedDateStr;
    });
  }, [orders, selectedDate]);
  const stats = useMemo4(() => {
    const cash = filteredOrders.filter((o) => o.paymentMethod === "Cash" && o.isPaid).reduce((acc, o) => acc + o.totalAmount, 0);
    const upi = filteredOrders.filter((o) => o.paymentMethod === "UPI" && o.isPaid).reduce((acc, o) => acc + o.totalAmount, 0);
    const pending = filteredOrders.filter((o) => !o.isPaid).reduce((acc, o) => acc + o.totalAmount, 0);
    return {
      cash,
      upi,
      pending,
      paidCount: filteredOrders.filter((o) => o.isPaid).length,
      unpaidCount: filteredOrders.filter((o) => !o.isPaid).length
    };
  }, [filteredOrders]);
  return /* @__PURE__ */ jsx14(ErrorBoundary, { children: /* @__PURE__ */ jsxs11("div", { className: "space-y-6", children: [
    /* @__PURE__ */ jsx14("div", { className: "flex flex-col md:flex-row md:items-center justify-between gap-4", children: /* @__PURE__ */ jsxs11("div", { children: [
      /* @__PURE__ */ jsx14("h1", { className: "text-3xl font-display font-bold text-navy", children: "Payment Management" }),
      /* @__PURE__ */ jsx14("p", { className: "text-muted-foreground mt-1", children: "Track and reconcile daily collections." })
    ] }) }),
    /* @__PURE__ */ jsxs11("div", { className: "grid gap-4 md:grid-cols-3", children: [
      /* @__PURE__ */ jsxs11(Card, { className: "bg-green-50 border-green-100", children: [
        /* @__PURE__ */ jsx14(CardHeader, { className: "pb-2", children: /* @__PURE__ */ jsx14(CardTitle, { className: "text-xs font-bold text-green-700 uppercase", children: "Cash Collected" }) }),
        /* @__PURE__ */ jsx14(CardContent, { children: /* @__PURE__ */ jsxs11("div", { className: "text-2xl font-bold text-green-900", children: [
          "\u20B9",
          stats.cash
        ] }) })
      ] }),
      /* @__PURE__ */ jsxs11(Card, { className: "bg-blue-50 border-blue-100", children: [
        /* @__PURE__ */ jsx14(CardHeader, { className: "pb-2", children: /* @__PURE__ */ jsx14(CardTitle, { className: "text-xs font-bold text-blue-700 uppercase", children: "UPI Collected" }) }),
        /* @__PURE__ */ jsx14(CardContent, { children: /* @__PURE__ */ jsxs11("div", { className: "text-2xl font-bold text-blue-900", children: [
          "\u20B9",
          stats.upi
        ] }) })
      ] }),
      /* @__PURE__ */ jsxs11(Card, { className: "bg-orange-50 border-orange-100", children: [
        /* @__PURE__ */ jsx14(CardHeader, { className: "pb-2", children: /* @__PURE__ */ jsx14(CardTitle, { className: "text-xs font-bold text-orange-700 uppercase", children: "Pending Payments" }) }),
        /* @__PURE__ */ jsx14(CardContent, { children: /* @__PURE__ */ jsxs11("div", { className: "text-2xl font-bold text-orange-900", children: [
          "\u20B9",
          stats.pending
        ] }) })
      ] })
    ] }),
    /* @__PURE__ */ jsxs11("div", { className: "bg-card rounded-2xl border border-border p-6 shadow-sm", children: [
      /* @__PURE__ */ jsxs11("div", { className: "flex items-center justify-between mb-6", children: [
        /* @__PURE__ */ jsx14("h2", { className: "text-xl font-semibold text-navy", children: "Daily Reconciliation" }),
        /* @__PURE__ */ jsxs11("div", { className: "flex gap-4 text-xs font-bold uppercase", children: [
          /* @__PURE__ */ jsxs11("div", { className: "flex items-center gap-1.5 text-green-600", children: [
            /* @__PURE__ */ jsx14(CheckCircle24, { className: "size-4" }),
            " Paid: ",
            stats.paidCount
          ] }),
          /* @__PURE__ */ jsxs11("div", { className: "flex items-center gap-1.5 text-orange-600", children: [
            /* @__PURE__ */ jsx14(XCircle, { className: "size-4" }),
            " Unpaid: ",
            stats.unpaidCount
          ] })
        ] })
      ] }),
      /* @__PURE__ */ jsx14("div", { className: "overflow-x-auto", children: /* @__PURE__ */ jsxs11("table", { className: "w-full text-sm text-left", children: [
        /* @__PURE__ */ jsx14("thead", { className: "text-xs text-muted-foreground uppercase bg-secondary", children: /* @__PURE__ */ jsxs11("tr", { children: [
          /* @__PURE__ */ jsx14("th", { className: "px-4 py-3 rounded-l-lg", children: "Order ID" }),
          /* @__PURE__ */ jsx14("th", { className: "px-4 py-3", children: "Customer" }),
          /* @__PURE__ */ jsx14("th", { className: "px-4 py-3", children: "Method" }),
          /* @__PURE__ */ jsx14("th", { className: "px-4 py-3", children: "Amount" }),
          /* @__PURE__ */ jsx14("th", { className: "px-4 py-3 rounded-r-lg", children: "Status" })
        ] }) }),
        /* @__PURE__ */ jsxs11("tbody", { className: "divide-y divide-border", children: [
          filteredOrders.map((order) => /* @__PURE__ */ jsxs11("tr", { className: "hover:bg-secondary/50", children: [
            /* @__PURE__ */ jsx14("td", { className: "px-4 py-4 font-bold text-navy", children: order.id }),
            /* @__PURE__ */ jsxs11("td", { className: "px-4 py-4", children: [
              /* @__PURE__ */ jsx14("div", { className: "font-semibold text-navy", children: order.customerName }),
              /* @__PURE__ */ jsx14("div", { className: "text-xs text-muted-foreground", children: order.phone })
            ] }),
            /* @__PURE__ */ jsx14("td", { className: "px-4 py-4", children: /* @__PURE__ */ jsxs11("div", { className: "flex items-center gap-2", children: [
              order.paymentMethod === "Cash" ? /* @__PURE__ */ jsx14(Wallet2, { className: "size-4 text-green-600" }) : /* @__PURE__ */ jsx14(CreditCard2, { className: "size-4 text-blue-600" }),
              /* @__PURE__ */ jsx14("span", { className: "font-semibold", children: order.paymentMethod })
            ] }) }),
            /* @__PURE__ */ jsxs11("td", { className: "px-4 py-4 font-bold text-navy", children: [
              "\u20B9",
              order.totalAmount
            ] }),
            /* @__PURE__ */ jsx14("td", { className: "px-4 py-4", children: /* @__PURE__ */ jsxs11("label", { className: "flex items-center gap-2 cursor-pointer", children: [
              /* @__PURE__ */ jsx14("input", { type: "checkbox", checked: order.isPaid, onChange: (e) => {
                updateOrderPaymentStatus(order.id, e.target.checked, "Admin");
                toast8.success(`Order ${order.id} marked as ${e.target.checked ? "Paid" : "Unpaid"}`);
              }, className: "size-4 rounded border-gray-300 text-orange focus:ring-orange" }),
              /* @__PURE__ */ jsx14("span", { className: `text-xs font-bold uppercase ${order.isPaid ? "text-green-600" : "text-orange-600"}`, children: order.isPaid ? "Paid" : "Mark Paid" })
            ] }) })
          ] }, order.uid)),
          filteredOrders.length === 0 && /* @__PURE__ */ jsx14("tr", { children: /* @__PURE__ */ jsx14("td", { colSpan: 5, className: "px-4 py-12 text-center text-muted-foreground", children: "No orders for this date." }) })
        ] })
      ] }) })
    ] })
  ] }) });
}
var init_payments_B4kqMjE2 = __esm({
  "dist/server/assets/payments-B4kqMjE2.js"() {
    "use strict";
    init_orders_BJKg52UO();
    init_card_DK4TJU2r();
    init_ErrorBoundary_BtGZJTax();
    init_adminFilter_Clv2cQDi();
  }
});

// dist/server/assets/select-B91GfZkm.js
import { jsxs as jsxs12, jsx as jsx15 } from "react/jsx-runtime";
import * as React4 from "react";
import * as SelectPrimitive from "@radix-ui/react-select";
import { ChevronDown, Check, ChevronUp } from "lucide-react";
var Select, SelectValue, SelectTrigger, SelectScrollUpButton, SelectScrollDownButton, SelectContent, SelectLabel, SelectItem, SelectSeparator;
var init_select_B91GfZkm = __esm({
  "dist/server/assets/select-B91GfZkm.js"() {
    "use strict";
    init_utils_H80jjgLf();
    Select = SelectPrimitive.Root;
    SelectValue = SelectPrimitive.Value;
    SelectTrigger = React4.forwardRef(({ className, children, ...props }, ref5) => /* @__PURE__ */ jsxs12(
      SelectPrimitive.Trigger,
      {
        ref: ref5,
        className: cn(
          "flex h-9 w-full items-center justify-between whitespace-nowrap rounded-md border border-input bg-transparent px-3 py-2 text-sm shadow-sm ring-offset-background data-[placeholder]:text-muted-foreground focus:outline-none focus:ring-1 focus:ring-ring disabled:cursor-not-allowed disabled:opacity-50 [&>span]:line-clamp-1",
          className
        ),
        ...props,
        children: [
          children,
          /* @__PURE__ */ jsx15(SelectPrimitive.Icon, { asChild: true, children: /* @__PURE__ */ jsx15(ChevronDown, { className: "h-4 w-4 opacity-50" }) })
        ]
      }
    ));
    SelectTrigger.displayName = SelectPrimitive.Trigger.displayName;
    SelectScrollUpButton = React4.forwardRef(({ className, ...props }, ref5) => /* @__PURE__ */ jsx15(
      SelectPrimitive.ScrollUpButton,
      {
        ref: ref5,
        className: cn("flex cursor-default items-center justify-center py-1", className),
        ...props,
        children: /* @__PURE__ */ jsx15(ChevronUp, { className: "h-4 w-4" })
      }
    ));
    SelectScrollUpButton.displayName = SelectPrimitive.ScrollUpButton.displayName;
    SelectScrollDownButton = React4.forwardRef(({ className, ...props }, ref5) => /* @__PURE__ */ jsx15(
      SelectPrimitive.ScrollDownButton,
      {
        ref: ref5,
        className: cn("flex cursor-default items-center justify-center py-1", className),
        ...props,
        children: /* @__PURE__ */ jsx15(ChevronDown, { className: "h-4 w-4" })
      }
    ));
    SelectScrollDownButton.displayName = SelectPrimitive.ScrollDownButton.displayName;
    SelectContent = React4.forwardRef(({ className, children, position = "popper", ...props }, ref5) => /* @__PURE__ */ jsx15(SelectPrimitive.Portal, { children: /* @__PURE__ */ jsxs12(
      SelectPrimitive.Content,
      {
        ref: ref5,
        className: cn(
          "relative z-50 max-h-(--radix-select-content-available-height) min-w-[8rem] overflow-y-auto overflow-x-hidden rounded-md border bg-popover text-popover-foreground shadow-md data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0 data-[state=closed]:zoom-out-95 data-[state=open]:zoom-in-95 data-[side=bottom]:slide-in-from-top-2 data-[side=left]:slide-in-from-right-2 data-[side=right]:slide-in-from-left-2 data-[side=top]:slide-in-from-bottom-2 origin-(--radix-select-content-transform-origin)",
          position === "popper" && "data-[side=bottom]:translate-y-1 data-[side=left]:-translate-x-1 data-[side=right]:translate-x-1 data-[side=top]:-translate-y-1",
          className
        ),
        position,
        ...props,
        children: [
          /* @__PURE__ */ jsx15(SelectScrollUpButton, {}),
          /* @__PURE__ */ jsx15(
            SelectPrimitive.Viewport,
            {
              className: cn(
                "p-1",
                position === "popper" && "h-[var(--radix-select-trigger-height)] w-full min-w-[var(--radix-select-trigger-width)]"
              ),
              children
            }
          ),
          /* @__PURE__ */ jsx15(SelectScrollDownButton, {})
        ]
      }
    ) }));
    SelectContent.displayName = SelectPrimitive.Content.displayName;
    SelectLabel = React4.forwardRef(({ className, ...props }, ref5) => /* @__PURE__ */ jsx15(
      SelectPrimitive.Label,
      {
        ref: ref5,
        className: cn("px-2 py-1.5 text-sm font-semibold", className),
        ...props
      }
    ));
    SelectLabel.displayName = SelectPrimitive.Label.displayName;
    SelectItem = React4.forwardRef(({ className, children, ...props }, ref5) => /* @__PURE__ */ jsxs12(
      SelectPrimitive.Item,
      {
        ref: ref5,
        className: cn(
          "relative flex w-full cursor-default select-none items-center rounded-sm py-1.5 pl-2 pr-8 text-sm outline-none focus:bg-accent focus:text-accent-foreground data-[disabled]:pointer-events-none data-[disabled]:opacity-50",
          className
        ),
        ...props,
        children: [
          /* @__PURE__ */ jsx15("span", { className: "absolute right-2 flex h-3.5 w-3.5 items-center justify-center", children: /* @__PURE__ */ jsx15(SelectPrimitive.ItemIndicator, { children: /* @__PURE__ */ jsx15(Check, { className: "h-4 w-4" }) }) }),
          /* @__PURE__ */ jsx15(SelectPrimitive.ItemText, { children })
        ]
      }
    ));
    SelectItem.displayName = SelectPrimitive.Item.displayName;
    SelectSeparator = React4.forwardRef(({ className, ...props }, ref5) => /* @__PURE__ */ jsx15(
      SelectPrimitive.Separator,
      {
        ref: ref5,
        className: cn("-mx-1 my-1 h-px bg-muted", className),
        ...props
      }
    ));
    SelectSeparator.displayName = SelectPrimitive.Separator.displayName;
  }
});

// dist/server/assets/orders-4x0FvsOb.js
var orders_4x0FvsOb_exports = {};
__export(orders_4x0FvsOb_exports, {
  component: () => OrdersPage
});
import { jsxs as jsxs13, jsx as jsx16, Fragment as Fragment3 } from "react/jsx-runtime";
import * as React5 from "react";
import { useState as useState9, useRef as useRef3 } from "react";
import { X as X5, Loader2 as Loader25, PackageCheck, CheckCircle as CheckCircle3, Truck, Edit as Edit2, Phone as Phone4, MessageCircle as MessageCircle3, MapPin as MapPin4, Wallet as Wallet3, CreditCard as CreditCard3, User, Pause as Pause2, Play as Play2, Download, Save as Save2 } from "lucide-react";
import { toast as toast9 } from "sonner";
import * as SheetPrimitive2 from "@radix-ui/react-dialog";
import * as LabelPrimitive from "@radix-ui/react-label";
import { cva as cva2 } from "class-variance-authority";
import "zustand";
import "firebase/database";
import "@tanstack/react-router";
import "firebase/app";
import "firebase/auth";
import "firebase/firestore";
import "firebase/analytics";
import "zustand/middleware";
import "clsx";
import "tailwind-merge";
import "@radix-ui/react-select";
import "date-fns";
function OrdersPage() {
  const {
    orders,
    loading
  } = useOrders();
  const {
    selectedDate
  } = useAdminFilter();
  if (loading || !orders) {
    return /* @__PURE__ */ jsx16("div", { className: "h-[60vh] grid place-items-center", children: /* @__PURE__ */ jsxs13("div", { className: "flex flex-col items-center gap-4", children: [
      /* @__PURE__ */ jsx16(Loader25, { className: "size-10 animate-spin text-orange" }),
      /* @__PURE__ */ jsx16("p", { className: "text-muted-foreground animate-pulse", children: "Syncing orders..." })
    ] }) });
  }
  const safeOrders = (Array.isArray(orders) ? orders : []).filter((o) => {
    if (!o.date) return false;
    return o.date.split("T")[0] === selectedDate;
  });
  const columns = [{
    id: "new",
    label: "New Orders",
    icon: PackageCheck
  }, {
    id: "confirmed",
    label: "Confirmed",
    icon: CheckCircle3
  }, {
    id: "dispatched",
    label: "Dispatched",
    icon: Truck
  }, {
    id: "delivered",
    label: "Delivered",
    icon: CheckCircle3
  }];
  return /* @__PURE__ */ jsx16(ErrorBoundary, { children: /* @__PURE__ */ jsxs13("div", { className: "space-y-6", children: [
    /* @__PURE__ */ jsxs13("div", { children: [
      /* @__PURE__ */ jsx16("h1", { className: "text-3xl font-display font-bold text-navy", children: "Order Management" }),
      /* @__PURE__ */ jsx16("p", { className: "text-muted-foreground mt-1", children: "Manage order workflow and assign delivery partners." })
    ] }),
    /* @__PURE__ */ jsx16("div", { className: "grid gap-4 grid-cols-1 md:grid-cols-2 xl:grid-cols-4 min-h-[calc(100vh-220px)]", children: columns.map((col) => /* @__PURE__ */ jsxs13("div", { className: "bg-secondary/30 rounded-3xl p-4 border border-border flex flex-col min-h-[400px]", children: [
      /* @__PURE__ */ jsxs13("div", { className: "flex items-center gap-2 mb-4 px-2", children: [
        /* @__PURE__ */ jsx16(col.icon, { className: "size-5 text-orange" }),
        /* @__PURE__ */ jsx16("h2", { className: "font-bold text-lg text-navy", children: col.label }),
        /* @__PURE__ */ jsx16("span", { className: "ml-auto bg-white/50 text-navy font-semibold text-xs px-2 py-1 rounded-full", children: safeOrders.filter((o) => o.status === col.id).length })
      ] }),
      /* @__PURE__ */ jsxs13("div", { className: "flex-1 overflow-y-auto space-y-4 pr-1", children: [
        safeOrders.filter((o) => o.status === col.id).map((order) => /* @__PURE__ */ jsx16(OrderCard, { order }, order.uid)),
        safeOrders.filter((o) => o.status === col.id).length === 0 && /* @__PURE__ */ jsxs13("div", { className: "text-center py-12 bg-white/40 rounded-2xl border border-dashed border-secondary/50", children: [
          /* @__PURE__ */ jsx16(PackageCheck, { className: "size-8 mx-auto text-muted-foreground/20 mb-2" }),
          /* @__PURE__ */ jsxs13("p", { className: "text-muted-foreground text-[10px] font-bold uppercase tracking-widest", children: [
            "No ",
            col.label
          ] })
        ] })
      ] })
    ] }, col.id)) })
  ] }) });
}
function VoiceNotePlayer({
  url
}) {
  const [playing, setPlaying] = useState9(false);
  const audioRef = useRef3(null);
  const toggle = () => {
    if (!audioRef.current) return;
    if (playing) audioRef.current.pause();
    else audioRef.current.play();
  };
  return /* @__PURE__ */ jsxs13("div", { className: "mt-3 bg-navy/5 rounded-xl p-2 flex items-center gap-3 border border-navy/10", children: [
    /* @__PURE__ */ jsx16("button", { onClick: toggle, className: "size-8 rounded-full bg-navy text-white grid place-items-center flex-shrink-0", children: playing ? /* @__PURE__ */ jsx16(Pause2, { className: "size-4" }) : /* @__PURE__ */ jsx16(Play2, { className: "size-4 ml-0.5" }) }),
    /* @__PURE__ */ jsxs13("div", { className: "flex-1", children: [
      /* @__PURE__ */ jsx16("div", { className: "text-[10px] font-bold text-navy uppercase tracking-wider", children: "Voice Note" }),
      /* @__PURE__ */ jsx16("div", { className: "h-1 bg-navy/10 rounded-full mt-1 overflow-hidden", children: playing && /* @__PURE__ */ jsx16("div", { className: "h-full bg-orange animate-progress" }) })
    ] }),
    /* @__PURE__ */ jsx16("a", { href: url, download: true, target: "_blank", className: "size-8 rounded-full bg-white hover:bg-orange hover:text-white grid place-items-center transition-colors shadow-sm", children: /* @__PURE__ */ jsx16(Download, { className: "size-4" }) }),
    /* @__PURE__ */ jsx16("audio", { ref: audioRef, src: url, onPlay: () => setPlaying(true), onPause: () => setPlaying(false), onEnded: () => setPlaying(false), className: "hidden" })
  ] });
}
function OrderCard({
  order
}) {
  const {
    updateOrderStatus,
    assignPartner,
    updateOrderPaymentStatus,
    updateOrderDetails
  } = useOrders();
  const partners = useDeliveryPartners((s) => s.partners);
  const [isEditing, setIsEditing] = useState9(false);
  const handleConfirm = () => {
    updateOrderStatus(order.uid, "confirmed");
    toast9.success("Order confirmed!");
    openWhatsApp(order.phone, `Hello ${order.customerName}, your order ${order.id} from Renuka's H2 Batters is confirmed!`);
  };
  const handleDispatch = () => {
    updateOrderStatus(order.uid, "dispatched");
    toast9.success("Order dispatched!");
    openWhatsApp(order.phone, `Hello ${order.customerName}, your order ${order.id} has been dispatched and will reach you soon!`);
  };
  const formatDate = (dateStr) => {
    try {
      const d = new Date(dateStr);
      if (isNaN(d.getTime())) return "Date unavailable";
      return d.toLocaleString("en-IN", {
        day: "2-digit",
        month: "short",
        hour: "2-digit",
        minute: "2-digit",
        hour12: true
      });
    } catch {
      return "Date unavailable";
    }
  };
  return /* @__PURE__ */ jsxs13("div", { className: "bg-white rounded-2xl p-4 shadow-sm border border-border relative group hover:border-orange/30 transition-all", children: [
    /* @__PURE__ */ jsxs13("div", { className: "flex justify-between items-start mb-2", children: [
      /* @__PURE__ */ jsxs13("div", { children: [
        /* @__PURE__ */ jsxs13("div", { className: "font-bold text-navy text-xs flex items-center gap-2", children: [
          "Order #",
          order.id,
          /* @__PURE__ */ jsx16("button", { onClick: () => setIsEditing(true), className: "opacity-0 group-hover:opacity-100 transition-opacity p-1 hover:bg-secondary rounded", children: /* @__PURE__ */ jsx16(Edit2, { className: "size-3 text-muted-foreground" }) })
        ] }),
        /* @__PURE__ */ jsx16("div", { className: "text-[10px] text-muted-foreground uppercase font-bold tracking-tight", children: formatDate(order.date) })
      ] }),
      /* @__PURE__ */ jsxs13("div", { className: "text-right", children: [
        /* @__PURE__ */ jsxs13("div", { className: "font-bold text-orange text-sm", children: [
          "\u20B9",
          order.totalAmount || 0
        ] }),
        /* @__PURE__ */ jsx16("div", { className: `text-[10px] font-bold ${order.isPaid ? "text-green-600" : "text-orange-600"}`, children: order.isPaid ? "PAID" : "UNPAID" })
      ] })
    ] }),
    /* @__PURE__ */ jsxs13("div", { className: "py-2 border-y border-secondary/50 my-2", children: [
      /* @__PURE__ */ jsx16("div", { className: "font-semibold text-navy text-sm mb-1", children: order.customerName }),
      /* @__PURE__ */ jsxs13("div", { className: "flex items-center gap-3", children: [
        /* @__PURE__ */ jsxs13("a", { href: `tel:${order.phone}`, className: "flex items-center gap-1 text-[10px] font-bold text-blue-600 hover:bg-blue-50 px-2 py-0.5 rounded-full border border-blue-100", children: [
          /* @__PURE__ */ jsx16(Phone4, { className: "size-2.5" }),
          " Call"
        ] }),
        /* @__PURE__ */ jsxs13("button", { onClick: () => openWhatsApp(order.phone, `Hello ${order.customerName}, about your order ${order.id}...`), className: "flex items-center gap-1 text-[10px] font-bold text-green-600 hover:bg-green-50 px-2 py-0.5 rounded-full border border-green-100", children: [
          /* @__PURE__ */ jsx16(MessageCircle3, { className: "size-2.5" }),
          " WhatsApp"
        ] })
      ] }),
      /* @__PURE__ */ jsxs13("div", { className: "mt-2 text-[11px] text-muted-foreground bg-secondary/30 p-2.5 rounded-xl border border-secondary shadow-inner", children: [
        /* @__PURE__ */ jsxs13("div", { className: "font-bold text-navy text-[10px] uppercase mb-1 flex items-center gap-1.5", children: [
          /* @__PURE__ */ jsx16(MapPin4, { className: "size-3 text-orange" }),
          "Delivery Address & Location"
        ] }),
        order.address ? /* @__PURE__ */ jsxs13("div", { className: "leading-tight text-navy/70", children: [
          order.address.door && /* @__PURE__ */ jsxs13("span", { className: "font-bold", children: [
            order.address.door,
            ", "
          ] }),
          order.address.apartment && /* @__PURE__ */ jsxs13("span", { children: [
            order.address.apartment,
            ", "
          ] }),
          order.address.floor && /* @__PURE__ */ jsxs13("span", { children: [
            "Fl ",
            order.address.floor,
            ", "
          ] }),
          order.address.street
        ] }) : /* @__PURE__ */ jsx16("span", { className: "text-red-500 font-bold", children: "Address missing" }),
        (order.mapsLink || order.mapsLocation) && /* @__PURE__ */ jsx16("div", { className: "mt-2", children: /* @__PURE__ */ jsxs13("a", { href: order.mapsLink || `https://maps.google.com/?q=${order.mapsLocation}`, target: "_blank", className: "inline-flex items-center gap-2 bg-blue-600 text-white px-3 py-1.5 rounded-lg font-bold hover:bg-blue-700 transition-all text-[9px] uppercase tracking-wider shadow-sm", children: [
          /* @__PURE__ */ jsx16(MapPin4, { className: "size-2.5" }),
          " Open Google Maps"
        ] }) })
      ] }),
      order.voiceNoteUrl && /* @__PURE__ */ jsx16("div", { className: "mt-2 p-1 bg-orange/5 border border-orange/10 rounded-2xl", children: /* @__PURE__ */ jsx16(VoiceNotePlayer, { url: order.voiceNoteUrl }) })
    ] }),
    /* @__PURE__ */ jsxs13("div", { className: "space-y-1 mb-3", children: [
      (order.items || []).map((it, idx) => /* @__PURE__ */ jsx16("div", { className: "text-[11px] flex justify-between", children: /* @__PURE__ */ jsxs13("span", { className: "text-navy font-medium", children: [
        it.kg > 0 ? `${it.kg}kg ` : "",
        it.halfKg > 0 ? `${it.halfKg}x0.5kg ` : "",
        it.name
      ] }) }, `${order.uid}-${it.productId}-${idx}`)),
      /* @__PURE__ */ jsxs13("div", { className: "flex items-center justify-between mt-2 pt-1 border-t border-secondary/30", children: [
        /* @__PURE__ */ jsxs13("div", { className: "flex items-center gap-1.5", children: [
          order.paymentMethod === "Cash" ? /* @__PURE__ */ jsx16(Wallet3, { className: "size-3 text-green-600" }) : /* @__PURE__ */ jsx16(CreditCard3, { className: "size-3 text-blue-600" }),
          /* @__PURE__ */ jsx16("span", { className: "text-[10px] font-bold text-navy uppercase", children: order.paymentMethod })
        ] }),
        /* @__PURE__ */ jsxs13("label", { className: "flex items-center gap-1.5 cursor-pointer select-none", children: [
          /* @__PURE__ */ jsx16("input", { type: "checkbox", checked: order.isPaid, onChange: (e) => updateOrderPaymentStatus(order.uid, e.target.checked, "Admin"), className: "size-3 rounded border-gray-300 text-orange focus:ring-orange" }),
          /* @__PURE__ */ jsx16("span", { className: "text-[10px] font-bold text-navy uppercase", children: "Mark Paid" })
        ] })
      ] })
    ] }),
    /* @__PURE__ */ jsxs13("div", { className: "flex flex-col gap-2", children: [
      order.status === "new" && /* @__PURE__ */ jsx16("button", { onClick: handleConfirm, className: "w-full bg-navy text-white text-[10px] font-bold py-2.5 rounded-xl hover:bg-orange transition-colors uppercase tracking-wider", children: "Confirm Order" }),
      order.status === "confirmed" && /* @__PURE__ */ jsxs13(Fragment3, { children: [
        /* @__PURE__ */ jsxs13("select", { className: "w-full text-[10px] font-semibold p-2 rounded-xl border border-border bg-white", value: order.assignedPartnerId || "", onChange: (e) => assignPartner(order.uid, e.target.value), children: [
          /* @__PURE__ */ jsx16("option", { value: "", disabled: true, children: "Assign Delivery Partner" }),
          (partners || []).map((p) => /* @__PURE__ */ jsx16("option", { value: p.id, children: p.name }, p.id))
        ] }),
        /* @__PURE__ */ jsx16("button", { onClick: handleDispatch, disabled: !order.assignedPartnerId, className: "w-full bg-orange text-navy text-[10px] font-bold py-2.5 rounded-xl hover:bg-orange/80 transition-colors disabled:opacity-50 uppercase tracking-wider", children: "Mark Dispatched" })
      ] }),
      (order.status === "dispatched" || order.status === "delivered") && /* @__PURE__ */ jsxs13("div", { className: "flex items-center gap-2 text-[10px] font-bold text-navy bg-secondary/50 p-2 rounded-xl border border-secondary", children: [
        /* @__PURE__ */ jsx16(User, { className: "size-3.5 text-orange" }),
        partners.find((p) => p.id === order.assignedPartnerId)?.name || "Unassigned"
      ] })
    ] }),
    /* @__PURE__ */ jsx16(EditOrderModal, { isOpen: isEditing, onClose: () => setIsEditing(false), order, onSave: (updates) => {
      updateOrderDetails(order.uid, updates);
      toast9.success("Order details updated.");
    } })
  ] });
}
function EditOrderModal({
  isOpen,
  onClose,
  order,
  onSave
}) {
  const [formData, setFormData] = useState9({
    customerName: order.customerName,
    phone: order.phone,
    apartment: order.address?.apartment || "",
    street: order.address?.street || "",
    door: order.address?.door || "",
    floor: order.address?.floor || "",
    mapsLocation: order.mapsLocation || "",
    paymentMethod: order.paymentMethod
  });
  const handleSubmit = (e) => {
    e.preventDefault();
    onSave({
      customerName: formData.customerName,
      phone: formData.phone,
      address: {
        apartment: formData.apartment,
        street: formData.street,
        door: formData.door,
        floor: formData.floor
      },
      mapsLocation: formData.mapsLocation,
      paymentMethod: formData.paymentMethod
    });
    onClose();
  };
  return /* @__PURE__ */ jsx16(Dialog, { open: isOpen, onOpenChange: onClose, children: /* @__PURE__ */ jsxs13(DialogContent, { className: "sm:max-w-[425px] rounded-3xl", children: [
    /* @__PURE__ */ jsxs13(DialogHeader, { children: [
      /* @__PURE__ */ jsx16(DialogTitle, { className: "text-xl font-display font-bold text-navy", children: "Edit Order Details" }),
      /* @__PURE__ */ jsxs13(DialogDescription, { className: "sr-only", children: [
        "Update customer information and delivery address for order ",
        order.id
      ] })
    ] }),
    /* @__PURE__ */ jsxs13("form", { onSubmit: handleSubmit, className: "space-y-4 py-4", children: [
      /* @__PURE__ */ jsxs13("div", { className: "grid grid-cols-2 gap-4", children: [
        /* @__PURE__ */ jsxs13("div", { className: "space-y-2", children: [
          /* @__PURE__ */ jsx16(Label2, { htmlFor: "name", children: "Name" }),
          /* @__PURE__ */ jsx16(Input, { id: "name", value: formData.customerName, onChange: (e) => setFormData({
            ...formData,
            customerName: e.target.value
          }) })
        ] }),
        /* @__PURE__ */ jsxs13("div", { className: "space-y-2", children: [
          /* @__PURE__ */ jsx16(Label2, { htmlFor: "phone", children: "Phone" }),
          /* @__PURE__ */ jsx16(Input, { id: "phone", value: formData.phone, onChange: (e) => setFormData({
            ...formData,
            phone: e.target.value
          }) })
        ] })
      ] }),
      /* @__PURE__ */ jsxs13("div", { className: "space-y-2", children: [
        /* @__PURE__ */ jsx16(Label2, { children: "Address Details" }),
        /* @__PURE__ */ jsxs13("div", { className: "grid grid-cols-2 gap-2", children: [
          /* @__PURE__ */ jsx16(Input, { placeholder: "Door #", value: formData.door, onChange: (e) => setFormData({
            ...formData,
            door: e.target.value
          }) }),
          /* @__PURE__ */ jsx16(Input, { placeholder: "Floor", value: formData.floor, onChange: (e) => setFormData({
            ...formData,
            floor: e.target.value
          }) })
        ] }),
        /* @__PURE__ */ jsx16(Input, { placeholder: "Apartment", value: formData.apartment, onChange: (e) => setFormData({
          ...formData,
          apartment: e.target.value
        }) }),
        /* @__PURE__ */ jsx16(Input, { placeholder: "Street", value: formData.street, onChange: (e) => setFormData({
          ...formData,
          street: e.target.value
        }) })
      ] }),
      /* @__PURE__ */ jsxs13("div", { className: "space-y-2", children: [
        /* @__PURE__ */ jsx16(Label2, { htmlFor: "maps", children: "Maps Location (Lat,Lng)" }),
        /* @__PURE__ */ jsx16(Input, { id: "maps", value: formData.mapsLocation, onChange: (e) => setFormData({
          ...formData,
          mapsLocation: e.target.value
        }) })
      ] }),
      /* @__PURE__ */ jsxs13("div", { className: "space-y-2", children: [
        /* @__PURE__ */ jsx16(Label2, { htmlFor: "payment", children: "Payment Method" }),
        /* @__PURE__ */ jsxs13(Select, { value: formData.paymentMethod, onValueChange: (v) => setFormData({
          ...formData,
          paymentMethod: v
        }), children: [
          /* @__PURE__ */ jsx16(SelectTrigger, { id: "payment", children: /* @__PURE__ */ jsx16(SelectValue, {}) }),
          /* @__PURE__ */ jsxs13(SelectContent, { children: [
            /* @__PURE__ */ jsx16(SelectItem, { value: "Cash", children: "Cash" }),
            /* @__PURE__ */ jsx16(SelectItem, { value: "UPI", children: "UPI" })
          ] })
        ] })
      ] }),
      /* @__PURE__ */ jsxs13("div", { className: "flex gap-3 pt-4", children: [
        /* @__PURE__ */ jsx16("button", { type: "button", onClick: onClose, className: "flex-1 px-4 py-2 rounded-xl border border-border font-bold text-navy hover:bg-secondary", children: "Cancel" }),
        /* @__PURE__ */ jsxs13("button", { type: "submit", className: "flex-1 bg-navy text-white px-4 py-2 rounded-xl font-bold hover:bg-orange transition-colors flex items-center justify-center gap-2", children: [
          /* @__PURE__ */ jsx16(Save2, { className: "size-4" }),
          " Save Changes"
        ] })
      ] })
    ] })
  ] }) });
}
var Dialog, DialogPortal, DialogOverlay, DialogContent, DialogHeader, DialogTitle, DialogDescription, labelVariants, Label2;
var init_orders_4x0FvsOb = __esm({
  "dist/server/assets/orders-4x0FvsOb.js"() {
    "use strict";
    init_orders_BJKg52UO();
    init_deliveryPartners_DwkfBo1h();
    init_whatsapp_ClGNEJKh();
    init_utils_H80jjgLf();
    init_select_B91GfZkm();
    init_ErrorBoundary_BtGZJTax();
    init_adminFilter_Clv2cQDi();
    Dialog = SheetPrimitive2.Root;
    DialogPortal = SheetPrimitive2.Portal;
    DialogOverlay = React5.forwardRef(({ className, ...props }, ref5) => /* @__PURE__ */ jsx16(
      SheetPrimitive2.Overlay,
      {
        ref: ref5,
        className: cn(
          "fixed inset-0 z-50 bg-black/80  data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0",
          className
        ),
        ...props
      }
    ));
    DialogOverlay.displayName = SheetPrimitive2.Overlay.displayName;
    DialogContent = React5.forwardRef(({ className, children, ...props }, ref5) => /* @__PURE__ */ jsxs13(DialogPortal, { children: [
      /* @__PURE__ */ jsx16(DialogOverlay, {}),
      /* @__PURE__ */ jsxs13(
        SheetPrimitive2.Content,
        {
          ref: ref5,
          className: cn(
            "fixed left-[50%] top-[50%] z-50 grid w-full max-w-lg translate-x-[-50%] translate-y-[-50%] gap-4 border bg-background p-6 shadow-lg duration-200 data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0 data-[state=closed]:zoom-out-95 data-[state=open]:zoom-in-95 data-[state=closed]:slide-out-to-left-1/2 data-[state=closed]:slide-out-to-top-[48%] data-[state=open]:slide-in-from-left-1/2 data-[state=open]:slide-in-from-top-[48%] sm:rounded-lg",
            className
          ),
          ...props,
          children: [
            children,
            /* @__PURE__ */ jsxs13(SheetPrimitive2.Close, { className: "absolute right-4 top-4 rounded-sm opacity-70 ring-offset-background transition-opacity hover:opacity-100 focus:outline-none focus:ring-2 focus:ring-ring focus:ring-offset-2 disabled:pointer-events-none data-[state=open]:bg-accent data-[state=open]:text-muted-foreground", children: [
              /* @__PURE__ */ jsx16(X5, { className: "h-4 w-4" }),
              /* @__PURE__ */ jsx16("span", { className: "sr-only", children: "Close" })
            ] })
          ]
        }
      )
    ] }));
    DialogContent.displayName = SheetPrimitive2.Content.displayName;
    DialogHeader = ({ className, ...props }) => /* @__PURE__ */ jsx16("div", { className: cn("flex flex-col space-y-1.5 text-center sm:text-left", className), ...props });
    DialogHeader.displayName = "DialogHeader";
    DialogTitle = React5.forwardRef(({ className, ...props }, ref5) => /* @__PURE__ */ jsx16(
      SheetPrimitive2.Title,
      {
        ref: ref5,
        className: cn("text-lg font-semibold leading-none tracking-tight", className),
        ...props
      }
    ));
    DialogTitle.displayName = SheetPrimitive2.Title.displayName;
    DialogDescription = React5.forwardRef(({ className, ...props }, ref5) => /* @__PURE__ */ jsx16(
      SheetPrimitive2.Description,
      {
        ref: ref5,
        className: cn("text-sm text-muted-foreground", className),
        ...props
      }
    ));
    DialogDescription.displayName = SheetPrimitive2.Description.displayName;
    labelVariants = cva2(
      "text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
    );
    Label2 = React5.forwardRef(({ className, ...props }, ref5) => /* @__PURE__ */ jsx16(LabelPrimitive.Root, { ref: ref5, className: cn(labelVariants(), className), ...props }));
    Label2.displayName = LabelPrimitive.Root.displayName;
  }
});

// dist/server/assets/login-BbJEHsxO.js
var login_BbJEHsxO_exports = {};
__export(login_BbJEHsxO_exports, {
  component: () => SplitComponent
});
import { jsx as jsx17, jsxs as jsxs14, Fragment as Fragment4 } from "react/jsx-runtime";
import { Lock, Loader2 as Loader26 } from "lucide-react";
import { useState as useState10 } from "react";
import { toast as toast10 } from "sonner";
import { useRouter as useRouter4 } from "@tanstack/react-router";
import "zustand";
import "firebase/database";
import "firebase/app";
import "firebase/auth";
import "firebase/firestore";
import "firebase/analytics";
import "zustand/middleware";
import "@imagekit/javascript";
import "clsx";
import "tailwind-merge";
function AdminLogin2() {
  const login = useAdminAuth((s) => s.login);
  const router2 = useRouter4();
  const [loading, setLoading] = useState10(false);
  const handleLogin = (e) => {
    e.preventDefault();
    setLoading(true);
    const form = new FormData(e.currentTarget);
    const password = form.get("password");
    setTimeout(() => {
      const success = login(password);
      setLoading(false);
      if (success) {
        toast10.success("Access Granted. Welcome, Admin.");
        router2.navigate({ to: "/admin/dashboard" });
      } else {
        toast10.error("Invalid Administrative Password.");
      }
    }, 800);
  };
  return /* @__PURE__ */ jsx17("div", { className: "fixed inset-0 z-[9999] bg-navy flex items-center justify-center p-6 overflow-y-auto", children: /* @__PURE__ */ jsxs14("div", { className: "w-full max-w-md bg-white rounded-[2.5rem] p-8 md:p-12 shadow-2xl relative overflow-hidden my-auto", children: [
    /* @__PURE__ */ jsx17("div", { className: "absolute top-0 right-0 w-32 h-32 bg-orange/10 rounded-full -mr-16 -mt-16 blur-2xl" }),
    /* @__PURE__ */ jsx17("div", { className: "absolute bottom-0 left-0 w-32 h-32 bg-navy/5 rounded-full -ml-16 -mb-16 blur-2xl" }),
    /* @__PURE__ */ jsxs14("div", { className: "relative", children: [
      /* @__PURE__ */ jsx17("div", { className: "flex justify-center mb-8", children: /* @__PURE__ */ jsx17(Logo, { size: "xl", className: "rotate-3" }) }),
      /* @__PURE__ */ jsxs14("div", { className: "text-center mb-10", children: [
        /* @__PURE__ */ jsx17("h1", { className: "font-display font-black text-3xl text-navy tracking-tight", children: "Admin Terminal" }),
        /* @__PURE__ */ jsx17("p", { className: "text-muted-foreground mt-2 font-medium", children: "Enter secure password to continue" })
      ] }),
      /* @__PURE__ */ jsxs14(
        "form",
        {
          onSubmit: handleLogin,
          className: "space-y-6",
          autoComplete: "off",
          children: [
            /* @__PURE__ */ jsxs14("div", { className: "space-y-2", children: [
              /* @__PURE__ */ jsx17("label", { className: "block text-[10px] uppercase tracking-[0.2em] font-black text-navy/40 ml-1", children: "Security Password" }),
              /* @__PURE__ */ jsxs14("div", { className: "relative", children: [
                /* @__PURE__ */ jsx17(Lock, { className: "absolute left-4 top-1/2 -translate-y-1/2 size-5 text-muted-foreground" }),
                /* @__PURE__ */ jsx17(
                  "input",
                  {
                    name: "password",
                    type: "password",
                    required: true,
                    autoFocus: true,
                    autoComplete: "new-password",
                    className: "w-full bg-secondary/50 border-2 border-transparent rounded-2xl px-12 py-4 text-navy font-bold focus:outline-none focus:border-orange focus:bg-white transition-all",
                    placeholder: "\u2022\u2022\u2022\u2022\u2022\u2022\u2022\u2022\u2022\u2022\u2022\u2022"
                  }
                )
              ] })
            ] }),
            /* @__PURE__ */ jsx17(
              "button",
              {
                type: "submit",
                disabled: loading,
                className: "w-full bg-navy text-white py-4 rounded-2xl font-black uppercase tracking-widest hover:bg-orange hover:text-navy hover:scale-[1.02] active:scale-95 transition-all disabled:opacity-50 shadow-xl shadow-navy/20 flex items-center justify-center gap-3",
                children: loading ? /* @__PURE__ */ jsxs14(Fragment4, { children: [
                  /* @__PURE__ */ jsx17(Loader26, { className: "size-5 animate-spin" }),
                  "Authenticating..."
                ] }) : "Authorize Access"
              }
            )
          ]
        }
      ),
      /* @__PURE__ */ jsx17("div", { className: "mt-12 text-center", children: /* @__PURE__ */ jsx17("p", { className: "text-[10px] text-muted-foreground font-bold uppercase tracking-widest opacity-50", children: "Renuka's H2 Batters \u2014 Internal System" }) })
    ] })
  ] }) });
}
var SplitComponent;
var init_login_BbJEHsxO = __esm({
  "dist/server/assets/login-BbJEHsxO.js"() {
    "use strict";
    init_router_B40ruYtd();
    init_Logo_DpDS75JT();
    SplitComponent = AdminLogin2;
  }
});

// dist/server/assets/enquiries-B1twTlh2.js
var enquiries_B1twTlh2_exports = {};
__export(enquiries_B1twTlh2_exports, {
  component: () => EnquiriesPage
});
import { jsx as jsx18, jsxs as jsxs15 } from "react/jsx-runtime";
import { format as format3, parseISO } from "date-fns";
import { Loader2 as Loader27, User as User2, Phone as Phone5, Calendar as Calendar3, MessageSquare as MessageSquare2, Trash2 as Trash23 } from "lucide-react";
import { toast as toast11 } from "sonner";
import "@tanstack/react-router";
import "react";
import "zustand";
import "firebase/database";
import "firebase/app";
import "firebase/auth";
import "firebase/firestore";
import "firebase/analytics";
import "zustand/middleware";
function EnquiriesPage() {
  const {
    enquiries,
    loading,
    removeEnquiry,
    updateEnquiryStatus
  } = useSiteSettings();
  const {
    selectedDate
  } = useAdminFilter();
  if (loading || !enquiries) {
    return /* @__PURE__ */ jsx18("div", { className: "h-[60vh] grid place-items-center", children: /* @__PURE__ */ jsxs15("div", { className: "flex flex-col items-center gap-4", children: [
      /* @__PURE__ */ jsx18(Loader27, { className: "size-10 animate-spin text-orange" }),
      /* @__PURE__ */ jsx18("p", { className: "text-muted-foreground animate-pulse", children: "Loading enquiries..." })
    ] }) });
  }
  const safeEnquiries = (Array.isArray(enquiries) ? enquiries : []).filter((e) => {
    if (!e.date) return false;
    return e.date.split("T")[0] === selectedDate;
  });
  return /* @__PURE__ */ jsx18(ErrorBoundary, { children: /* @__PURE__ */ jsxs15("div", { className: "space-y-6", children: [
    /* @__PURE__ */ jsxs15("div", { className: "flex items-center justify-between", children: [
      /* @__PURE__ */ jsxs15("div", { children: [
        /* @__PURE__ */ jsx18("h1", { className: "text-3xl font-display font-bold text-navy", children: "Customer Enquiries" }),
        /* @__PURE__ */ jsx18("p", { className: "text-muted-foreground mt-1", children: "Manage feedback and questions from the website." })
      ] }),
      /* @__PURE__ */ jsxs15("div", { className: "flex items-center gap-2 bg-orange/10 text-orange px-4 py-2 rounded-full border border-orange/20", children: [
        /* @__PURE__ */ jsx18("span", { className: "text-xs font-bold uppercase tracking-widest", children: "Unread:" }),
        /* @__PURE__ */ jsx18("span", { className: "font-display font-black", children: safeEnquiries.filter((e) => !e.isRead).length })
      ] })
    ] }),
    /* @__PURE__ */ jsxs15("div", { className: "grid gap-6", children: [
      safeEnquiries.map((e) => /* @__PURE__ */ jsxs15("div", { className: `bg-white rounded-3xl p-6 md:p-8 border-2 transition-all group relative shadow-sm ${e.isRead ? "border-border opacity-75" : "border-orange shadow-xl shadow-orange/5"}`, children: [
        !e.isRead && /* @__PURE__ */ jsx18("div", { className: "absolute -top-3 -left-3 bg-orange text-navy text-[10px] font-black uppercase tracking-[0.2em] px-4 py-1.5 rounded-full shadow-lg z-10", children: "New Message" }),
        /* @__PURE__ */ jsxs15("div", { className: "flex flex-col md:flex-row md:items-start justify-between gap-6", children: [
          /* @__PURE__ */ jsxs15("div", { className: "flex-1 space-y-6", children: [
            /* @__PURE__ */ jsxs15("div", { className: "flex flex-wrap items-center gap-x-8 gap-y-4", children: [
              /* @__PURE__ */ jsxs15("div", { className: "flex items-center gap-3", children: [
                /* @__PURE__ */ jsx18("div", { className: "size-10 rounded-full bg-secondary grid place-items-center text-navy shadow-inner", children: /* @__PURE__ */ jsx18(User2, { className: "size-5" }) }),
                /* @__PURE__ */ jsxs15("div", { children: [
                  /* @__PURE__ */ jsx18("div", { className: "text-[10px] font-bold uppercase text-muted-foreground tracking-widest", children: "Customer" }),
                  /* @__PURE__ */ jsx18("div", { className: "font-bold text-navy text-lg leading-none", children: e.name })
                ] })
              ] }),
              /* @__PURE__ */ jsxs15("div", { className: "flex items-center gap-3", children: [
                /* @__PURE__ */ jsx18("div", { className: "size-10 rounded-full bg-secondary grid place-items-center text-navy shadow-inner", children: /* @__PURE__ */ jsx18(Phone5, { className: "size-5" }) }),
                /* @__PURE__ */ jsxs15("div", { children: [
                  /* @__PURE__ */ jsx18("div", { className: "text-[10px] font-bold uppercase text-muted-foreground tracking-widest", children: "Contact" }),
                  /* @__PURE__ */ jsx18("a", { href: `tel:${e.phone}`, className: "font-bold text-navy hover:text-orange hover:underline transition-colors", children: e.phone })
                ] })
              ] }),
              /* @__PURE__ */ jsxs15("div", { className: "flex items-center gap-3", children: [
                /* @__PURE__ */ jsx18("div", { className: "size-10 rounded-full bg-secondary grid place-items-center text-navy shadow-inner", children: /* @__PURE__ */ jsx18(Calendar3, { className: "size-5" }) }),
                /* @__PURE__ */ jsxs15("div", { children: [
                  /* @__PURE__ */ jsx18("div", { className: "text-[10px] font-bold uppercase text-muted-foreground tracking-widest", children: "Received On" }),
                  /* @__PURE__ */ jsx18("div", { className: "font-bold text-navy", children: e.date ? format3(parseISO(e.date), "PPP p") : "N/A" })
                ] })
              ] })
            ] }),
            /* @__PURE__ */ jsxs15("div", { className: `p-6 rounded-2xl border relative ${e.isRead ? "bg-secondary/20 border-border" : "bg-orange/5 border-orange/20"}`, children: [
              /* @__PURE__ */ jsx18(MessageSquare2, { className: `absolute -top-3 -left-3 size-8 opacity-10 rotate-12 ${e.isRead ? "text-navy" : "text-orange"}` }),
              /* @__PURE__ */ jsx18("p", { className: `text-navy leading-relaxed font-medium ${e.isRead ? "" : "text-lg"}`, children: e.message })
            ] })
          ] }),
          /* @__PURE__ */ jsxs15("div", { className: "flex md:flex-col gap-3", children: [
            /* @__PURE__ */ jsx18("button", { onClick: () => updateEnquiryStatus(e.id, !e.isRead), className: `flex-1 md:flex-none px-6 py-3 rounded-xl font-bold text-xs uppercase tracking-widest transition-all ${e.isRead ? "bg-secondary text-muted-foreground hover:bg-orange/20 hover:text-orange" : "bg-navy text-white hover:bg-orange hover:text-navy shadow-lg shadow-navy/20"}`, children: e.isRead ? "Mark Unread" : "Mark as Read" }),
            /* @__PURE__ */ jsx18("button", { onClick: () => {
              if (confirm("Permanently delete this enquiry?")) {
                removeEnquiry(e.id);
                toast11.success("Enquiry deleted.");
              }
            }, className: "size-12 rounded-xl bg-red-50 text-red-500 hover:bg-red-500 hover:text-white grid place-items-center transition-all", title: "Delete enquiry", children: /* @__PURE__ */ jsx18(Trash23, { className: "size-5" }) })
          ] })
        ] })
      ] }, e.id)),
      safeEnquiries.length === 0 && /* @__PURE__ */ jsxs15("div", { className: "text-center py-32 bg-white rounded-[3rem] border-4 border-dashed border-secondary shadow-inner", children: [
        /* @__PURE__ */ jsx18(MessageSquare2, { className: "size-16 mx-auto text-muted-foreground/10 mb-6" }),
        /* @__PURE__ */ jsx18("h3", { className: "text-2xl font-display font-bold text-navy", children: "No messages found" }),
        /* @__PURE__ */ jsx18("p", { className: "text-muted-foreground max-w-xs mx-auto", children: "When customers reach out through your website, their messages will appear here instantly." })
      ] })
    ] })
  ] }) });
}
var init_enquiries_B1twTlh2 = __esm({
  "dist/server/assets/enquiries-B1twTlh2.js"() {
    "use strict";
    init_router_B40ruYtd();
    init_ErrorBoundary_BtGZJTax();
    init_adminFilter_Clv2cQDi();
  }
});

// dist/server/assets/delivery-7VShiZL6.js
var delivery_7VShiZL6_exports = {};
__export(delivery_7VShiZL6_exports, {
  component: () => DeliveryPartnersPage
});
import { jsx as jsx19, jsxs as jsxs16 } from "react/jsx-runtime";
import { useState as useState11 } from "react";
import { Plus as Plus3, Trash2 as Trash24, Key, Phone as Phone6, MapPin as MapPin5 } from "lucide-react";
import { toast as toast12 } from "sonner";
import "zustand";
import "firebase/database";
import "@tanstack/react-router";
import "firebase/app";
import "firebase/auth";
import "firebase/firestore";
import "firebase/analytics";
import "zustand/middleware";
import "@imagekit/javascript";
function DeliveryPartnersPage() {
  const partners = useDeliveryPartners((s) => s.partners);
  const addPartner = useDeliveryPartners((s) => s.addPartner);
  const deletePartner = useDeliveryPartners((s) => s.deletePartner);
  const [isAdding, setIsAdding] = useState11(false);
  const [newPartnerImage, setNewPartnerImage] = useState11("https://images.unsplash.com/photo-1599566150163-29194dcaad36?w=400&h=400&fit=crop");
  return /* @__PURE__ */ jsx19(ErrorBoundary, { children: /* @__PURE__ */ jsxs16("div", { className: "space-y-6", children: [
    /* @__PURE__ */ jsxs16("div", { className: "flex items-center justify-between", children: [
      /* @__PURE__ */ jsxs16("div", { children: [
        /* @__PURE__ */ jsx19("h1", { className: "text-3xl font-display font-bold text-navy", children: "Delivery Partners" }),
        /* @__PURE__ */ jsx19("p", { className: "text-muted-foreground mt-1", children: "Manage delivery personnel and access credentials." })
      ] }),
      /* @__PURE__ */ jsxs16("button", { onClick: () => setIsAdding(!isAdding), className: "bg-navy text-white px-5 py-2.5 rounded-full font-semibold hover:bg-orange transition-colors flex items-center gap-2", children: [
        /* @__PURE__ */ jsx19(Plus3, { className: "size-4" }),
        " Add Partner"
      ] })
    ] }),
    isAdding && /* @__PURE__ */ jsxs16("form", { className: "bg-white p-8 rounded-[2rem] border border-border grid sm:grid-cols-2 gap-6 shadow-xl relative overflow-hidden", autoComplete: "off", onSubmit: (e) => {
      e.preventDefault();
      const form = new FormData(e.currentTarget);
      addPartner({
        id: form.get("id"),
        passcode: form.get("passcode"),
        name: form.get("name"),
        phone: form.get("phone"),
        image: newPartnerImage,
        address: form.get("address")
      });
      setIsAdding(false);
      setNewPartnerImage("https://images.unsplash.com/photo-1599566150163-29194dcaad36?w=400&h=400&fit=crop");
      toast12.success("Delivery partner created successfully!");
    }, children: [
      /* @__PURE__ */ jsxs16("div", { className: "sm:col-span-2 flex items-center justify-between mb-2", children: [
        /* @__PURE__ */ jsx19("h3", { className: "font-bold text-navy", children: "Partner Registration" }),
        /* @__PURE__ */ jsx19("button", { type: "button", onClick: () => setIsAdding(false), className: "text-muted-foreground hover:text-navy", children: /* @__PURE__ */ jsx19(Trash24, { className: "size-5" }) })
      ] }),
      /* @__PURE__ */ jsxs16("div", { className: "space-y-2", children: [
        /* @__PURE__ */ jsx19("label", { className: "text-[10px] font-black uppercase text-navy/40 tracking-[0.2em] ml-1", children: "Partner ID (Login)" }),
        /* @__PURE__ */ jsx19("input", { name: "id", required: true, autoComplete: "off", className: "w-full border-2 border-secondary rounded-2xl p-4 text-sm font-bold text-navy focus:border-orange outline-none transition-all", placeholder: "e.g. DP001" })
      ] }),
      /* @__PURE__ */ jsxs16("div", { className: "space-y-2", children: [
        /* @__PURE__ */ jsx19("label", { className: "text-[10px] font-black uppercase text-navy/40 tracking-[0.2em] ml-1", children: "Passcode (Login)" }),
        /* @__PURE__ */ jsx19("input", { name: "passcode", required: true, type: "password", autoComplete: "new-password", className: "w-full border-2 border-secondary rounded-2xl p-4 text-sm font-bold text-navy focus:border-orange outline-none transition-all", placeholder: "\u2022\u2022\u2022\u2022" })
      ] }),
      /* @__PURE__ */ jsxs16("div", { className: "space-y-2", children: [
        /* @__PURE__ */ jsx19("label", { className: "text-[10px] font-black uppercase text-navy/40 tracking-[0.2em] ml-1", children: "Full Name" }),
        /* @__PURE__ */ jsx19("input", { name: "name", required: true, autoComplete: "off", className: "w-full border-2 border-secondary rounded-2xl p-4 text-sm font-bold text-navy focus:border-orange outline-none transition-all" })
      ] }),
      /* @__PURE__ */ jsxs16("div", { className: "space-y-2", children: [
        /* @__PURE__ */ jsx19("label", { className: "text-[10px] font-black uppercase text-navy/40 tracking-[0.2em] ml-1", children: "Phone" }),
        /* @__PURE__ */ jsx19("input", { name: "phone", required: true, type: "tel", autoComplete: "off", className: "w-full border-2 border-secondary rounded-2xl p-4 text-sm font-bold text-navy focus:border-orange outline-none transition-all" })
      ] }),
      /* @__PURE__ */ jsx19("div", { className: "sm:col-span-2", children: /* @__PURE__ */ jsx19(MediaUpload, { label: "Profile Photo", value: newPartnerImage, onChange: setNewPartnerImage }) }),
      /* @__PURE__ */ jsxs16("div", { className: "space-y-2", children: [
        /* @__PURE__ */ jsx19("label", { className: "text-[10px] font-black uppercase text-navy/40 tracking-[0.2em] ml-1", children: "Address" }),
        /* @__PURE__ */ jsx19("input", { name: "address", required: true, autoComplete: "off", className: "w-full border-2 border-secondary rounded-2xl p-4 text-sm font-bold text-navy focus:border-orange outline-none transition-all" })
      ] }),
      /* @__PURE__ */ jsxs16("div", { className: "sm:col-span-2 flex justify-end gap-3 mt-4", children: [
        /* @__PURE__ */ jsx19("button", { type: "button", onClick: () => setIsAdding(false), className: "px-8 py-3.5 rounded-xl font-bold text-navy/60 hover:bg-secondary transition-all", children: "Cancel" }),
        /* @__PURE__ */ jsx19("button", { type: "submit", className: "px-10 py-3.5 rounded-xl bg-navy text-white font-black uppercase tracking-widest hover:bg-orange hover:text-navy transition-all shadow-lg shadow-navy/10", children: "Register Partner" })
      ] })
    ] }),
    /* @__PURE__ */ jsxs16("div", { className: "grid sm:grid-cols-2 lg:grid-cols-3 gap-6", children: [
      (partners || []).map((p) => /* @__PURE__ */ jsxs16("div", { className: "bg-card border border-border rounded-3xl p-6 shadow-sm relative group overflow-hidden", children: [
        /* @__PURE__ */ jsx19("div", { className: "absolute top-4 right-4 flex gap-2", children: /* @__PURE__ */ jsx19("button", { onClick: () => deletePartner(p.id), className: "p-2 bg-white/80 backdrop-blur rounded-full text-red-500 hover:bg-red-50 hover:scale-110 transition-all", children: /* @__PURE__ */ jsx19(Trash24, { className: "size-4" }) }) }),
        /* @__PURE__ */ jsxs16("div", { className: "flex items-center gap-4", children: [
          /* @__PURE__ */ jsx19("img", { src: p.image, alt: p.name, className: "size-16 rounded-full object-cover border-2 border-orange/20" }),
          /* @__PURE__ */ jsxs16("div", { children: [
            /* @__PURE__ */ jsx19("h3", { className: "font-display font-bold text-lg text-navy", children: p.name }),
            /* @__PURE__ */ jsxs16("div", { className: "text-xs font-medium text-orange flex items-center gap-1 mt-0.5", children: [
              /* @__PURE__ */ jsx19(Key, { className: "size-3" }),
              " ID: ",
              p.id
            ] })
          ] })
        ] }),
        /* @__PURE__ */ jsxs16("div", { className: "mt-6 space-y-3", children: [
          /* @__PURE__ */ jsxs16("div", { className: "flex items-center gap-3 text-sm text-muted-foreground", children: [
            /* @__PURE__ */ jsx19("div", { className: "p-2 bg-secondary rounded-lg text-navy", children: /* @__PURE__ */ jsx19(Phone6, { className: "size-4" }) }),
            p.phone
          ] }),
          /* @__PURE__ */ jsxs16("div", { className: "flex items-center gap-3 text-sm text-muted-foreground", children: [
            /* @__PURE__ */ jsx19("div", { className: "p-2 bg-secondary rounded-lg text-navy", children: /* @__PURE__ */ jsx19(MapPin5, { className: "size-4" }) }),
            p.address
          ] })
        ] })
      ] }, p.id)),
      (partners || []).length === 0 && !isAdding && /* @__PURE__ */ jsx19("div", { className: "sm:col-span-2 lg:col-span-3 text-center py-20 text-muted-foreground border-2 border-dashed border-border rounded-3xl", children: "No delivery partners added yet." })
    ] })
  ] }) });
}
var init_delivery_7VShiZL6 = __esm({
  "dist/server/assets/delivery-7VShiZL6.js"() {
    "use strict";
    init_deliveryPartners_DwkfBo1h();
    init_ErrorBoundary_BtGZJTax();
    init_MediaUpload_C6I_6V8U();
  }
});

// dist/server/assets/dashboard-BRCwi-3B.js
var dashboard_BRCwi_3B_exports = {};
__export(dashboard_BRCwi_3B_exports, {
  component: () => DashboardPage
});
import { jsx as jsx20, jsxs as jsxs17 } from "react/jsx-runtime";
import { useState as useState12, useMemo as useMemo5 } from "react";
import { Filter, Download as Download2, Settings as Settings2, IndianRupee as IndianRupee2, ShoppingCart as ShoppingCart2, CheckCircle as CheckCircle4, Clock as Clock2, Wallet as Wallet4, CreditCard as CreditCard4, TrendingUp as TrendingUp2 } from "lucide-react";
import { parseISO as parseISO2, isSameWeek, isSameMonth, isSameYear, format as format4 } from "date-fns";
import "zustand";
import "firebase/database";
import "sonner";
import "@tanstack/react-router";
import "firebase/app";
import "firebase/auth";
import "firebase/firestore";
import "firebase/analytics";
import "zustand/middleware";
import "clsx";
import "tailwind-merge";
import "@radix-ui/react-select";
function DashboardPage() {
  const orders = useOrders((s) => s.orders);
  useProductsStore((s) => s.products);
  const {
    selectedDate
  } = useAdminFilter();
  const [period, setPeriod] = useState12("daily");
  const filteredOrders = useMemo5(() => {
    const baseDate = parseISO2(selectedDate);
    const selectedDateStr = selectedDate;
    const safeOrders = Array.isArray(orders) ? orders : [];
    return safeOrders.filter((o) => {
      if (!o.date) return false;
      const orderDate = parseISO2(o.date);
      if (period === "daily") {
        const oDateStr = o.date.split("T")[0];
        return oDateStr === selectedDateStr;
      }
      if (period === "weekly") return isSameWeek(orderDate, baseDate);
      if (period === "monthly") return isSameMonth(orderDate, baseDate);
      if (period === "yearly") return isSameYear(orderDate, baseDate);
      return false;
    });
  }, [orders, selectedDate, period]);
  const stats = useMemo5(() => {
    const totalCollection = filteredOrders.reduce((acc, o) => acc + o.totalAmount, 0);
    const cashCollection = filteredOrders.filter((o) => o.paymentMethod === "Cash").reduce((acc, o) => acc + o.totalAmount, 0);
    const upiCollection = filteredOrders.filter((o) => o.paymentMethod === "UPI").reduce((acc, o) => acc + o.totalAmount, 0);
    const deliveredCount = filteredOrders.filter((o) => o.status === "delivered").length;
    const pendingCount = filteredOrders.filter((o) => o.status !== "delivered").length;
    const productCounts = {};
    filteredOrders.forEach((o) => {
      (o.items || []).forEach((item) => {
        if (!productCounts[item.productId]) {
          productCounts[item.productId] = {
            name: item.name,
            count: 0
          };
        }
        productCounts[item.productId].count += (item.kg || 0) + (item.halfKg || 0);
      });
    });
    const mostRepeated = Object.values(productCounts).sort((a, b) => b.count - a.count).slice(0, 5);
    return {
      totalCollection,
      cashCollection,
      upiCollection,
      deliveredCount,
      pendingCount,
      totalOrders: filteredOrders.length,
      mostRepeated
    };
  }, [filteredOrders]);
  const generatePDF = async () => {
    const {
      default: jsPDF
    } = await import("jspdf");
    const {
      default: autoTable
    } = await import("jspdf-autotable");
    const doc = new jsPDF();
    const pageW = doc.internal.pageSize.getWidth();
    const periodLabel = period.charAt(0).toUpperCase() + period.slice(1);
    const dateLabel = format4(parseISO2(selectedDate), "dd MMM yyyy");
    doc.setFillColor(31, 41, 80);
    doc.rect(0, 0, pageW, 36, "F");
    doc.setTextColor(255, 255, 255);
    doc.setFontSize(20);
    doc.setFont("helvetica", "bold");
    doc.text("Renuka's H2 Batters", 14, 16);
    doc.setFontSize(9);
    doc.setFont("helvetica", "normal");
    doc.text(`${periodLabel} Report  \xB7  ${dateLabel}  \xB7  Generated: ${format4(/* @__PURE__ */ new Date(), "dd MMM yyyy, hh:mm a")}`, 14, 28);
    let y = 46;
    doc.setTextColor(31, 41, 80);
    doc.setFontSize(13);
    doc.setFont("helvetica", "bold");
    doc.text("Summary", 14, y);
    y += 6;
    autoTable(doc, {
      startY: y,
      head: [["Metric", "Value"]],
      body: [["Total Revenue", `Rs. ${stats.totalCollection}`], ["Total Orders", String(stats.totalOrders)], ["Delivered Orders", String(stats.deliveredCount)], ["Pending Orders", String(stats.pendingCount)], ["Cash Collection", `Rs. ${stats.cashCollection}`], ["UPI Collection", `Rs. ${stats.upiCollection}`]],
      headStyles: {
        fillColor: [255, 122, 26],
        textColor: [31, 41, 80],
        fontStyle: "bold"
      },
      alternateRowStyles: {
        fillColor: [248, 249, 252]
      },
      styles: {
        fontSize: 10
      }
    });
    y = doc.lastAutoTable.finalY + 10;
    if (stats.mostRepeated.length > 0) {
      doc.setFontSize(13);
      doc.setFont("helvetica", "bold");
      doc.setTextColor(31, 41, 80);
      doc.text("Top Products", 14, y);
      y += 6;
      autoTable(doc, {
        startY: y,
        head: [["#", "Product", "Units Ordered"]],
        body: stats.mostRepeated.map((p, i) => [String(i + 1), p.name, String(p.count)]),
        headStyles: {
          fillColor: [31, 41, 80],
          textColor: [255, 255, 255]
        },
        alternateRowStyles: {
          fillColor: [248, 249, 252]
        },
        styles: {
          fontSize: 10
        }
      });
      y = doc.lastAutoTable.finalY + 10;
    }
    if (filteredOrders.length > 0) {
      doc.setFontSize(13);
      doc.setFont("helvetica", "bold");
      doc.setTextColor(31, 41, 80);
      doc.text("Orders", 14, y);
      y += 6;
      autoTable(doc, {
        startY: y,
        head: [["Order ID", "Customer", "Phone", "Status", "Payment", "Total"]],
        body: filteredOrders.map((o) => [o.id, o.customerName, o.phone, o.status.toUpperCase(), `${o.paymentMethod} - ${o.isPaid ? "Paid" : "Unpaid"}`, `Rs. ${o.totalAmount}`]),
        headStyles: {
          fillColor: [31, 41, 80],
          textColor: [255, 255, 255]
        },
        alternateRowStyles: {
          fillColor: [248, 249, 252]
        },
        styles: {
          fontSize: 8
        }
      });
    }
    const totalPages = doc.internal.getNumberOfPages();
    for (let i = 1; i <= totalPages; i++) {
      doc.setPage(i);
      doc.setFontSize(7);
      doc.setTextColor(150);
      doc.text(`Page ${i} of ${totalPages}  \xB7  Made by WEBDEN`, pageW / 2, doc.internal.pageSize.getHeight() - 6, {
        align: "center"
      });
    }
    doc.save(`report-${selectedDate}-${period}.pdf`);
  };
  return /* @__PURE__ */ jsx20(ErrorBoundary, { children: /* @__PURE__ */ jsxs17("div", { className: "space-y-8", children: [
    /* @__PURE__ */ jsxs17("div", { className: "flex flex-col xl:flex-row xl:items-center justify-between gap-6", children: [
      /* @__PURE__ */ jsxs17("div", { children: [
        /* @__PURE__ */ jsx20("h1", { className: "text-2xl md:text-3xl font-display font-bold text-navy", children: "Dashboard" }),
        /* @__PURE__ */ jsxs17("p", { className: "text-muted-foreground mt-1 text-sm md:text-base", children: [
          "Store overview for ",
          /* @__PURE__ */ jsx20("span", { className: "text-orange font-bold uppercase", children: period }),
          " report."
        ] })
      ] }),
      /* @__PURE__ */ jsxs17("div", { className: "flex flex-col sm:flex-row items-stretch sm:items-center gap-3 bg-white p-3 rounded-3xl border border-border shadow-sm", children: [
        /* @__PURE__ */ jsxs17("div", { className: "flex items-center gap-2 px-3 py-1.5 sm:border-r border-border", children: [
          /* @__PURE__ */ jsx20(Filter, { className: "size-4 text-orange" }),
          /* @__PURE__ */ jsx20("span", { className: "text-sm font-black uppercase tracking-wider text-navy", children: "Period" })
        ] }),
        /* @__PURE__ */ jsx20("div", { className: "grid grid-cols-2 sm:flex items-center gap-3", children: /* @__PURE__ */ jsxs17(Select, { value: period, onValueChange: (v) => setPeriod(v), children: [
          /* @__PURE__ */ jsx20(SelectTrigger, { className: "h-10 border-none bg-secondary/50 sm:bg-transparent focus:ring-0 rounded-xl sm:rounded-none", children: /* @__PURE__ */ jsx20(SelectValue, {}) }),
          /* @__PURE__ */ jsxs17(SelectContent, { children: [
            /* @__PURE__ */ jsx20(SelectItem, { value: "daily", children: "Daily" }),
            /* @__PURE__ */ jsx20(SelectItem, { value: "weekly", children: "Weekly" }),
            /* @__PURE__ */ jsx20(SelectItem, { value: "monthly", children: "Monthly" }),
            /* @__PURE__ */ jsx20(SelectItem, { value: "yearly", children: "Yearly" })
          ] })
        ] }) }),
        /* @__PURE__ */ jsxs17("div", { className: "flex items-center gap-2 pt-3 sm:pt-0 sm:border-l border-border sm:pl-3", children: [
          /* @__PURE__ */ jsxs17("button", { onClick: generatePDF, className: "flex-1 sm:flex-none px-5 py-2.5 bg-navy text-white hover:bg-orange hover:text-navy rounded-xl text-[10px] font-black uppercase tracking-widest transition-all flex items-center justify-center gap-2 shadow-lg shadow-navy/10", children: [
            /* @__PURE__ */ jsx20(Download2, { className: "size-3.5" }),
            " PDF"
          ] }),
          /* @__PURE__ */ jsx20("button", { onClick: () => {
            if (confirm("Are you sure you want to clear all data? This cannot be undone.")) {
              useOrders.getState().clearAllData();
              useSiteSettings.getState().clearAllEnquiries();
            }
          }, className: "size-10 flex items-center justify-center bg-red-500/10 text-red-500 hover:bg-red-500 hover:text-white rounded-xl transition-colors shrink-0", title: "Clear All Data", children: /* @__PURE__ */ jsx20(Settings2, { className: "size-4" }) })
        ] })
      ] })
    ] }),
    /* @__PURE__ */ jsxs17("div", { className: "grid gap-4 sm:gap-6 grid-cols-1 sm:grid-cols-2 lg:grid-cols-4", children: [
      /* @__PURE__ */ jsxs17(Card, { className: "border-none shadow-sm bg-navy text-white overflow-hidden relative", children: [
        /* @__PURE__ */ jsx20(CardHeader, { className: "pb-2", children: /* @__PURE__ */ jsx20(CardTitle, { className: "text-xs font-semibold uppercase tracking-wider text-white/60", children: "Total Collection" }) }),
        /* @__PURE__ */ jsxs17(CardContent, { children: [
          /* @__PURE__ */ jsxs17("div", { className: "text-2xl sm:text-3xl font-bold", children: [
            "\u20B9",
            stats.totalCollection
          ] }),
          /* @__PURE__ */ jsx20(IndianRupee2, { className: "absolute top-4 right-4 size-8 opacity-10" })
        ] })
      ] }),
      /* @__PURE__ */ jsxs17(Card, { className: "border-none shadow-sm bg-white overflow-hidden relative", children: [
        /* @__PURE__ */ jsx20(CardHeader, { className: "pb-2", children: /* @__PURE__ */ jsx20(CardTitle, { className: "text-xs font-semibold uppercase tracking-wider text-muted-foreground", children: "Orders" }) }),
        /* @__PURE__ */ jsxs17(CardContent, { children: [
          /* @__PURE__ */ jsx20("div", { className: "text-2xl sm:text-3xl font-bold text-navy", children: stats.totalOrders }),
          /* @__PURE__ */ jsx20(ShoppingCart2, { className: "absolute top-4 right-4 size-8 text-orange/10" })
        ] })
      ] }),
      /* @__PURE__ */ jsxs17(Card, { className: "border-none shadow-sm bg-green-50 overflow-hidden relative border-l-4 border-l-green-500", children: [
        /* @__PURE__ */ jsx20(CardHeader, { className: "pb-2", children: /* @__PURE__ */ jsx20(CardTitle, { className: "text-xs font-semibold uppercase tracking-wider text-green-700", children: "Delivered" }) }),
        /* @__PURE__ */ jsxs17(CardContent, { children: [
          /* @__PURE__ */ jsx20("div", { className: "text-2xl sm:text-3xl font-bold text-green-900", children: stats.deliveredCount }),
          /* @__PURE__ */ jsx20(CheckCircle4, { className: "absolute top-4 right-4 size-8 text-green-500/10" })
        ] })
      ] }),
      /* @__PURE__ */ jsxs17(Card, { className: "border-none shadow-sm bg-orange-50 overflow-hidden relative border-l-4 border-l-orange-500", children: [
        /* @__PURE__ */ jsx20(CardHeader, { className: "pb-2", children: /* @__PURE__ */ jsx20(CardTitle, { className: "text-xs font-semibold uppercase tracking-wider text-orange-700", children: "Pending" }) }),
        /* @__PURE__ */ jsxs17(CardContent, { children: [
          /* @__PURE__ */ jsx20("div", { className: "text-2xl sm:text-3xl font-bold text-orange-900", children: stats.pendingCount }),
          /* @__PURE__ */ jsx20(Clock2, { className: "absolute top-4 right-4 size-8 text-orange-500/10" })
        ] })
      ] })
    ] }),
    /* @__PURE__ */ jsxs17("div", { className: "grid gap-6 md:grid-cols-2", children: [
      /* @__PURE__ */ jsxs17(Card, { children: [
        /* @__PURE__ */ jsx20(CardHeader, { children: /* @__PURE__ */ jsxs17(CardTitle, { className: "text-lg text-navy font-bold flex items-center gap-2", children: [
          /* @__PURE__ */ jsx20(Wallet4, { className: "size-5 text-orange" }),
          "Payment Split"
        ] }) }),
        /* @__PURE__ */ jsxs17(CardContent, { className: "space-y-4", children: [
          /* @__PURE__ */ jsxs17("div", { className: "flex items-center justify-between p-4 bg-secondary/30 rounded-2xl", children: [
            /* @__PURE__ */ jsxs17("div", { className: "flex items-center gap-3", children: [
              /* @__PURE__ */ jsx20("div", { className: "size-10 rounded-full bg-white flex items-center justify-center shadow-sm", children: /* @__PURE__ */ jsx20(IndianRupee2, { className: "size-5 text-green-600" }) }),
              /* @__PURE__ */ jsxs17("div", { children: [
                /* @__PURE__ */ jsx20("div", { className: "text-sm font-semibold text-navy", children: "Cash Collection" }),
                /* @__PURE__ */ jsx20("div", { className: "text-xs text-muted-foreground", children: "End of day cash" })
              ] })
            ] }),
            /* @__PURE__ */ jsxs17("div", { className: "text-xl font-bold text-navy", children: [
              "\u20B9",
              stats.cashCollection
            ] })
          ] }),
          /* @__PURE__ */ jsxs17("div", { className: "flex items-center justify-between p-4 bg-secondary/30 rounded-2xl", children: [
            /* @__PURE__ */ jsxs17("div", { className: "flex items-center gap-3", children: [
              /* @__PURE__ */ jsx20("div", { className: "size-10 rounded-full bg-white flex items-center justify-center shadow-sm", children: /* @__PURE__ */ jsx20(CreditCard4, { className: "size-5 text-blue-600" }) }),
              /* @__PURE__ */ jsxs17("div", { children: [
                /* @__PURE__ */ jsx20("div", { className: "text-sm font-semibold text-navy", children: "UPI Collection" }),
                /* @__PURE__ */ jsx20("div", { className: "text-xs text-muted-foreground", children: "Digital payments" })
              ] })
            ] }),
            /* @__PURE__ */ jsxs17("div", { className: "text-xl font-bold text-navy", children: [
              "\u20B9",
              stats.upiCollection
            ] })
          ] })
        ] })
      ] }),
      /* @__PURE__ */ jsxs17(Card, { children: [
        /* @__PURE__ */ jsx20(CardHeader, { children: /* @__PURE__ */ jsxs17(CardTitle, { className: "text-lg text-navy font-bold flex items-center gap-2", children: [
          /* @__PURE__ */ jsx20(TrendingUp2, { className: "size-5 text-orange" }),
          "Most Repeated Products"
        ] }) }),
        /* @__PURE__ */ jsx20(CardContent, { children: /* @__PURE__ */ jsxs17("div", { className: "space-y-4", children: [
          stats.mostRepeated.map((p, idx) => /* @__PURE__ */ jsxs17("div", { className: "flex items-center gap-4", children: [
            /* @__PURE__ */ jsxs17("div", { className: "size-8 rounded-lg bg-orange/10 text-orange grid place-items-center font-bold text-sm", children: [
              "#",
              idx + 1
            ] }),
            /* @__PURE__ */ jsxs17("div", { className: "flex-1", children: [
              /* @__PURE__ */ jsx20("div", { className: "text-sm font-semibold text-navy", children: p.name }),
              /* @__PURE__ */ jsx20("div", { className: "w-full bg-secondary h-1.5 rounded-full mt-1.5 overflow-hidden", children: /* @__PURE__ */ jsx20("div", { className: "bg-orange h-full rounded-full", style: {
                width: `${p.count / Math.max(...stats.mostRepeated.map((x) => x.count)) * 100}%`
              } }) })
            ] }),
            /* @__PURE__ */ jsxs17("div", { className: "text-sm font-bold text-navy", children: [
              p.count,
              " units"
            ] })
          ] }, p.name)),
          stats.mostRepeated.length === 0 && /* @__PURE__ */ jsx20("div", { className: "text-center py-8 text-muted-foreground text-sm italic", children: "No data available for this period." })
        ] }) })
      ] })
    ] }),
    /* @__PURE__ */ jsxs17("div", { className: "bg-card rounded-2xl border border-border p-6 shadow-sm", children: [
      /* @__PURE__ */ jsx20("h2", { className: "text-xl font-semibold text-navy mb-4", children: "Orders for this period" }),
      /* @__PURE__ */ jsx20("div", { className: "overflow-x-auto", children: /* @__PURE__ */ jsxs17("table", { className: "w-full text-sm text-left", children: [
        /* @__PURE__ */ jsx20("thead", { className: "text-xs text-muted-foreground uppercase bg-secondary", children: /* @__PURE__ */ jsxs17("tr", { children: [
          /* @__PURE__ */ jsx20("th", { className: "px-4 py-3 rounded-l-lg", children: "Order ID" }),
          /* @__PURE__ */ jsx20("th", { className: "px-4 py-3", children: "Customer" }),
          /* @__PURE__ */ jsx20("th", { className: "px-4 py-3", children: "Status" }),
          /* @__PURE__ */ jsx20("th", { className: "px-4 py-3", children: "Payment" }),
          /* @__PURE__ */ jsx20("th", { className: "px-4 py-3 rounded-r-lg text-right", children: "Total" })
        ] }) }),
        /* @__PURE__ */ jsxs17("tbody", { className: "divide-y divide-border", children: [
          filteredOrders.map((order) => /* @__PURE__ */ jsxs17("tr", { className: "hover:bg-secondary/50 transition-colors", children: [
            /* @__PURE__ */ jsx20("td", { className: "px-4 py-4 font-medium text-navy", children: order.id }),
            /* @__PURE__ */ jsxs17("td", { className: "px-4 py-4", children: [
              /* @__PURE__ */ jsx20("div", { className: "font-semibold text-navy", children: order.customerName }),
              /* @__PURE__ */ jsx20("div", { className: "text-xs text-muted-foreground", children: order.phone })
            ] }),
            /* @__PURE__ */ jsx20("td", { className: "px-4 py-4", children: /* @__PURE__ */ jsx20("span", { className: `px-2.5 py-1 rounded-full text-[10px] font-bold uppercase tracking-wider ${order.status === "delivered" ? "bg-green-100 text-green-700" : order.status === "new" ? "bg-orange-100 text-orange-700" : "bg-blue-100 text-blue-700"}`, children: order.status }) }),
            /* @__PURE__ */ jsx20("td", { className: "px-4 py-4", children: /* @__PURE__ */ jsxs17("div", { className: "flex flex-col", children: [
              /* @__PURE__ */ jsx20("span", { className: "text-xs font-semibold", children: order.paymentMethod }),
              /* @__PURE__ */ jsx20("span", { className: `text-[10px] ${order.isPaid ? "text-green-600" : "text-orange-600"}`, children: order.isPaid ? "\u25CF Paid" : "\u25CB Unpaid" })
            ] }) }),
            /* @__PURE__ */ jsxs17("td", { className: "px-4 py-4 font-bold text-navy text-right", children: [
              "\u20B9",
              order.totalAmount
            ] })
          ] }, order.id)),
          filteredOrders.length === 0 && /* @__PURE__ */ jsx20("tr", { children: /* @__PURE__ */ jsx20("td", { colSpan: 5, className: "px-4 py-12 text-center text-muted-foreground", children: /* @__PURE__ */ jsxs17("div", { className: "flex flex-col items-center gap-2", children: [
            /* @__PURE__ */ jsx20(ShoppingCart2, { className: "size-8 opacity-20" }),
            /* @__PURE__ */ jsx20("p", { children: "No orders found for this period." })
          ] }) }) })
        ] })
      ] }) })
    ] })
  ] }) });
}
var init_dashboard_BRCwi_3B = __esm({
  "dist/server/assets/dashboard-BRCwi-3B.js"() {
    "use strict";
    init_orders_BJKg52UO();
    init_router_B40ruYtd();
    init_products_DDA9Kbv3();
    init_card_DK4TJU2r();
    init_select_B91GfZkm();
    init_ErrorBoundary_BtGZJTax();
    init_adminFilter_Clv2cQDi();
  }
});

// dist/server/assets/cms-fE21DlOM.js
var cms_fE21DlOM_exports = {};
__export(cms_fE21DlOM_exports, {
  component: () => CMSPage
});
import { jsx as jsx21, jsxs as jsxs18, Fragment as Fragment5 } from "react/jsx-runtime";
import { useState as useState13 } from "react";
import { Loader2 as Loader28, Layout, Save as Save3, Globe, Image, Trash2 as Trash25, Plus as Plus4, Star as Star2, Phone as Phone7, Mail as Mail2, MapPin as MapPin6, Link as Link7, Instagram as Instagram2, Facebook as Facebook2, MessageCircle as MessageCircle4, Youtube as Youtube2, Twitter as Twitter2 } from "lucide-react";
import { toast as toast13 } from "sonner";
import "@tanstack/react-router";
import "zustand";
import "firebase/database";
import "firebase/app";
import "firebase/auth";
import "firebase/firestore";
import "firebase/analytics";
import "zustand/middleware";
import "@imagekit/javascript";
function CMSPage() {
  const settings = useSiteSettings();
  const [heroHeadingInput, setHeroHeadingInput] = useState13("");
  const [heroTaglineInput, setHeroTaglineInput] = useState13("");
  const [heroButtonInput, setHeroButtonInput] = useState13("");
  const [newBannerImage, setNewBannerImage] = useState13("");
  const [footerDesc, setFooterDesc] = useState13("");
  const [footerCopy, setFooterCopy] = useState13("");
  const [mapsLinkInput, setMapsLinkInput] = useState13("");
  const [mapsLabelInput, setMapsLabelInput] = useState13("");
  const [socialInputs, setSocialInputs] = useState13({});
  if (settings.loading) {
    return /* @__PURE__ */ jsx21("div", { className: "h-[60vh] grid place-items-center", children: /* @__PURE__ */ jsxs18("div", { className: "flex flex-col items-center gap-4", children: [
      /* @__PURE__ */ jsx21(Loader28, { className: "size-10 animate-spin text-orange" }),
      /* @__PURE__ */ jsx21("p", { className: "text-muted-foreground animate-pulse", children: "Fetching site content..." })
    ] }) });
  }
  const handleSaveHeroText = () => {
    if (heroHeadingInput) settings.updateSetting("heroHeading", heroHeadingInput);
    if (heroTaglineInput) settings.updateSetting("heroTagline", heroTaglineInput);
    if (heroButtonInput) settings.updateSetting("heroButtonText", heroButtonInput);
    toast13.success("\u2705 Hero section updated! Changes are now live on the website.");
  };
  const handleSaveFooter = () => {
    if (footerDesc) settings.updateSetting("footerDescription", footerDesc);
    if (footerCopy) settings.updateSetting("footerCopyright", footerCopy);
    if (mapsLinkInput) {
      let url = mapsLinkInput.trim();
      if (url && !url.startsWith("http")) {
        url = "https://" + url;
      }
      settings.updateSetting("mapsLink", url);
    }
    if (mapsLabelInput) settings.updateSetting("mapsLabel", mapsLabelInput);
    Object.entries(socialInputs).forEach(([key, value]) => {
      settings.updateSocialLink(key, value);
    });
    toast13.success("\u2705 Footer settings updated!");
  };
  return /* @__PURE__ */ jsx21(ErrorBoundary, { children: /* @__PURE__ */ jsxs18("div", { className: "space-y-10 max-w-5xl pb-20", children: [
    /* @__PURE__ */ jsx21("div", { className: "flex flex-col sm:flex-row sm:items-center justify-between gap-6", children: /* @__PURE__ */ jsxs18("div", { children: [
      /* @__PURE__ */ jsx21("h1", { className: "text-2xl md:text-3xl font-display font-bold text-navy", children: "Website Editor" }),
      /* @__PURE__ */ jsx21("p", { className: "text-muted-foreground mt-1 text-sm md:text-base", children: "Updates reflect live on the website instantly." })
    ] }) }),
    /* @__PURE__ */ jsxs18("section", { className: "bg-card rounded-3xl border border-border overflow-hidden shadow-sm", children: [
      /* @__PURE__ */ jsxs18("div", { className: "p-6 border-b border-border bg-secondary/30 flex items-center justify-between", children: [
        /* @__PURE__ */ jsxs18("div", { className: "flex items-center gap-3", children: [
          /* @__PURE__ */ jsx21(Layout, { className: "size-5 text-orange" }),
          /* @__PURE__ */ jsx21("h2", { className: "font-bold text-xl text-navy", children: "Hero Section" })
        ] }),
        /* @__PURE__ */ jsxs18("button", { onClick: handleSaveHeroText, className: "bg-orange text-navy px-6 py-2.5 rounded-full font-bold text-sm hover:bg-orange/80 transition-colors flex items-center gap-2 shadow-lg shadow-orange/20", children: [
          /* @__PURE__ */ jsx21(Save3, { className: "size-4" }),
          " Save Changes"
        ] })
      ] }),
      /* @__PURE__ */ jsxs18("div", { className: "p-6 grid md:grid-cols-2 gap-10", children: [
        /* @__PURE__ */ jsx21("div", { className: "space-y-6", children: /* @__PURE__ */ jsxs18("div", { className: "space-y-4", children: [
          /* @__PURE__ */ jsxs18("div", { children: [
            /* @__PURE__ */ jsx21("label", { className: "text-xs font-black uppercase tracking-widest text-navy/40 block mb-2", children: "Main Heading" }),
            /* @__PURE__ */ jsx21("input", { defaultValue: settings.heroHeading, onChange: (e) => setHeroHeadingInput(e.target.value), placeholder: "e.g. Renuka's H2 Batters", className: "w-full border rounded-xl p-3.5 text-sm focus:ring-4 focus:ring-orange/10 focus:border-orange outline-none transition-all" })
          ] }),
          /* @__PURE__ */ jsxs18("div", { children: [
            /* @__PURE__ */ jsx21("label", { className: "text-xs font-black uppercase tracking-widest text-navy/40 block mb-2", children: "Sub-heading / Tagline" }),
            /* @__PURE__ */ jsx21("textarea", { defaultValue: settings.heroTagline, onChange: (e) => setHeroTaglineInput(e.target.value), rows: 3, className: "w-full border rounded-xl p-3.5 text-sm focus:ring-4 focus:ring-orange/10 focus:border-orange outline-none transition-all resize-none" })
          ] }),
          /* @__PURE__ */ jsxs18("div", { children: [
            /* @__PURE__ */ jsx21("label", { className: "text-xs font-black uppercase tracking-widest text-navy/40 block mb-2", children: "Button Text" }),
            /* @__PURE__ */ jsx21("input", { defaultValue: settings.heroButtonText, onChange: (e) => setHeroButtonInput(e.target.value), className: "w-full border rounded-xl p-3.5 text-sm focus:ring-4 focus:ring-orange/10 focus:border-orange outline-none transition-all" })
          ] })
        ] }) }),
        /* @__PURE__ */ jsxs18("div", { className: "space-y-8", children: [
          /* @__PURE__ */ jsxs18("div", { className: "grid grid-cols-2 gap-4", children: [
            /* @__PURE__ */ jsxs18("div", { className: "space-y-2", children: [
              /* @__PURE__ */ jsx21(MediaUpload, { label: "Desktop Video", mediaType: "video", value: settings.heroVideoDesktop, onChange: (url) => settings.updateSetting("heroVideoDesktop", url), folder: "hero" }),
              /* @__PURE__ */ jsx21("p", { className: "text-[9px] text-center font-black uppercase tracking-widest text-muted-foreground", children: "16:9 Landscape" })
            ] }),
            /* @__PURE__ */ jsxs18("div", { className: "space-y-2", children: [
              /* @__PURE__ */ jsx21(MediaUpload, { label: "Mobile Video", mediaType: "video", value: settings.heroVideoMobile, onChange: (url) => settings.updateSetting("heroVideoMobile", url), folder: "hero" }),
              /* @__PURE__ */ jsx21("p", { className: "text-[9px] text-center font-black uppercase tracking-widest text-muted-foreground", children: "9:16 Portrait" })
            ] })
          ] }),
          /* @__PURE__ */ jsx21("div", { className: "p-4 bg-orange/5 rounded-2xl border border-dashed border-orange/20", children: /* @__PURE__ */ jsx21("p", { className: "text-[10px] text-navy/60 leading-relaxed font-bold italic", children: "\u{1F4A1} **Pro Tip**: Use a landscape video for Desktop and a portrait video for Mobile. This ensures your hero section remains cinematic and immersive on all screens." }) })
        ] })
      ] })
    ] }),
    /* @__PURE__ */ jsxs18("section", { className: "bg-card rounded-3xl border border-border overflow-hidden shadow-sm", children: [
      /* @__PURE__ */ jsx21("div", { className: "p-6 border-b border-border bg-secondary/30 flex items-center justify-between", children: /* @__PURE__ */ jsxs18("div", { className: "flex items-center gap-3", children: [
        /* @__PURE__ */ jsx21(Globe, { className: "size-5 text-orange" }),
        /* @__PURE__ */ jsx21("h2", { className: "font-bold text-xl text-navy", children: "Global Branding" })
      ] }) }),
      /* @__PURE__ */ jsxs18("div", { className: "p-6 space-y-10", children: [
        /* @__PURE__ */ jsxs18("div", { className: "grid md:grid-cols-2 gap-8", children: [
          /* @__PURE__ */ jsxs18("div", { className: "space-y-4", children: [
            /* @__PURE__ */ jsx21(MediaUpload, { label: "Official Logo (Platform Wide)", value: settings.logoUrl, onChange: (url) => settings.updateSetting("logoUrl", url), folder: "branding" }),
            /* @__PURE__ */ jsxs18("p", { className: "text-[11px] text-muted-foreground leading-relaxed", children: [
              "\u{1F4A1} This logo appears in the ",
              /* @__PURE__ */ jsx21("strong", { children: "Navbar, Admin Panel, Delivery App," }),
              " and all ",
              /* @__PURE__ */ jsx21("strong", { children: "Login Screens" }),
              ". Use a high-resolution PNG with transparency for best results."
            ] })
          ] }),
          /* @__PURE__ */ jsxs18("div", { className: "flex flex-col items-center justify-center p-8 bg-navy/5 rounded-[2rem] border border-dashed border-navy/10", children: [
            /* @__PURE__ */ jsx21("div", { className: "text-[10px] font-black uppercase tracking-widest text-navy/40 mb-6", children: "Logo Preview" }),
            /* @__PURE__ */ jsx21("div", { className: "bg-white p-8 rounded-2xl shadow-xl shadow-navy/5", children: /* @__PURE__ */ jsx21("img", { src: settings.logoUrl, alt: "Logo Preview", className: "h-24 w-auto object-contain" }) })
          ] })
        ] }),
        /* @__PURE__ */ jsxs18("div", { className: "grid md:grid-cols-2 gap-8 pt-10 border-t border-border", children: [
          /* @__PURE__ */ jsxs18("div", { className: "space-y-4", children: [
            /* @__PURE__ */ jsx21(MediaUpload, { label: "Browser Favicon / App Icon", value: settings.faviconUrl, onChange: (url) => settings.updateSetting("faviconUrl", url), folder: "branding" }),
            /* @__PURE__ */ jsxs18("p", { className: "text-[11px] text-muted-foreground leading-relaxed", children: [
              "\u{1F4A1} This icon appears in the ",
              /* @__PURE__ */ jsx21("strong", { children: "Browser Tab, Mobile Shortcuts," }),
              " and ",
              /* @__PURE__ */ jsx21("strong", { children: "PWA Home Screen" }),
              ". A square 512x512px image is recommended."
            ] })
          ] }),
          /* @__PURE__ */ jsxs18("div", { className: "flex flex-col items-center justify-center p-8 bg-orange/5 rounded-[2rem] border border-dashed border-orange/10", children: [
            /* @__PURE__ */ jsx21("div", { className: "text-[10px] font-black uppercase tracking-widest text-orange/60 mb-6", children: "Favicon Preview" }),
            /* @__PURE__ */ jsx21("div", { className: "size-16 bg-white rounded-xl shadow-lg shadow-orange/10 overflow-hidden grid place-items-center", children: /* @__PURE__ */ jsx21("img", { src: settings.faviconUrl, alt: "Favicon Preview", className: "size-12 object-contain" }) }),
            /* @__PURE__ */ jsx21("p", { className: "mt-4 text-[9px] font-bold text-muted-foreground uppercase tracking-widest", children: "Tab Preview Rendering" })
          ] })
        ] })
      ] })
    ] }),
    /* @__PURE__ */ jsxs18("section", { className: "bg-card rounded-3xl border border-border overflow-hidden shadow-sm", children: [
      /* @__PURE__ */ jsxs18("div", { className: "p-6 border-b border-border bg-secondary/30 flex items-center justify-between", children: [
        /* @__PURE__ */ jsxs18("div", { className: "flex items-center gap-3", children: [
          /* @__PURE__ */ jsx21(Image, { className: "size-5 text-orange" }),
          /* @__PURE__ */ jsx21("h2", { className: "font-bold text-xl text-navy", children: "Today's Menu Management" })
        ] }),
        /* @__PURE__ */ jsxs18("div", { className: "text-[10px] font-black uppercase tracking-widest text-muted-foreground px-3 py-1 bg-white/50 rounded-full border border-border", children: [
          settings.todayMenu?.length || 0,
          " / 3 Items"
        ] })
      ] }),
      /* @__PURE__ */ jsxs18("div", { className: "p-6 space-y-8", children: [
        /* @__PURE__ */ jsx21("div", { className: "grid grid-cols-3 gap-6", children: [...Array(3)].map((_, i) => {
          const item = settings.todayMenu?.[i];
          return /* @__PURE__ */ jsxs18("div", { className: "space-y-3", children: [
            /* @__PURE__ */ jsx21("div", { className: "aspect-[3/4] rounded-2xl border-2 border-dashed border-border bg-secondary/20 overflow-hidden relative group", children: item ? /* @__PURE__ */ jsxs18(Fragment5, { children: [
              /* @__PURE__ */ jsx21("img", { src: item.image, className: "w-full h-full object-cover" }),
              /* @__PURE__ */ jsx21("button", { onClick: () => settings.removeTodayMenu(item.id), className: "absolute top-2 right-2 size-8 rounded-xl bg-red-500 text-white grid place-items-center opacity-0 group-hover:opacity-100 transition-all hover:scale-110 shadow-lg", children: /* @__PURE__ */ jsx21(Trash25, { className: "size-4" }) })
            ] }) : /* @__PURE__ */ jsxs18("div", { className: "size-full flex flex-col items-center justify-center p-4 text-center", children: [
              /* @__PURE__ */ jsx21(Plus4, { className: "size-8 text-muted-foreground/30 mb-2" }),
              /* @__PURE__ */ jsxs18("span", { className: "text-[10px] font-bold text-muted-foreground/50 uppercase tracking-widest leading-tight", children: [
                "Slot ",
                i + 1,
                /* @__PURE__ */ jsx21("br", {}),
                "Empty"
              ] })
            ] }) }),
            !item && /* @__PURE__ */ jsx21(MediaUpload, { label: `Upload Menu ${i + 1}`, value: "", onChange: (url) => settings.addTodayMenu({
              id: Math.random().toString(36).substr(2, 9),
              image: url
            }), folder: "menu" })
          ] }, i);
        }) }),
        /* @__PURE__ */ jsx21("p", { className: "text-[11px] text-center text-muted-foreground bg-orange/5 border border-orange/20 rounded-xl px-4 py-3", children: "\u{1F4A1} **Menu Strategy**: These images should be **Portrait (3:4)** ratio for a clean mobile display. Only 3 slots are available to maintain a high-quality, focused UI." })
      ] })
    ] }),
    /* @__PURE__ */ jsxs18("section", { className: "bg-card rounded-3xl border border-border overflow-hidden shadow-sm", children: [
      /* @__PURE__ */ jsxs18("div", { className: "p-6 border-b border-border bg-secondary/30 flex items-center gap-3", children: [
        /* @__PURE__ */ jsx21(Star2, { className: "size-5 text-orange" }),
        /* @__PURE__ */ jsx21("h2", { className: "font-bold text-xl text-navy", children: "Customer Reviews" })
      ] }),
      /* @__PURE__ */ jsxs18("div", { className: "p-6 space-y-6", children: [
        /* @__PURE__ */ jsx21("div", { className: "grid md:grid-cols-2 gap-4", children: (settings.reviews || []).map((r) => /* @__PURE__ */ jsxs18("div", { className: "p-4 bg-secondary/20 rounded-2xl border border-border relative group", children: [
          /* @__PURE__ */ jsx21("div", { className: "flex items-center gap-1 mb-2", children: [...Array(5)].map((_, i) => /* @__PURE__ */ jsx21(Star2, { className: `size-3 ${i < (r.rating || 0) ? "fill-orange text-orange" : "text-muted-foreground/30"}` }, i)) }),
          /* @__PURE__ */ jsxs18("p", { className: "text-sm text-navy italic mb-2", children: [
            '"',
            r.text,
            '"'
          ] }),
          /* @__PURE__ */ jsxs18("div", { className: "text-xs font-bold text-navy", children: [
            r.name,
            ", ",
            r.city
          ] }),
          /* @__PURE__ */ jsx21("button", { onClick: () => settings.removeReview(r.id), className: "absolute top-4 right-4 text-muted-foreground hover:text-red-500 opacity-0 group-hover:opacity-100 transition-opacity", children: /* @__PURE__ */ jsx21(Trash25, { className: "size-4" }) })
        ] }, r.id)) }),
        /* @__PURE__ */ jsxs18("form", { className: "bg-secondary/30 p-6 rounded-2xl border border-border grid grid-cols-2 md:grid-cols-4 gap-4", onSubmit: (e) => {
          e.preventDefault();
          const form = new FormData(e.currentTarget);
          settings.addReview({
            id: Math.random().toString(36).substr(2, 9),
            name: form.get("name"),
            city: form.get("city"),
            rating: Number(form.get("rating")),
            text: form.get("text")
          });
          e.target.reset();
          toast13.success("Review added!");
        }, children: [
          /* @__PURE__ */ jsxs18("div", { className: "space-y-4 col-span-2", children: [
            /* @__PURE__ */ jsx21("textarea", { name: "text", required: true, placeholder: "Review Text", rows: 2, className: "w-full border rounded-xl p-3 text-sm" }),
            /* @__PURE__ */ jsxs18("div", { className: "flex gap-4", children: [
              /* @__PURE__ */ jsx21("input", { name: "name", required: true, placeholder: "Customer Name", className: "flex-1 border rounded-xl p-2.5 text-sm" }),
              /* @__PURE__ */ jsx21("input", { name: "city", required: true, placeholder: "City", className: "flex-1 border rounded-xl p-2.5 text-sm" })
            ] })
          ] }),
          /* @__PURE__ */ jsxs18("div", { className: "space-y-4 flex flex-col justify-between col-span-2 md:col-span-1", children: [
            /* @__PURE__ */ jsxs18("div", { className: "space-y-2", children: [
              /* @__PURE__ */ jsx21("label", { className: "text-[10px] font-bold uppercase text-muted-foreground", children: "Rating" }),
              /* @__PURE__ */ jsxs18("select", { name: "rating", className: "w-full border rounded-xl p-2.5 text-sm", children: [
                /* @__PURE__ */ jsx21("option", { value: "5", children: "5 Stars" }),
                /* @__PURE__ */ jsx21("option", { value: "4", children: "4 Stars" }),
                /* @__PURE__ */ jsx21("option", { value: "3", children: "3 Stars" })
              ] })
            ] }),
            /* @__PURE__ */ jsxs18("button", { type: "submit", className: "w-full bg-navy text-white py-3 rounded-xl font-bold hover:bg-orange transition-colors flex items-center justify-center gap-2", children: [
              /* @__PURE__ */ jsx21(Plus4, { className: "size-4" }),
              " Add Review"
            ] })
          ] })
        ] })
      ] })
    ] }),
    /* @__PURE__ */ jsxs18("section", { className: "bg-card rounded-3xl border border-border overflow-hidden shadow-sm", children: [
      /* @__PURE__ */ jsxs18("div", { className: "p-6 border-b border-border bg-secondary/30 flex items-center gap-3", children: [
        /* @__PURE__ */ jsx21(Phone7, { className: "size-5 text-orange" }),
        /* @__PURE__ */ jsx21("h2", { className: "font-bold text-xl text-navy", children: "Contact Details" })
      ] }),
      /* @__PURE__ */ jsxs18("form", { onSubmit: (e) => {
        e.preventDefault();
        const form = new FormData(e.currentTarget);
        settings.updateSetting("contactPhone", form.get("phone"));
        settings.updateSetting("contactEmail", form.get("email"));
        settings.updateSetting("contactAddress", form.get("address"));
        toast13.success("Contact details updated!");
      }, className: "p-6 grid md:grid-cols-3 gap-6", children: [
        /* @__PURE__ */ jsxs18("div", { children: [
          /* @__PURE__ */ jsx21("label", { className: "text-xs font-bold uppercase text-muted-foreground block mb-1.5", children: "Phone Number" }),
          /* @__PURE__ */ jsxs18("div", { className: "relative", children: [
            /* @__PURE__ */ jsx21(Phone7, { className: "absolute left-3 top-1/2 -translate-y-1/2 size-4 text-muted-foreground" }),
            /* @__PURE__ */ jsx21("input", { name: "phone", defaultValue: settings.contactPhone, className: "w-full border rounded-xl p-3 pl-10 text-sm" })
          ] })
        ] }),
        /* @__PURE__ */ jsxs18("div", { children: [
          /* @__PURE__ */ jsx21("label", { className: "text-xs font-bold uppercase text-muted-foreground block mb-1.5", children: "Email Address" }),
          /* @__PURE__ */ jsxs18("div", { className: "relative", children: [
            /* @__PURE__ */ jsx21(Mail2, { className: "absolute left-3 top-1/2 -translate-y-1/2 size-4 text-muted-foreground" }),
            /* @__PURE__ */ jsx21("input", { name: "email", defaultValue: settings.contactEmail, className: "w-full border rounded-xl p-3 pl-10 text-sm" })
          ] })
        ] }),
        /* @__PURE__ */ jsxs18("div", { className: "flex flex-col", children: [
          /* @__PURE__ */ jsx21("label", { className: "text-xs font-bold uppercase text-muted-foreground block mb-1.5", children: "Address" }),
          /* @__PURE__ */ jsxs18("div", { className: "flex gap-2", children: [
            /* @__PURE__ */ jsxs18("div", { className: "relative flex-1", children: [
              /* @__PURE__ */ jsx21(MapPin6, { className: "absolute left-3 top-1/2 -translate-y-1/2 size-4 text-muted-foreground" }),
              /* @__PURE__ */ jsx21("input", { name: "address", defaultValue: settings.contactAddress, className: "w-full border rounded-xl p-3 pl-10 text-sm" })
            ] }),
            /* @__PURE__ */ jsx21("button", { type: "submit", className: "bg-navy text-white px-6 rounded-xl font-bold hover:bg-orange transition-colors", children: "Save" })
          ] })
        ] })
      ] })
    ] }),
    /* @__PURE__ */ jsxs18("section", { className: "bg-card rounded-3xl border border-border overflow-hidden shadow-sm", children: [
      /* @__PURE__ */ jsxs18("div", { className: "p-6 border-b border-border bg-secondary/30 flex items-center justify-between", children: [
        /* @__PURE__ */ jsxs18("div", { className: "flex items-center gap-3", children: [
          /* @__PURE__ */ jsx21(Globe, { className: "size-5 text-orange" }),
          /* @__PURE__ */ jsx21("h2", { className: "font-bold text-xl text-navy", children: "Footer Management" })
        ] }),
        /* @__PURE__ */ jsxs18("button", { onClick: handleSaveFooter, className: "bg-navy text-white px-6 py-2.5 rounded-full font-bold text-sm hover:bg-orange transition-colors flex items-center gap-2 shadow-lg shadow-navy/10", children: [
          /* @__PURE__ */ jsx21(Save3, { className: "size-4" }),
          " Update Footer"
        ] })
      ] }),
      /* @__PURE__ */ jsxs18("div", { className: "p-6 space-y-8", children: [
        /* @__PURE__ */ jsxs18("div", { children: [
          /* @__PURE__ */ jsx21("h3", { className: "text-sm font-bold text-navy uppercase tracking-widest mb-4", children: "Footer Content" }),
          /* @__PURE__ */ jsxs18("div", { className: "grid md:grid-cols-2 gap-4", children: [
            /* @__PURE__ */ jsxs18("div", { children: [
              /* @__PURE__ */ jsx21("label", { className: "text-xs font-bold uppercase text-muted-foreground block mb-1.5", children: "Footer Description" }),
              /* @__PURE__ */ jsx21("textarea", { defaultValue: settings.footerDescription, onChange: (e) => setFooterDesc(e.target.value), rows: 3, placeholder: "Short description shown below the logo", className: "w-full border rounded-xl p-3 text-sm focus:ring-2 focus:ring-orange/20 focus:border-orange outline-none" })
            ] }),
            /* @__PURE__ */ jsxs18("div", { children: [
              /* @__PURE__ */ jsx21("label", { className: "text-xs font-bold uppercase text-muted-foreground block mb-1.5", children: "Copyright Text" }),
              /* @__PURE__ */ jsx21("input", { defaultValue: settings.footerCopyright, onChange: (e) => setFooterCopy(e.target.value), placeholder: "e.g. Renuka's H2 Batters. All rights reserved.", className: "w-full border rounded-xl p-3 text-sm focus:ring-2 focus:ring-orange/20 focus:border-orange outline-none" })
            ] })
          ] })
        ] }),
        /* @__PURE__ */ jsxs18("div", { children: [
          /* @__PURE__ */ jsxs18("h3", { className: "text-sm font-bold text-navy uppercase tracking-widest mb-4 flex items-center gap-2", children: [
            /* @__PURE__ */ jsx21(MapPin6, { className: "size-4 text-orange" }),
            " Office Location & Maps"
          ] }),
          /* @__PURE__ */ jsxs18("div", { className: "grid md:grid-cols-3 gap-4", children: [
            /* @__PURE__ */ jsxs18("div", { children: [
              /* @__PURE__ */ jsx21("label", { className: "text-xs font-bold uppercase text-muted-foreground block mb-1.5", children: "Maps Link Label" }),
              /* @__PURE__ */ jsx21("input", { defaultValue: settings.mapsLabel, onChange: (e) => setMapsLabelInput(e.target.value), placeholder: "e.g. Visit Our Kitchen", className: "w-full border rounded-xl p-3 text-sm focus:ring-2 focus:ring-orange/20 focus:border-orange outline-none" })
            ] }),
            /* @__PURE__ */ jsxs18("div", { className: "md:col-span-2", children: [
              /* @__PURE__ */ jsx21("label", { className: "text-xs font-bold uppercase text-muted-foreground block mb-1.5", children: "Google Maps Link" }),
              /* @__PURE__ */ jsxs18("div", { className: "flex gap-2", children: [
                /* @__PURE__ */ jsx21("input", { defaultValue: settings.mapsLink, onChange: (e) => setMapsLinkInput(e.target.value), placeholder: "https://maps.google.com/...", className: "flex-1 border rounded-xl p-3 text-sm focus:ring-2 focus:ring-orange/20 focus:border-orange outline-none" }),
                settings.mapsLink && /* @__PURE__ */ jsxs18("a", { href: settings.mapsLink, target: "_blank", className: "bg-secondary px-4 rounded-xl text-xs font-bold text-navy hover:bg-orange hover:text-white transition-colors flex items-center gap-1.5", children: [
                  /* @__PURE__ */ jsx21(MapPin6, { className: "size-3.5" }),
                  " Preview"
                ] })
              ] })
            ] })
          ] })
        ] }),
        /* @__PURE__ */ jsxs18("div", { children: [
          /* @__PURE__ */ jsxs18("h3", { className: "text-sm font-bold text-navy uppercase tracking-widest mb-4 flex items-center gap-2", children: [
            /* @__PURE__ */ jsx21(Link7, { className: "size-4 text-orange" }),
            " Social Media Links"
          ] }),
          /* @__PURE__ */ jsx21("div", { className: "grid sm:grid-cols-2 md:grid-cols-3 gap-4", children: [{
            key: "instagram",
            icon: Instagram2,
            label: "Instagram",
            placeholder: "https://instagram.com/...",
            color: "text-pink-500"
          }, {
            key: "facebook",
            icon: Facebook2,
            label: "Facebook",
            placeholder: "https://facebook.com/...",
            color: "text-blue-600"
          }, {
            key: "whatsapp",
            icon: MessageCircle4,
            label: "WhatsApp Number",
            placeholder: "+91 99999 00000",
            color: "text-green-500"
          }, {
            key: "youtube",
            icon: Youtube2,
            label: "YouTube",
            placeholder: "https://youtube.com/...",
            color: "text-red-500"
          }, {
            key: "twitter",
            icon: Twitter2,
            label: "Twitter / X",
            placeholder: "https://x.com/...",
            color: "text-sky-500"
          }].map(({
            key,
            icon: Icon2,
            label,
            placeholder,
            color
          }) => /* @__PURE__ */ jsxs18("div", { children: [
            /* @__PURE__ */ jsxs18("label", { className: "text-xs font-bold uppercase text-muted-foreground flex items-center gap-1.5 mb-1.5", children: [
              /* @__PURE__ */ jsx21(Icon2, { className: `size-3.5 ${color}` }),
              " ",
              label
            ] }),
            /* @__PURE__ */ jsx21("input", { defaultValue: settings.socialLinks?.[key] || "", onChange: (e) => setSocialInputs((prev) => ({
              ...prev,
              [key]: e.target.value
            })), placeholder, className: "w-full border rounded-xl p-3 text-sm focus:ring-2 focus:ring-orange/20 focus:border-orange outline-none" })
          ] }, key)) }),
          /* @__PURE__ */ jsx21("p", { className: "mt-3 text-[11px] text-muted-foreground bg-orange/5 border border-orange/20 rounded-xl px-3 py-2", children: "\u{1F4A1} Leave a field blank to hide that social icon in the footer. For WhatsApp, enter just the phone number (e.g. +919999900000)." })
        ] })
      ] })
    ] })
  ] }) });
}
var init_cms_fE21DlOM = __esm({
  "dist/server/assets/cms-fE21DlOM.js"() {
    "use strict";
    init_router_B40ruYtd();
    init_ErrorBoundary_BtGZJTax();
    init_MediaUpload_C6I_6V8U();
  }
});

// dist/server/assets/router-B40ruYtd.js
var router_B40ruYtd_exports = {};
__export(router_B40ruYtd_exports, {
  R: () => Route$9,
  a: () => useAdminAuth,
  b: () => useSiteSettings,
  c: () => router,
  p: () => products,
  r: () => rtdb,
  u: () => useDeliveryAuth
});
import { jsx as jsx22, jsxs as jsxs19, Fragment as Fragment6 } from "react/jsx-runtime";
import { createRootRoute, Link as Link8, Outlet as Outlet3, HeadContent, Scripts, createFileRoute, lazyRouteComponent, redirect, createRouter, useRouter as useRouter5 } from "@tanstack/react-router";
import { Toaster as Toaster$1 } from "sonner";
import { useEffect as useEffect4 } from "react";
import { create as create6 } from "zustand";
import { getDatabase, remove as remove4, ref as ref4, set as set4, update as update4, onValue as onValue4 } from "firebase/database";
import { getApps, initializeApp, getApp } from "firebase/app";
import { getAuth } from "firebase/auth";
import { getFirestore } from "firebase/firestore";
import { isSupported, getAnalytics } from "firebase/analytics";
import { persist as persist3 } from "zustand/middleware";
function NotFoundComponent() {
  return /* @__PURE__ */ jsx22("div", { className: "flex min-h-screen items-center justify-center bg-background px-4", children: /* @__PURE__ */ jsxs19("div", { className: "max-w-md text-center", children: [
    /* @__PURE__ */ jsx22("h1", { className: "text-7xl font-bold text-foreground", children: "404" }),
    /* @__PURE__ */ jsx22("h2", { className: "mt-4 text-xl font-semibold text-foreground", children: "Page not found" }),
    /* @__PURE__ */ jsx22("p", { className: "mt-2 text-sm text-muted-foreground", children: "The page you're looking for doesn't exist or has been moved." }),
    /* @__PURE__ */ jsx22("div", { className: "mt-6", children: /* @__PURE__ */ jsx22(
      Link8,
      {
        to: "/",
        className: "inline-flex items-center justify-center rounded-md bg-primary px-4 py-2 text-sm font-medium text-primary-foreground transition-colors hover:bg-primary/90",
        children: "Go home"
      }
    ) })
  ] }) });
}
function RootShell({ children }) {
  return /* @__PURE__ */ jsxs19("html", { lang: "en", children: [
    /* @__PURE__ */ jsx22("head", { children: /* @__PURE__ */ jsx22(HeadContent, {}) }),
    /* @__PURE__ */ jsxs19("body", { children: [
      children,
      /* @__PURE__ */ jsx22(Scripts, {})
    ] })
  ] });
}
function RootComponent() {
  const { faviconUrl } = useSiteSettings();
  useEffect4(() => {
    if (!faviconUrl) return;
    const updateIcons = () => {
      const buster = `v=${(/* @__PURE__ */ new Date()).setMinutes(0, 0, 0)}`;
      let iconLink = document.querySelector("link[rel~='icon']");
      if (!iconLink) {
        iconLink = document.createElement("link");
        iconLink.rel = "icon";
        document.head.appendChild(iconLink);
      }
      iconLink.href = `${faviconUrl}?${buster}`;
      let appleLink = document.querySelector("link[rel='apple-touch-icon']");
      if (!appleLink) {
        appleLink = document.createElement("link");
        appleLink.rel = "apple-touch-icon";
        document.head.appendChild(appleLink);
      }
      appleLink.href = `${faviconUrl}?${buster}`;
    };
    updateIcons();
  }, [faviconUrl]);
  return /* @__PURE__ */ jsxs19(Fragment6, { children: [
    /* @__PURE__ */ jsx22(Outlet3, {}),
    /* @__PURE__ */ jsx22(Toaster, { richColors: true, position: "top-center" })
  ] });
}
function DefaultErrorComponent({ error, reset }) {
  const router2 = useRouter5();
  return /* @__PURE__ */ jsx22("div", { className: "flex min-h-screen items-center justify-center bg-background px-4", children: /* @__PURE__ */ jsxs19("div", { className: "max-w-md text-center", children: [
    /* @__PURE__ */ jsx22("div", { className: "mx-auto mb-6 flex h-16 w-16 items-center justify-center rounded-full bg-destructive/10", children: /* @__PURE__ */ jsx22(
      "svg",
      {
        xmlns: "http://www.w3.org/2000/svg",
        className: "h-8 w-8 text-destructive",
        fill: "none",
        viewBox: "0 0 24 24",
        stroke: "currentColor",
        strokeWidth: 2,
        children: /* @__PURE__ */ jsx22(
          "path",
          {
            strokeLinecap: "round",
            strokeLinejoin: "round",
            d: "M12 9v3.75m-9.303 3.376c-.866 1.5.217 3.374 1.948 3.374h14.71c1.73 0 2.813-1.874 1.948-3.374L13.949 3.378c-.866-1.5-3.032-1.5-3.898 0L2.697 16.126ZM12 15.75h.007v.008H12v-.008Z"
          }
        )
      }
    ) }),
    /* @__PURE__ */ jsx22("h1", { className: "text-2xl font-bold tracking-tight text-foreground", children: "Something went wrong" }),
    /* @__PURE__ */ jsx22("p", { className: "mt-2 text-sm text-muted-foreground", children: "An unexpected error occurred. Please try again." }),
    false,
    /* @__PURE__ */ jsxs19("div", { className: "mt-6 flex items-center justify-center gap-3", children: [
      /* @__PURE__ */ jsx22(
        "button",
        {
          onClick: () => {
            router2.invalidate();
            reset();
          },
          className: "inline-flex items-center justify-center rounded-md bg-primary px-4 py-2 text-sm font-medium text-primary-foreground transition-colors hover:bg-primary/90",
          children: "Try again"
        }
      ),
      /* @__PURE__ */ jsx22(
        "a",
        {
          href: "/",
          className: "inline-flex items-center justify-center rounded-md border border-input bg-background px-4 py-2 text-sm font-medium text-foreground transition-colors hover:bg-accent",
          children: "Go home"
        }
      )
    ] })
  ] }) });
}
var Toaster, firebaseConfig, app, rtdb, products, reviews, defaultSettings, useSiteSettings, settingsRef, appCss, Route$f, useDeliveryAuth, $$splitComponentImporter$e, Route$e, $$splitComponentImporter$d, Route$d, useAdminAuth, $$splitComponentImporter$c, Route$c, $$splitComponentImporter$b, Route$b, $$splitComponentImporter$a, Route$a, $$splitComponentImporter$9, Route$9, $$splitComponentImporter$8, Route$8, $$splitComponentImporter$7, Route$7, $$splitComponentImporter$6, Route$6, $$splitComponentImporter$5, Route$5, $$splitComponentImporter$4, Route$4, $$splitComponentImporter$3, Route$3, $$splitComponentImporter$2, Route$2, $$splitComponentImporter$1, Route$1, $$splitComponentImporter, Route, DeliveryRoute, CheckoutRoute, AdminRoute, IndexRoute, DeliveryIndexRoute, OrderSuccessIdRoute, DeliveryLoginRoute, AdminProductsRoute, AdminPaymentsRoute, AdminOrdersRoute, AdminLoginRoute, AdminEnquiriesRoute, AdminDeliveryRoute, AdminDashboardRoute, AdminCmsRoute, AdminRouteChildren, AdminRouteWithChildren, DeliveryRouteChildren, DeliveryRouteWithChildren, rootRouteChildren, routeTree, getRouter, router;
var init_router_B40ruYtd = __esm({
  "dist/server/assets/router-B40ruYtd.js"() {
    "use strict";
    Toaster = ({ ...props }) => {
      return /* @__PURE__ */ jsx22(
        Toaster$1,
        {
          className: "toaster group",
          toastOptions: {
            classNames: {
              toast: "group toast group-[.toaster]:bg-background group-[.toaster]:text-foreground group-[.toaster]:border-border group-[.toaster]:shadow-lg",
              description: "group-[.toast]:text-muted-foreground",
              actionButton: "group-[.toast]:bg-primary group-[.toast]:text-primary-foreground",
              cancelButton: "group-[.toast]:bg-muted group-[.toast]:text-muted-foreground"
            }
          },
          ...props
        }
      );
    };
    firebaseConfig = {
      apiKey: "AIzaSyA9qRo0skHU0qoVjKv_KPpFBsWA4C0ruUo",
      authDomain: "h2battersrjy.firebaseapp.com",
      projectId: "h2battersrjy",
      storageBucket: "h2battersrjy.firebasestorage.app",
      messagingSenderId: "364194610365",
      appId: "1:364194610365:web:85d0a7a943db0692d28bd4",
      databaseURL: "https://h2battersrjy-default-rtdb.firebaseio.com"
    };
    app = getApps().length === 0 ? initializeApp(firebaseConfig) : getApp();
    getAuth(app);
    getFirestore(app);
    rtdb = getDatabase(app);
    isSupported().then(
      (supported) => supported ? getAnalytics(app) : null
    );
    products = [
      {
        id: "idli",
        name: "Idli Batter",
        description: "Soft, fluffy, fermented overnight with premium urad dal & idli rice.",
        image: "https://images.unsplash.com/photo-1668236543090-82eba5ee5976?w=900&auto=format&fit=crop",
        pricePerKg: 120,
        pricePerHalfKg: 65,
        category: "Classic",
        stockQuantity: 50,
        inStock: true
      },
      {
        id: "dosa",
        name: "Dosa Batter",
        description: "Crispy golden dosas every time. Stone-ground, naturally fermented.",
        image: "https://images.unsplash.com/photo-1694849789325-914f49a4d108?w=900&auto=format&fit=crop",
        pricePerKg: 130,
        pricePerHalfKg: 70,
        category: "Classic",
        stockQuantity: 40,
        inStock: true
      },
      {
        id: "rava",
        name: "Rava Idli Mix",
        description: "Quick and soft rava idlis with the perfect tang. Ready in minutes.",
        image: "https://images.unsplash.com/photo-1589301760014-d929f3979dbc?w=900&auto=format&fit=crop",
        pricePerKg: 140,
        pricePerHalfKg: 75,
        category: "Mixes",
        stockQuantity: 30,
        inStock: true
      },
      {
        id: "ragi",
        name: "Ragi Dosa Batter",
        description: "Wholesome finger millet batter, naturally rich in iron and fibre.",
        image: "https://images.unsplash.com/photo-1666887360742-974c8fce8e6b?w=900&auto=format&fit=crop",
        pricePerKg: 150,
        pricePerHalfKg: 80,
        category: "Healthy",
        stockQuantity: 25,
        inStock: true
      },
      {
        id: "uttapam",
        name: "Uttapam Batter",
        description: "Thick, soft, and perfect for loaded veggie uttapams.",
        image: "https://images.unsplash.com/photo-1668665771445-93066f9b8e1d?w=900&auto=format&fit=crop",
        pricePerKg: 130,
        pricePerHalfKg: 70,
        category: "Classic",
        stockQuantity: 35,
        inStock: true
      },
      {
        id: "paniyaram",
        name: "Paniyaram Batter",
        description: "Spiced and ready to pour. Crispy outside, soft inside.",
        image: "https://images.unsplash.com/photo-1631452180519-c014fe946bc7?w=900&auto=format&fit=crop",
        pricePerKg: 140,
        pricePerHalfKg: 75,
        category: "Classic",
        stockQuantity: 20,
        inStock: true
      }
    ];
    reviews = [
      {
        id: "r1",
        name: "Priya Nair",
        rating: 5,
        text: "The fluffiest idlis I've made at home. Tastes exactly like my amma's recipe.",
        city: "Bengaluru"
      },
      {
        id: "r2",
        name: "Karthik R",
        rating: 5,
        text: "Crispy dosas every single time. Delivery was on time and packaging was great.",
        city: "Chennai"
      },
      {
        id: "r3",
        name: "Anjali Iyer",
        rating: 4,
        text: "Love the ragi batter \u2014 feels healthier and the kids actually enjoy it.",
        city: "Coimbatore"
      },
      {
        id: "r4",
        name: "Suresh Menon",
        rating: 5,
        text: "Switched from store-bought packets months ago. Never going back.",
        city: "Hyderabad"
      }
    ];
    defaultSettings = {
      logoUrl: "https://ik.imagekit.io/h2batters/logo-h2.png",
      faviconUrl: "https://ik.imagekit.io/h2batters/logo-h2.png",
      heroHeading: "Renuka's H2 Batters",
      heroTagline: "Add related tagline below",
      heroButtonText: "Order Now",
      heroVideoDesktop: "https://vimeo.com/external/406634811.sd.mp4?s=d0ea1a205a2b3dfbc4f4fae5138f619e09d1d8cf&profile_id=164&oauth2_token_id=57447761",
      heroVideoMobile: "",
      todayMenu: [],
      contactPhone: "+91 90000 12345",
      contactEmail: "hello@renukasbatters.in",
      contactAddress: "Bengaluru, Karnataka",
      footerDescription: "Stone-ground, naturally fermented batter delivered to your door every morning.",
      footerCopyright: "Renuka's H2 Batters. All rights reserved.",
      mapsLink: "",
      mapsLabel: "Visit Our Kitchen",
      socialLinks: { instagram: "", facebook: "", whatsapp: "", youtube: "", twitter: "" },
      reviews,
      enquiries: []
    };
    useSiteSettings = create6()((set$1, get) => ({
      ...defaultSettings,
      loading: true,
      _setSettings: (settings) => set$1({ ...settings, loading: false }),
      updateSetting: (key, value) => {
        set$1({ [key]: value });
        update4(ref4(rtdb, "siteSettings"), { [key]: value });
      },
      updateSocialLink: (platform, url) => {
        const current = get().socialLinks || {};
        const updated = { ...current, [platform]: url };
        set$1({ socialLinks: updated });
        update4(ref4(rtdb, "siteSettings/socialLinks"), { [platform]: url });
      },
      addTodayMenu: (item) => {
        const currentMenu = get().todayMenu || [];
        if (currentMenu.length >= 3) return;
        const newMenu = [...currentMenu, item];
        set$1({ todayMenu: newMenu });
        set4(ref4(rtdb, "siteSettings/todayMenu"), newMenu);
      },
      removeTodayMenu: (id) => {
        const newMenu = (get().todayMenu || []).filter((i) => i.id !== id);
        set$1({ todayMenu: newMenu });
        set4(ref4(rtdb, "siteSettings/todayMenu"), newMenu);
      },
      addReview: (review) => {
        const newReviews = [...get().reviews, review];
        set$1({ reviews: newReviews });
        set4(ref4(rtdb, "siteSettings/reviews"), newReviews);
      },
      removeReview: (id) => {
        const newReviews = get().reviews.filter((r) => r.id !== id);
        set$1({ reviews: newReviews });
        set4(ref4(rtdb, "siteSettings/reviews"), newReviews);
      },
      addEnquiry: (enquiryData) => {
        const id = Math.random().toString(36).substr(2, 9);
        const newEnquiry = {
          ...enquiryData,
          id,
          date: (/* @__PURE__ */ new Date()).toISOString(),
          isRead: false
        };
        const newEnquiries = [newEnquiry, ...get().enquiries];
        set$1({ enquiries: newEnquiries });
        set4(ref4(rtdb, "siteSettings/enquiries"), newEnquiries);
      },
      updateEnquiryStatus: (id, isRead) => {
        const newEnquiries = get().enquiries.map(
          (e) => e.id === id ? { ...e, isRead } : e
        );
        set$1({ enquiries: newEnquiries });
        set4(ref4(rtdb, "siteSettings/enquiries"), newEnquiries);
      },
      removeEnquiry: (id) => {
        const newEnquiries = get().enquiries.filter((e) => e.id !== id);
        set$1({ enquiries: newEnquiries });
        set4(ref4(rtdb, "siteSettings/enquiries"), newEnquiries);
      },
      clearAllEnquiries: () => {
        set$1({ enquiries: [] });
        remove4(ref4(rtdb, "siteSettings/enquiries"));
      }
    }));
    settingsRef = ref4(rtdb, "siteSettings");
    onValue4(settingsRef, (snapshot) => {
      const data = snapshot.val();
      if (data) {
        useSiteSettings.getState()._setSettings({
          logoUrl: data.logoUrl ?? defaultSettings.logoUrl,
          faviconUrl: data.faviconUrl ?? defaultSettings.faviconUrl,
          heroHeading: data.heroHeading ?? defaultSettings.heroHeading,
          heroTagline: data.heroTagline ?? defaultSettings.heroTagline,
          heroButtonText: data.heroButtonText ?? defaultSettings.heroButtonText,
          heroVideoDesktop: data.heroVideoDesktop ?? defaultSettings.heroVideoDesktop,
          heroVideoMobile: data.heroVideoMobile ?? defaultSettings.heroVideoMobile,
          todayMenu: data.todayMenu ?? defaultSettings.todayMenu,
          contactPhone: data.contactPhone ?? defaultSettings.contactPhone,
          contactEmail: data.contactEmail ?? defaultSettings.contactEmail,
          contactAddress: data.contactAddress ?? defaultSettings.contactAddress,
          footerDescription: data.footerDescription ?? defaultSettings.footerDescription,
          footerCopyright: data.footerCopyright ?? defaultSettings.footerCopyright,
          mapsLink: data.mapsLink ?? defaultSettings.mapsLink,
          mapsLabel: data.mapsLabel ?? defaultSettings.mapsLabel,
          socialLinks: data.socialLinks ?? defaultSettings.socialLinks,
          banners: data.banners ?? defaultSettings.banners,
          reviews: data.reviews ?? defaultSettings.reviews,
          enquiries: data.enquiries ?? defaultSettings.enquiries
        });
      } else {
        set4(settingsRef, defaultSettings);
      }
    });
    appCss = "/assets/styles-Be4oF47p.css";
    Route$f = createRootRoute({
      head: () => ({
        meta: [
          { charSet: "utf-8" },
          { name: "viewport", content: "width=device-width, initial-scale=1" },
          { title: "H2 Batters | Healthy & Homemade" },
          {
            name: "description",
            content: "Fresh, stone-ground, naturally fermented idli & dosa batter delivered daily."
          },
          { name: "theme-color", content: "#0A1A3F" },
          { property: "og:type", content: "website" },
          { name: "twitter:card", content: "summary_large_image" }
        ],
        links: [
          {
            rel: "stylesheet",
            href: appCss
          }
        ]
      }),
      shellComponent: RootShell,
      component: RootComponent,
      notFoundComponent: NotFoundComponent
    });
    useDeliveryAuth = create6()(
      persist3(
        (set22) => ({
          currentPartner: null,
          login: (partner) => set22({ currentPartner: partner }),
          logout: () => set22({ currentPartner: null })
        }),
        { name: "rhb-delivery-auth" }
      )
    );
    $$splitComponentImporter$e = () => Promise.resolve().then(() => (init_delivery_C_y7eiYc(), delivery_C_y7eiYc_exports));
    Route$e = createFileRoute("/delivery")({
      beforeLoad: ({
        location
      }) => {
        const isLogged = !!useDeliveryAuth.getState().currentPartner;
        if (!isLogged && location.pathname !== "/delivery/login") {
          throw redirect({
            to: "/delivery/login"
          });
        }
      },
      component: lazyRouteComponent($$splitComponentImporter$e, "component")
    });
    $$splitComponentImporter$d = () => Promise.resolve().then(() => (init_checkout_CUR7wfVc(), checkout_CUR7wfVc_exports));
    Route$d = createFileRoute("/checkout")({
      head: () => ({
        meta: [{
          title: "Checkout \u2014 Renuka's H2 Batters"
        }, {
          name: "description",
          content: "Complete your batter order."
        }]
      }),
      component: lazyRouteComponent($$splitComponentImporter$d, "component")
    });
    useAdminAuth = create6()(
      persist3(
        (set22) => ({
          isAdmin: false,
          login: (password) => {
            if (password === "Admin@H2") {
              set22({ isAdmin: true });
              return true;
            }
            return false;
          },
          logout: () => set22({ isAdmin: false })
        }),
        { name: "rhb-admin-auth" }
      )
    );
    $$splitComponentImporter$c = () => Promise.resolve().then(() => (init_admin_DnBpFsiP(), admin_DnBpFsiP_exports));
    Route$c = createFileRoute("/admin")({
      beforeLoad: ({
        location
      }) => {
        const isAdmin = useAdminAuth.getState().isAdmin;
        if (!isAdmin && location.pathname !== "/admin/login") {
          throw redirect({
            to: "/admin/login"
          });
        }
        if (isAdmin && (location.pathname === "/admin" || location.pathname === "/admin/")) {
          throw redirect({
            to: "/admin/dashboard"
          });
        }
      },
      component: lazyRouteComponent($$splitComponentImporter$c, "component")
    });
    $$splitComponentImporter$b = () => Promise.resolve().then(() => (init_index_BRS2E8Vh(), index_BRS2E8Vh_exports));
    Route$b = createFileRoute("/")({
      head: () => ({
        meta: [{
          title: "Renuka's H2 Batters \u2014 Fresh Idli & Dosa Batter, Daily"
        }, {
          name: "description",
          content: "Stone-ground, naturally fermented idli & dosa batter delivered fresh to your door every morning. Order now from Renuka's H2 Batters."
        }, {
          property: "og:title",
          content: "Renuka's H2 Batters"
        }, {
          property: "og:description",
          content: "Fresh, hand-crafted batter delivered daily."
        }]
      }),
      component: lazyRouteComponent($$splitComponentImporter$b, "component")
    });
    $$splitComponentImporter$a = () => Promise.resolve().then(() => (init_index_DuJXXynU(), index_DuJXXynU_exports));
    Route$a = createFileRoute("/delivery/")({
      component: lazyRouteComponent($$splitComponentImporter$a, "component")
    });
    $$splitComponentImporter$9 = () => Promise.resolve().then(() => (init_order_success_id_DOhIX4X4(), order_success_id_DOhIX4X4_exports));
    Route$9 = createFileRoute("/order-success/$id")({
      head: ({
        params
      }) => ({
        meta: [{
          title: `Order ${params.id} Confirmed \u2014 Renuka's H2 Batters`
        }, {
          name: "description",
          content: "Your order has been placed."
        }]
      }),
      component: lazyRouteComponent($$splitComponentImporter$9, "component")
    });
    $$splitComponentImporter$8 = () => Promise.resolve().then(() => (init_login_CWe5ffew(), login_CWe5ffew_exports));
    Route$8 = createFileRoute("/delivery/login")({
      component: lazyRouteComponent($$splitComponentImporter$8, "component")
    });
    $$splitComponentImporter$7 = () => Promise.resolve().then(() => (init_products_BVhow1KF(), products_BVhow1KF_exports));
    Route$7 = createFileRoute("/admin/products")({
      beforeLoad: () => {
        const isAdmin = useAdminAuth.getState().isAdmin;
        if (!isAdmin) {
          throw redirect({
            to: "/admin/login"
          });
        }
      },
      component: lazyRouteComponent($$splitComponentImporter$7, "component")
    });
    $$splitComponentImporter$6 = () => Promise.resolve().then(() => (init_payments_B4kqMjE2(), payments_B4kqMjE2_exports));
    Route$6 = createFileRoute("/admin/payments")({
      beforeLoad: () => {
        const isAdmin = useAdminAuth.getState().isAdmin;
        if (!isAdmin) {
          throw redirect({
            to: "/admin/login"
          });
        }
      },
      component: lazyRouteComponent($$splitComponentImporter$6, "component")
    });
    $$splitComponentImporter$5 = () => Promise.resolve().then(() => (init_orders_4x0FvsOb(), orders_4x0FvsOb_exports));
    Route$5 = createFileRoute("/admin/orders")({
      beforeLoad: () => {
        const isAdmin = useAdminAuth.getState().isAdmin;
        if (!isAdmin) {
          throw redirect({
            to: "/admin/login"
          });
        }
      },
      component: lazyRouteComponent($$splitComponentImporter$5, "component")
    });
    $$splitComponentImporter$4 = () => Promise.resolve().then(() => (init_login_BbJEHsxO(), login_BbJEHsxO_exports));
    Route$4 = createFileRoute("/admin/login")({
      component: lazyRouteComponent($$splitComponentImporter$4, "component")
    });
    $$splitComponentImporter$3 = () => Promise.resolve().then(() => (init_enquiries_B1twTlh2(), enquiries_B1twTlh2_exports));
    Route$3 = createFileRoute("/admin/enquiries")({
      beforeLoad: () => {
        const isAdmin = useAdminAuth.getState().isAdmin;
        if (!isAdmin) {
          throw redirect({
            to: "/admin/login"
          });
        }
      },
      component: lazyRouteComponent($$splitComponentImporter$3, "component")
    });
    $$splitComponentImporter$2 = () => Promise.resolve().then(() => (init_delivery_7VShiZL6(), delivery_7VShiZL6_exports));
    Route$2 = createFileRoute("/admin/delivery")({
      beforeLoad: () => {
        const isAdmin = useAdminAuth.getState().isAdmin;
        if (!isAdmin) {
          throw redirect({
            to: "/admin/login"
          });
        }
      },
      component: lazyRouteComponent($$splitComponentImporter$2, "component")
    });
    $$splitComponentImporter$1 = () => Promise.resolve().then(() => (init_dashboard_BRCwi_3B(), dashboard_BRCwi_3B_exports));
    Route$1 = createFileRoute("/admin/dashboard")({
      beforeLoad: () => {
        const isAdmin = useAdminAuth.getState().isAdmin;
        if (!isAdmin) {
          throw redirect({
            to: "/admin/login"
          });
        }
      },
      component: lazyRouteComponent($$splitComponentImporter$1, "component")
    });
    $$splitComponentImporter = () => Promise.resolve().then(() => (init_cms_fE21DlOM(), cms_fE21DlOM_exports));
    Route = createFileRoute("/admin/cms")({
      beforeLoad: () => {
        const isAdmin = useAdminAuth.getState().isAdmin;
        if (!isAdmin) {
          throw redirect({
            to: "/admin/login"
          });
        }
      },
      component: lazyRouteComponent($$splitComponentImporter, "component")
    });
    DeliveryRoute = Route$e.update({
      id: "/delivery",
      path: "/delivery",
      getParentRoute: () => Route$f
    });
    CheckoutRoute = Route$d.update({
      id: "/checkout",
      path: "/checkout",
      getParentRoute: () => Route$f
    });
    AdminRoute = Route$c.update({
      id: "/admin",
      path: "/admin",
      getParentRoute: () => Route$f
    });
    IndexRoute = Route$b.update({
      id: "/",
      path: "/",
      getParentRoute: () => Route$f
    });
    DeliveryIndexRoute = Route$a.update({
      id: "/",
      path: "/",
      getParentRoute: () => DeliveryRoute
    });
    OrderSuccessIdRoute = Route$9.update({
      id: "/order-success/$id",
      path: "/order-success/$id",
      getParentRoute: () => Route$f
    });
    DeliveryLoginRoute = Route$8.update({
      id: "/login",
      path: "/login",
      getParentRoute: () => DeliveryRoute
    });
    AdminProductsRoute = Route$7.update({
      id: "/products",
      path: "/products",
      getParentRoute: () => AdminRoute
    });
    AdminPaymentsRoute = Route$6.update({
      id: "/payments",
      path: "/payments",
      getParentRoute: () => AdminRoute
    });
    AdminOrdersRoute = Route$5.update({
      id: "/orders",
      path: "/orders",
      getParentRoute: () => AdminRoute
    });
    AdminLoginRoute = Route$4.update({
      id: "/login",
      path: "/login",
      getParentRoute: () => AdminRoute
    });
    AdminEnquiriesRoute = Route$3.update({
      id: "/enquiries",
      path: "/enquiries",
      getParentRoute: () => AdminRoute
    });
    AdminDeliveryRoute = Route$2.update({
      id: "/delivery",
      path: "/delivery",
      getParentRoute: () => AdminRoute
    });
    AdminDashboardRoute = Route$1.update({
      id: "/dashboard",
      path: "/dashboard",
      getParentRoute: () => AdminRoute
    });
    AdminCmsRoute = Route.update({
      id: "/cms",
      path: "/cms",
      getParentRoute: () => AdminRoute
    });
    AdminRouteChildren = {
      AdminCmsRoute,
      AdminDashboardRoute,
      AdminDeliveryRoute,
      AdminEnquiriesRoute,
      AdminLoginRoute,
      AdminOrdersRoute,
      AdminPaymentsRoute,
      AdminProductsRoute
    };
    AdminRouteWithChildren = AdminRoute._addFileChildren(AdminRouteChildren);
    DeliveryRouteChildren = {
      DeliveryLoginRoute,
      DeliveryIndexRoute
    };
    DeliveryRouteWithChildren = DeliveryRoute._addFileChildren(
      DeliveryRouteChildren
    );
    rootRouteChildren = {
      IndexRoute,
      AdminRoute: AdminRouteWithChildren,
      CheckoutRoute,
      DeliveryRoute: DeliveryRouteWithChildren,
      OrderSuccessIdRoute
    };
    routeTree = Route$f._addFileChildren(rootRouteChildren)._addFileTypes();
    getRouter = () => {
      const router2 = createRouter({
        routeTree,
        context: {},
        scrollRestoration: true,
        defaultPreloadStaleTime: 0,
        defaultErrorComponent: DefaultErrorComponent
      });
      return router2;
    };
    router = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
      __proto__: null,
      getRouter
    }, Symbol.toStringTag, { value: "Module" }));
  }
});

// dist/server/assets/start-HYkvq4Ni.js
var start_HYkvq4Ni_exports = {};
__export(start_HYkvq4Ni_exports, {
  startInstance: () => startInstance
});
var startInstance;
var init_start_HYkvq4Ni = __esm({
  "dist/server/assets/start-HYkvq4Ni.js"() {
    "use strict";
    startInstance = void 0;
  }
});

// dist/server/assets/__23tanstack-start-plugin-adapters-Cwee5PKy.js
var tanstack_start_plugin_adapters_Cwee5PKy_exports = {};
__export(tanstack_start_plugin_adapters_Cwee5PKy_exports, {
  hasPluginAdapters: () => hasPluginAdapters,
  pluginSerializationAdapters: () => pluginSerializationAdapters
});
var pluginSerializationAdapters, hasPluginAdapters;
var init_tanstack_start_plugin_adapters_Cwee5PKy = __esm({
  "dist/server/assets/__23tanstack-start-plugin-adapters-Cwee5PKy.js"() {
    "use strict";
    pluginSerializationAdapters = [];
    hasPluginAdapters = false;
  }
});

// dist/server/server.js
import { AsyncLocalStorage } from "node:async_hooks";
import { H3Event, toResponse } from "h3-v2";
import { rootRouteId, defaultSerovalPlugins, makeSerovalPlugin, createRawStreamRPCPlugin, invariant, isNotFound, isRedirect, resolveManifestAssetLink, createSerializationAdapter, isResolvedRedirect, executeRewriteInput } from "@tanstack/router-core";
import { toCrossJSONStream, fromJSON, toCrossJSONAsync } from "seroval";
import { createMemoryHistory } from "@tanstack/history";
import { mergeHeaders } from "@tanstack/router-core/ssr/client";
import { getNormalizedURL, getOrigin, attachRouterServerSsrUtils } from "@tanstack/router-core/ssr/server";
import "react";
import { RouterProvider } from "@tanstack/react-router";
import { jsx as jsx23 } from "react/jsx-runtime";
import { defineHandlerCallback, renderRouterToStream } from "@tanstack/react-router/ssr/server";
function StartServer(props) {
  return /* @__PURE__ */ jsx23(RouterProvider, { router: props.router });
}
var defaultStreamHandler = defineHandlerCallback(({ request, router: router2, responseHeaders }) => renderRouterToStream({
  request,
  router: router2,
  responseHeaders,
  children: /* @__PURE__ */ jsx23(StartServer, { router: router2 })
}));
var GLOBAL_EVENT_STORAGE_KEY = /* @__PURE__ */ Symbol.for("tanstack-start:event-storage");
var globalObj$1 = globalThis;
if (!globalObj$1[GLOBAL_EVENT_STORAGE_KEY]) globalObj$1[GLOBAL_EVENT_STORAGE_KEY] = new AsyncLocalStorage();
var eventStorage = globalObj$1[GLOBAL_EVENT_STORAGE_KEY];
function isPromiseLike(value) {
  return typeof value.then === "function";
}
function getSetCookieValues(headers) {
  const headersWithSetCookie = headers;
  if (typeof headersWithSetCookie.getSetCookie === "function") return headersWithSetCookie.getSetCookie();
  const value = headers.get("set-cookie");
  return value ? [value] : [];
}
function mergeEventResponseHeaders(response, event) {
  if (response.ok) return;
  const eventSetCookies = getSetCookieValues(event.res.headers);
  if (eventSetCookies.length === 0) return;
  const responseSetCookies = getSetCookieValues(response.headers);
  response.headers.delete("set-cookie");
  for (const cookie of responseSetCookies) response.headers.append("set-cookie", cookie);
  for (const cookie of eventSetCookies) response.headers.append("set-cookie", cookie);
}
function attachResponseHeaders(value, event) {
  if (isPromiseLike(value)) return value.then((resolved) => {
    if (resolved instanceof Response) mergeEventResponseHeaders(resolved, event);
    return resolved;
  });
  if (value instanceof Response) mergeEventResponseHeaders(value, event);
  return value;
}
function requestHandler(handler) {
  return (request, requestOpts) => {
    let h3Event;
    try {
      h3Event = new H3Event(request);
    } catch (error) {
      if (error instanceof URIError) return new Response(null, {
        status: 400,
        statusText: "Bad Request"
      });
      throw error;
    }
    return toResponse(attachResponseHeaders(eventStorage.run({ h3Event }, () => handler(request, requestOpts)), h3Event), h3Event);
  };
}
function getH3Event() {
  const event = eventStorage.getStore();
  if (!event) throw new Error(`No StartEvent found in AsyncLocalStorage. Make sure you are using the function within the server runtime.`);
  return event.h3Event;
}
function getResponse() {
  return getH3Event().res;
}
var HEADERS = { TSS_SHELL: "X-TSS_SHELL" };
async function getStartManifest(matchedRoutes) {
  const { tsrStartManifest: tsrStartManifest2 } = await Promise.resolve().then(() => (init_tanstack_start_manifest_v_D55eW8K9(), tanstack_start_manifest_v_D55eW8K9_exports));
  const startManifest = tsrStartManifest2();
  const rootRoute = startManifest.routes[rootRouteId] = startManifest.routes[rootRouteId] || {};
  rootRoute.assets = rootRoute.assets || [];
  let injectedHeadScripts;
  return {
    manifest: { routes: Object.fromEntries(Object.entries(startManifest.routes).flatMap(([k, v]) => {
      const result = {};
      let hasData = false;
      if (v.preloads && v.preloads.length > 0) {
        result["preloads"] = v.preloads;
        hasData = true;
      }
      if (v.assets && v.assets.length > 0) {
        result["assets"] = v.assets;
        hasData = true;
      }
      if (!hasData) return [];
      return [[k, result]];
    })) },
    clientEntry: startManifest.clientEntry,
    injectedHeadScripts
  };
}
var manifest = {};
async function getServerFnById(id, access) {
  const serverFnInfo = manifest[id];
  if (!serverFnInfo) {
    throw new Error("Server function info not found for " + id);
  }
  const fnModule = serverFnInfo.module ?? await serverFnInfo.importer();
  if (!fnModule) {
    throw new Error("Server function module not resolved for " + id);
  }
  const action = fnModule[serverFnInfo.functionName];
  if (!action) {
    throw new Error("Server function module export not resolved for serverFn ID: " + id);
  }
  return action;
}
var TSS_FORMDATA_CONTEXT = "__TSS_CONTEXT";
var TSS_SERVER_FUNCTION = /* @__PURE__ */ Symbol.for("TSS_SERVER_FUNCTION");
var X_TSS_SERIALIZED = "x-tss-serialized";
var X_TSS_RAW_RESPONSE = "x-tss-raw";
var TSS_CONTENT_TYPE_FRAMED = "application/x-tss-framed";
var FrameType = {
  JSON: 0,
  CHUNK: 1,
  END: 2,
  ERROR: 3
};
var FRAME_HEADER_SIZE = 9;
var TSS_CONTENT_TYPE_FRAMED_VERSIONED = `${TSS_CONTENT_TYPE_FRAMED}; v=1`;
function isSafeKey(key) {
  return key !== "__proto__" && key !== "constructor" && key !== "prototype";
}
function safeObjectMerge(target, source) {
  const result = /* @__PURE__ */ Object.create(null);
  if (target) {
    for (const key of Object.keys(target)) if (isSafeKey(key)) result[key] = target[key];
  }
  if (source && typeof source === "object") {
    for (const key of Object.keys(source)) if (isSafeKey(key)) result[key] = source[key];
  }
  return result;
}
function createNullProtoObject(source) {
  if (!source) return /* @__PURE__ */ Object.create(null);
  const obj = /* @__PURE__ */ Object.create(null);
  for (const key of Object.keys(source)) if (isSafeKey(key)) obj[key] = source[key];
  return obj;
}
var GLOBAL_STORAGE_KEY = /* @__PURE__ */ Symbol.for("tanstack-start:start-storage-context");
var globalObj = globalThis;
if (!globalObj[GLOBAL_STORAGE_KEY]) globalObj[GLOBAL_STORAGE_KEY] = new AsyncLocalStorage();
var startStorage = globalObj[GLOBAL_STORAGE_KEY];
async function runWithStartContext(context, fn) {
  return startStorage.run(context, fn);
}
function getStartContext(opts) {
  const context = startStorage.getStore();
  if (!context && opts?.throwIfNotFound !== false) throw new Error(`No Start context found in AsyncLocalStorage. Make sure you are using the function within the server runtime.`);
  return context;
}
var getStartOptions = () => getStartContext().startOptions;
function flattenMiddlewares(middlewares, maxDepth = 100) {
  const seen = /* @__PURE__ */ new Set();
  const flattened = [];
  const recurse = (middleware, depth) => {
    if (depth > maxDepth) throw new Error(`Middleware nesting depth exceeded maximum of ${maxDepth}. Check for circular references.`);
    middleware.forEach((m) => {
      if (m.options.middleware) recurse(m.options.middleware, depth + 1);
      if (!seen.has(m)) {
        seen.add(m);
        flattened.push(m);
      }
    });
  };
  recurse(middlewares, 0);
  return flattened;
}
function getDefaultSerovalPlugins() {
  return [...getStartOptions()?.serializationAdapters?.map(makeSerovalPlugin) ?? [], ...defaultSerovalPlugins];
}
var textEncoder = new TextEncoder();
var EMPTY_PAYLOAD = new Uint8Array(0);
function encodeFrame(type, streamId, payload) {
  const frame = new Uint8Array(FRAME_HEADER_SIZE + payload.length);
  frame[0] = type;
  frame[1] = streamId >>> 24 & 255;
  frame[2] = streamId >>> 16 & 255;
  frame[3] = streamId >>> 8 & 255;
  frame[4] = streamId & 255;
  frame[5] = payload.length >>> 24 & 255;
  frame[6] = payload.length >>> 16 & 255;
  frame[7] = payload.length >>> 8 & 255;
  frame[8] = payload.length & 255;
  frame.set(payload, FRAME_HEADER_SIZE);
  return frame;
}
function encodeJSONFrame(json) {
  return encodeFrame(FrameType.JSON, 0, textEncoder.encode(json));
}
function encodeChunkFrame(streamId, chunk) {
  return encodeFrame(FrameType.CHUNK, streamId, chunk);
}
function encodeEndFrame(streamId) {
  return encodeFrame(FrameType.END, streamId, EMPTY_PAYLOAD);
}
function encodeErrorFrame(streamId, error) {
  const message = error instanceof Error ? error.message : String(error ?? "Unknown error");
  return encodeFrame(FrameType.ERROR, streamId, textEncoder.encode(message));
}
function createMultiplexedStream(jsonStream, rawStreams, lateStreamSource) {
  let controller;
  let cancelled = false;
  const readers = [];
  const enqueue = (frame) => {
    if (cancelled) return false;
    try {
      controller.enqueue(frame);
      return true;
    } catch {
      return false;
    }
  };
  const errorOutput = (error) => {
    if (cancelled) return;
    cancelled = true;
    try {
      controller.error(error);
    } catch {
    }
    for (const reader of readers) reader.cancel().catch(() => {
    });
  };
  async function pumpRawStream(streamId, stream) {
    const reader = stream.getReader();
    readers.push(reader);
    try {
      while (!cancelled) {
        const { done, value } = await reader.read();
        if (done) {
          enqueue(encodeEndFrame(streamId));
          return;
        }
        if (!enqueue(encodeChunkFrame(streamId, value))) return;
      }
    } catch (error) {
      enqueue(encodeErrorFrame(streamId, error));
    } finally {
      reader.releaseLock();
    }
  }
  async function pumpJSON() {
    const reader = jsonStream.getReader();
    readers.push(reader);
    try {
      while (!cancelled) {
        const { done, value } = await reader.read();
        if (done) return;
        if (!enqueue(encodeJSONFrame(value))) return;
      }
    } catch (error) {
      errorOutput(error);
      throw error;
    } finally {
      reader.releaseLock();
    }
  }
  async function pumpLateStreams() {
    if (!lateStreamSource) return [];
    const lateStreamPumps = [];
    const reader = lateStreamSource.getReader();
    readers.push(reader);
    try {
      while (!cancelled) {
        const { done, value } = await reader.read();
        if (done) break;
        lateStreamPumps.push(pumpRawStream(value.id, value.stream));
      }
    } finally {
      reader.releaseLock();
    }
    return lateStreamPumps;
  }
  return new ReadableStream({
    async start(ctrl) {
      controller = ctrl;
      const pumps = [pumpJSON()];
      for (const [streamId, stream] of rawStreams) pumps.push(pumpRawStream(streamId, stream));
      if (lateStreamSource) pumps.push(pumpLateStreams());
      try {
        const latePumps = (await Promise.all(pumps)).find(Array.isArray);
        if (latePumps && latePumps.length > 0) await Promise.all(latePumps);
        if (!cancelled) try {
          controller.close();
        } catch {
        }
      } catch {
      }
    },
    cancel() {
      cancelled = true;
      for (const reader of readers) reader.cancel().catch(() => {
      });
      readers.length = 0;
    }
  });
}
var serovalPlugins = void 0;
var FORM_DATA_CONTENT_TYPES = ["multipart/form-data", "application/x-www-form-urlencoded"];
var MAX_PAYLOAD_SIZE = 1e6;
var handleServerAction = async ({ request, context, serverFnId }) => {
  const methodUpper = request.method.toUpperCase();
  const url = new URL(request.url);
  const action = await getServerFnById(serverFnId);
  if (action.method && methodUpper !== action.method) return new Response(`expected ${action.method} method. Got ${methodUpper}`, {
    status: 405,
    headers: { Allow: action.method }
  });
  const isServerFn = request.headers.get("x-tsr-serverFn") === "true";
  if (!serovalPlugins) serovalPlugins = getDefaultSerovalPlugins();
  const contentType = request.headers.get("Content-Type");
  function parsePayload(payload) {
    return fromJSON(payload, { plugins: serovalPlugins });
  }
  return await (async () => {
    try {
      let serializeResult = function(res2) {
        let nonStreamingBody = void 0;
        const alsResponse = getResponse();
        if (res2 !== void 0) {
          const rawStreams = /* @__PURE__ */ new Map();
          let initialPhase = true;
          let lateStreamWriter;
          let lateStreamReadable = void 0;
          const pendingLateStreams = [];
          const plugins = [createRawStreamRPCPlugin((id, stream) => {
            if (initialPhase) {
              rawStreams.set(id, stream);
              return;
            }
            if (lateStreamWriter) {
              lateStreamWriter.write({
                id,
                stream
              }).catch(() => {
              });
              return;
            }
            pendingLateStreams.push({
              id,
              stream
            });
          }), ...serovalPlugins || []];
          let done = false;
          const callbacks = {
            onParse: (value) => {
              nonStreamingBody = value;
            },
            onDone: () => {
              done = true;
            },
            onError: (error) => {
              throw error;
            }
          };
          toCrossJSONStream(res2, {
            refs: /* @__PURE__ */ new Map(),
            plugins,
            onParse(value) {
              callbacks.onParse(value);
            },
            onDone() {
              callbacks.onDone();
            },
            onError: (error) => {
              callbacks.onError(error);
            }
          });
          initialPhase = false;
          if (done && rawStreams.size === 0) return new Response(nonStreamingBody ? JSON.stringify(nonStreamingBody) : void 0, {
            status: alsResponse.status,
            statusText: alsResponse.statusText,
            headers: {
              "Content-Type": "application/json",
              [X_TSS_SERIALIZED]: "true"
            }
          });
          const { readable, writable } = new TransformStream();
          lateStreamReadable = readable;
          lateStreamWriter = writable.getWriter();
          for (const registration of pendingLateStreams) lateStreamWriter.write(registration).catch(() => {
          });
          pendingLateStreams.length = 0;
          const multiplexedStream = createMultiplexedStream(new ReadableStream({
            start(controller) {
              callbacks.onParse = (value) => {
                controller.enqueue(JSON.stringify(value) + "\n");
              };
              callbacks.onDone = () => {
                try {
                  controller.close();
                } catch {
                }
                lateStreamWriter?.close().catch(() => {
                }).finally(() => {
                  lateStreamWriter = void 0;
                });
              };
              callbacks.onError = (error) => {
                controller.error(error);
                lateStreamWriter?.abort(error).catch(() => {
                }).finally(() => {
                  lateStreamWriter = void 0;
                });
              };
              if (nonStreamingBody !== void 0) callbacks.onParse(nonStreamingBody);
              if (done) callbacks.onDone();
            },
            cancel() {
              lateStreamWriter?.abort().catch(() => {
              });
              lateStreamWriter = void 0;
            }
          }), rawStreams, lateStreamReadable);
          return new Response(multiplexedStream, {
            status: alsResponse.status,
            statusText: alsResponse.statusText,
            headers: {
              "Content-Type": TSS_CONTENT_TYPE_FRAMED_VERSIONED,
              [X_TSS_SERIALIZED]: "true"
            }
          });
        }
        return new Response(void 0, {
          status: alsResponse.status,
          statusText: alsResponse.statusText
        });
      };
      let res = await (async () => {
        if (FORM_DATA_CONTENT_TYPES.some((type) => contentType && contentType.includes(type))) {
          if (methodUpper === "GET") {
            if (false) ;
            invariant();
          }
          const formData = await request.formData();
          const serializedContext = formData.get(TSS_FORMDATA_CONTEXT);
          formData.delete(TSS_FORMDATA_CONTEXT);
          const params = {
            context,
            data: formData,
            method: methodUpper
          };
          if (typeof serializedContext === "string") try {
            const deserializedContext = fromJSON(JSON.parse(serializedContext), { plugins: serovalPlugins });
            if (typeof deserializedContext === "object" && deserializedContext) params.context = safeObjectMerge(deserializedContext, context);
          } catch (e) {
            if (false) ;
          }
          return await action(params);
        }
        if (methodUpper === "GET") {
          const payloadParam = url.searchParams.get("payload");
          if (payloadParam && payloadParam.length > MAX_PAYLOAD_SIZE) throw new Error("Payload too large");
          const payload2 = payloadParam ? parsePayload(JSON.parse(payloadParam)) : {};
          payload2.context = safeObjectMerge(payload2.context, context);
          payload2.method = methodUpper;
          return await action(payload2);
        }
        let jsonPayload;
        if (contentType?.includes("application/json")) jsonPayload = await request.json();
        const payload = jsonPayload ? parsePayload(jsonPayload) : {};
        payload.context = safeObjectMerge(payload.context, context);
        payload.method = methodUpper;
        return await action(payload);
      })();
      const unwrapped = res.result || res.error;
      if (isNotFound(res)) res = isNotFoundResponse(res);
      if (!isServerFn) return unwrapped;
      if (unwrapped instanceof Response) {
        if (isRedirect(unwrapped)) return unwrapped;
        unwrapped.headers.set(X_TSS_RAW_RESPONSE, "true");
        return unwrapped;
      }
      return serializeResult(res);
    } catch (error) {
      if (error instanceof Response) return error;
      if (isNotFound(error)) return isNotFoundResponse(error);
      console.info();
      console.info("Server Fn Error!");
      console.info();
      console.error(error);
      console.info();
      const serializedError = JSON.stringify(await Promise.resolve(toCrossJSONAsync(error, {
        refs: /* @__PURE__ */ new Map(),
        plugins: serovalPlugins
      })));
      const response = getResponse();
      return new Response(serializedError, {
        status: response.status ?? 500,
        statusText: response.statusText,
        headers: {
          "Content-Type": "application/json",
          [X_TSS_SERIALIZED]: "true"
        }
      });
    }
  })();
};
function isNotFoundResponse(error) {
  const { headers, ...rest } = error;
  return new Response(JSON.stringify(rest), {
    status: 404,
    headers: {
      "Content-Type": "application/json",
      ...headers || {}
    }
  });
}
function normalizeTransformAssetResult(result) {
  if (typeof result === "string") return { href: result };
  return result;
}
function resolveTransformAssetsCrossOrigin(config2, kind) {
  if (!config2) return void 0;
  if (typeof config2 === "string") return config2;
  return config2[kind];
}
function isObjectShorthand(transform) {
  return "prefix" in transform;
}
function resolveTransformAssetsConfig(transform) {
  if (typeof transform === "string") {
    const prefix = transform;
    return {
      type: "transform",
      transformFn: ({ url }) => ({ href: `${prefix}${url}` }),
      cache: true
    };
  }
  if (typeof transform === "function") return {
    type: "transform",
    transformFn: transform,
    cache: true
  };
  if (isObjectShorthand(transform)) {
    const { prefix, crossOrigin } = transform;
    return {
      type: "transform",
      transformFn: ({ url, kind }) => {
        const href = `${prefix}${url}`;
        if (kind === "clientEntry") return { href };
        const co = resolveTransformAssetsCrossOrigin(crossOrigin, kind);
        return co ? {
          href,
          crossOrigin: co
        } : { href };
      },
      cache: true
    };
  }
  if ("createTransform" in transform && transform.createTransform) return {
    type: "createTransform",
    createTransform: transform.createTransform,
    cache: transform.cache !== false
  };
  return {
    type: "transform",
    transformFn: typeof transform.transform === "string" ? (({ url }) => ({ href: `${transform.transform}${url}` })) : transform.transform,
    cache: transform.cache !== false
  };
}
function adaptTransformAssetUrlsToTransformAssets(transformFn) {
  return async ({ url, kind }) => ({ href: await transformFn({
    url,
    type: kind
  }) });
}
function adaptTransformAssetUrlsConfigToTransformAssets(transform) {
  if (typeof transform === "string") return transform;
  if (typeof transform === "function") return adaptTransformAssetUrlsToTransformAssets(transform);
  if ("createTransform" in transform && transform.createTransform) return {
    createTransform: async (ctx) => adaptTransformAssetUrlsToTransformAssets(await transform.createTransform(ctx)),
    cache: transform.cache,
    warmup: transform.warmup
  };
  return {
    transform: typeof transform.transform === "string" ? transform.transform : adaptTransformAssetUrlsToTransformAssets(transform.transform),
    cache: transform.cache,
    warmup: transform.warmup
  };
}
function buildClientEntryScriptTag(clientEntry, injectedHeadScripts) {
  let script = `import(${JSON.stringify(clientEntry)})`;
  if (injectedHeadScripts) script = `${injectedHeadScripts};${script}`;
  return {
    tag: "script",
    attrs: {
      type: "module",
      async: true
    },
    children: script
  };
}
function assignManifestAssetLink(link, next) {
  if (typeof link === "string") return next.crossOrigin ? next : next.href;
  return next.crossOrigin ? next : { href: next.href };
}
async function transformManifestAssets(source, transformFn, _opts) {
  const manifest2 = structuredClone(source.manifest);
  for (const route of Object.values(manifest2.routes)) {
    if (route.preloads) route.preloads = await Promise.all(route.preloads.map(async (link) => {
      const result = normalizeTransformAssetResult(await transformFn({
        url: resolveManifestAssetLink(link).href,
        kind: "modulepreload"
      }));
      return assignManifestAssetLink(link, {
        href: result.href,
        crossOrigin: result.crossOrigin
      });
    }));
    if (route.assets) {
      for (const asset of route.assets) if (asset.tag === "link" && asset.attrs?.href) {
        const rel = asset.attrs.rel;
        if (!(typeof rel === "string" ? rel.split(/\s+/) : []).includes("stylesheet")) continue;
        const result = normalizeTransformAssetResult(await transformFn({
          url: asset.attrs.href,
          kind: "stylesheet"
        }));
        asset.attrs.href = result.href;
        if (result.crossOrigin) asset.attrs.crossOrigin = result.crossOrigin;
        else delete asset.attrs.crossOrigin;
      }
    }
  }
  const transformedClientEntry = normalizeTransformAssetResult(await transformFn({
    url: source.clientEntry,
    kind: "clientEntry"
  }));
  const rootRoute = manifest2.routes[rootRouteId] = manifest2.routes[rootRouteId] || {};
  rootRoute.assets = rootRoute.assets || [];
  rootRoute.assets.push(buildClientEntryScriptTag(transformedClientEntry.href, source.injectedHeadScripts));
  return manifest2;
}
function buildManifestWithClientEntry(source) {
  const scriptTag = buildClientEntryScriptTag(source.clientEntry, source.injectedHeadScripts);
  const baseRootRoute = source.manifest.routes[rootRouteId];
  return { routes: {
    ...source.manifest.routes,
    [rootRouteId]: {
      ...baseRootRoute,
      assets: [...baseRootRoute?.assets || [], scriptTag]
    }
  } };
}
var ServerFunctionSerializationAdapter = createSerializationAdapter({
  key: "$TSS/serverfn",
  test: (v) => {
    if (typeof v !== "function") return false;
    if (!(TSS_SERVER_FUNCTION in v)) return false;
    return !!v[TSS_SERVER_FUNCTION];
  },
  toSerializable: ({ serverFnMeta }) => ({ functionId: serverFnMeta.id }),
  fromSerializable: ({ functionId }) => {
    const fn = async (opts, signal) => {
      return (await (await getServerFnById(functionId))(opts ?? {}, signal)).result;
    };
    return fn;
  }
});
function getStartResponseHeaders(opts) {
  return mergeHeaders({ "Content-Type": "text/html; charset=utf-8" }, ...opts.router.stores.matches.get().map((match) => {
    return match.headers;
  }));
}
var entriesPromise;
var baseManifestPromise;
var cachedFinalManifestPromise;
async function loadEntries() {
  const [routerEntry, startEntry, pluginAdapters] = await Promise.all([
    Promise.resolve().then(() => (init_router_B40ruYtd(), router_B40ruYtd_exports)).then((n) => n.c),
    Promise.resolve().then(() => (init_start_HYkvq4Ni(), start_HYkvq4Ni_exports)),
    Promise.resolve().then(() => (init_tanstack_start_plugin_adapters_Cwee5PKy(), tanstack_start_plugin_adapters_Cwee5PKy_exports))
  ]);
  return {
    routerEntry,
    startEntry,
    pluginAdapters
  };
}
function getEntries() {
  if (!entriesPromise) entriesPromise = loadEntries();
  return entriesPromise;
}
function getBaseManifest(matchedRoutes) {
  if (!baseManifestPromise) baseManifestPromise = getStartManifest();
  return baseManifestPromise;
}
async function resolveManifest(matchedRoutes, transformFn, cache) {
  const base = await getBaseManifest();
  const computeFinalManifest = async () => {
    return transformFn ? await transformManifestAssets(base, transformFn) : buildManifestWithClientEntry(base);
  };
  if (!transformFn || cache) {
    if (!cachedFinalManifestPromise) cachedFinalManifestPromise = computeFinalManifest();
    return cachedFinalManifestPromise;
  }
  return computeFinalManifest();
}
var ROUTER_BASEPATH = "/";
var SERVER_FN_BASE = "/_serverFn/";
var IS_PRERENDERING = process.env.TSS_PRERENDERING === "true";
var IS_SHELL_ENV = process.env.TSS_SHELL === "true";
var ERR_NO_RESPONSE = "Internal Server Error";
var ERR_NO_DEFER = "Internal Server Error";
function throwRouteHandlerError() {
  throw new Error(ERR_NO_RESPONSE);
}
function throwIfMayNotDefer() {
  throw new Error(ERR_NO_DEFER);
}
function isSpecialResponse(value) {
  return value instanceof Response || isRedirect(value);
}
function handleCtxResult(result) {
  if (isSpecialResponse(result)) return { response: result };
  return result;
}
function executeMiddleware(middlewares, ctx) {
  let index = -1;
  const next = async (nextCtx) => {
    if (nextCtx) {
      if (nextCtx.context) ctx.context = safeObjectMerge(ctx.context, nextCtx.context);
      for (const key of Object.keys(nextCtx)) if (key !== "context") ctx[key] = nextCtx[key];
    }
    index++;
    const middleware = middlewares[index];
    if (!middleware) return ctx;
    let result;
    try {
      result = await middleware({
        ...ctx,
        next
      });
    } catch (err) {
      if (isSpecialResponse(err)) {
        ctx.response = err;
        return ctx;
      }
      throw err;
    }
    const normalized = handleCtxResult(result);
    if (normalized) {
      if (normalized.response !== void 0) ctx.response = normalized.response;
      if (normalized.context) ctx.context = safeObjectMerge(ctx.context, normalized.context);
    }
    return ctx;
  };
  return next();
}
function handlerToMiddleware(handler, mayDefer = false) {
  if (mayDefer) return handler;
  return async (ctx) => {
    const response = await handler({
      ...ctx,
      next: throwIfMayNotDefer
    });
    if (!response) throwRouteHandlerError();
    return response;
  };
}
function createStartHandler(cbOrOptions) {
  const cb = typeof cbOrOptions === "function" ? cbOrOptions : cbOrOptions.handler;
  const transformAssetsOption = typeof cbOrOptions === "function" ? void 0 : cbOrOptions.transformAssets;
  const transformAssetUrlsOption = typeof cbOrOptions === "function" ? void 0 : cbOrOptions.transformAssetUrls;
  const transformOption = transformAssetsOption !== void 0 ? resolveTransformAssetsConfig(transformAssetsOption) : transformAssetUrlsOption !== void 0 ? resolveTransformAssetsConfig(adaptTransformAssetUrlsConfigToTransformAssets(transformAssetUrlsOption)) : void 0;
  const warmupTransformManifest = !!transformAssetsOption && typeof transformAssetsOption === "object" && "warmup" in transformAssetsOption && transformAssetsOption.warmup === true || !!transformAssetUrlsOption && typeof transformAssetUrlsOption === "object" && transformAssetUrlsOption.warmup === true;
  const resolvedTransformConfig = transformOption;
  const cache = resolvedTransformConfig ? resolvedTransformConfig.cache : true;
  const shouldCacheCreateTransform = cache && true;
  let cachedCreateTransformPromise;
  const getTransformFn = async (opts) => {
    if (!resolvedTransformConfig) return void 0;
    if (resolvedTransformConfig.type === "createTransform") {
      if (shouldCacheCreateTransform) {
        if (!cachedCreateTransformPromise) cachedCreateTransformPromise = Promise.resolve(resolvedTransformConfig.createTransform(opts)).catch((error) => {
          cachedCreateTransformPromise = void 0;
          throw error;
        });
        return cachedCreateTransformPromise;
      }
      return resolvedTransformConfig.createTransform(opts);
    }
    return resolvedTransformConfig.transformFn;
  };
  if (warmupTransformManifest && cache && true && !cachedFinalManifestPromise) {
    const warmupPromise = (async () => {
      const base = await getBaseManifest();
      const transformFn = await getTransformFn({ warmup: true });
      return transformFn ? await transformManifestAssets(base, transformFn) : buildManifestWithClientEntry(base);
    })();
    cachedFinalManifestPromise = warmupPromise;
    warmupPromise.catch(() => {
      if (cachedFinalManifestPromise === warmupPromise) cachedFinalManifestPromise = void 0;
      cachedCreateTransformPromise = void 0;
    });
  }
  const startRequestResolver = async (request, requestOpts) => {
    let router2 = null;
    let cbWillCleanup = false;
    try {
      const { url, handledProtocolRelativeURL } = getNormalizedURL(request.url);
      const href = url.pathname + url.search + url.hash;
      const origin = getOrigin(request);
      if (handledProtocolRelativeURL) return Response.redirect(url, 308);
      const entries = await getEntries();
      const startOptions = await entries.startEntry.startInstance?.getOptions() || {};
      const { hasPluginAdapters: hasPluginAdapters2, pluginSerializationAdapters: pluginSerializationAdapters2 } = entries.pluginAdapters;
      const serializationAdapters = [
        ...startOptions.serializationAdapters || [],
        ...hasPluginAdapters2 ? pluginSerializationAdapters2 : [],
        ServerFunctionSerializationAdapter
      ];
      const requestStartOptions = {
        ...startOptions,
        serializationAdapters
      };
      const flattenedRequestMiddlewares = startOptions.requestMiddleware ? flattenMiddlewares(startOptions.requestMiddleware) : [];
      const executedRequestMiddlewares = new Set(flattenedRequestMiddlewares);
      const getRouter2 = async () => {
        if (router2) return router2;
        router2 = await entries.routerEntry.getRouter();
        let isShell = IS_SHELL_ENV;
        if (IS_PRERENDERING && !isShell) isShell = request.headers.get(HEADERS.TSS_SHELL) === "true";
        const history = createMemoryHistory({ initialEntries: [href] });
        router2.update({
          history,
          isShell,
          isPrerendering: IS_PRERENDERING,
          origin: router2.options.origin ?? origin,
          defaultSsr: requestStartOptions.defaultSsr,
          serializationAdapters: [...requestStartOptions.serializationAdapters, ...router2.options.serializationAdapters || []],
          basepath: ROUTER_BASEPATH
        });
        return router2;
      };
      if (SERVER_FN_BASE && url.pathname.startsWith(SERVER_FN_BASE)) {
        const serverFnId = url.pathname.slice(SERVER_FN_BASE.length).split("/")[0];
        if (!serverFnId) throw new Error("Invalid server action param for serverFnId");
        const serverFnHandler = async ({ context }) => {
          return runWithStartContext({
            getRouter: getRouter2,
            startOptions: requestStartOptions,
            contextAfterGlobalMiddlewares: context,
            request,
            executedRequestMiddlewares,
            handlerType: "serverFn"
          }, () => handleServerAction({
            request,
            context: requestOpts?.context,
            serverFnId
          }));
        };
        return handleRedirectResponse((await executeMiddleware([...flattenedRequestMiddlewares.map((d) => d.options.server), serverFnHandler], {
          request,
          pathname: url.pathname,
          context: createNullProtoObject(requestOpts?.context)
        })).response, request, getRouter2);
      }
      const executeRouter = async (serverContext, matchedRoutes) => {
        const acceptParts = (request.headers.get("Accept") || "*/*").split(",");
        if (!["*/*", "text/html"].some((mimeType) => acceptParts.some((part) => part.trim().startsWith(mimeType)))) return Response.json({ error: "Only HTML requests are supported here" }, { status: 500 });
        const manifest2 = await resolveManifest(matchedRoutes, await getTransformFn({
          warmup: false,
          request
        }), cache);
        const routerInstance = await getRouter2();
        attachRouterServerSsrUtils({
          router: routerInstance,
          manifest: manifest2,
          getRequestAssets: () => getStartContext({ throwIfNotFound: false })?.requestAssets,
          includeUnmatchedRouteAssets: false
        });
        routerInstance.update({ additionalContext: { serverContext } });
        await routerInstance.load();
        if (routerInstance.state.redirect) return routerInstance.state.redirect;
        const ctx = getStartContext({ throwIfNotFound: false });
        await routerInstance.serverSsr.dehydrate({ requestAssets: ctx?.requestAssets });
        const responseHeaders = getStartResponseHeaders({ router: routerInstance });
        cbWillCleanup = true;
        return cb({
          request,
          router: routerInstance,
          responseHeaders
        });
      };
      const requestHandlerMiddleware = async ({ context }) => {
        return runWithStartContext({
          getRouter: getRouter2,
          startOptions: requestStartOptions,
          contextAfterGlobalMiddlewares: context,
          request,
          executedRequestMiddlewares,
          handlerType: "router"
        }, async () => {
          try {
            return await handleServerRoutes({
              getRouter: getRouter2,
              request,
              url,
              executeRouter,
              context,
              executedRequestMiddlewares
            });
          } catch (err) {
            if (err instanceof Response) return err;
            throw err;
          }
        });
      };
      return handleRedirectResponse((await executeMiddleware([...flattenedRequestMiddlewares.map((d) => d.options.server), requestHandlerMiddleware], {
        request,
        pathname: url.pathname,
        context: createNullProtoObject(requestOpts?.context)
      })).response, request, getRouter2);
    } finally {
      if (router2 && !cbWillCleanup) router2.serverSsr?.cleanup();
      router2 = null;
    }
  };
  return requestHandler(startRequestResolver);
}
async function handleRedirectResponse(response, request, getRouter2) {
  if (!isRedirect(response)) return response;
  if (isResolvedRedirect(response)) {
    if (request.headers.get("x-tsr-serverFn") === "true") return Response.json({
      ...response.options,
      isSerializedRedirect: true
    }, { headers: response.headers });
    return response;
  }
  const opts = response.options;
  if (opts.to && typeof opts.to === "string" && !opts.to.startsWith("/")) throw new Error(`Server side redirects must use absolute paths via the 'href' or 'to' options. The redirect() method's "to" property accepts an internal path only. Use the "href" property to provide an external URL. Received: ${JSON.stringify(opts)}`);
  if ([
    "params",
    "search",
    "hash"
  ].some((d) => typeof opts[d] === "function")) throw new Error(`Server side redirects must use static search, params, and hash values and do not support functional values. Received functional values for: ${Object.keys(opts).filter((d) => typeof opts[d] === "function").map((d) => `"${d}"`).join(", ")}`);
  const redirect2 = (await getRouter2()).resolveRedirect(response);
  if (request.headers.get("x-tsr-serverFn") === "true") return Response.json({
    ...response.options,
    isSerializedRedirect: true
  }, { headers: response.headers });
  return redirect2;
}
async function handleServerRoutes({ getRouter: getRouter2, request, url, executeRouter, context, executedRequestMiddlewares }) {
  const router2 = await getRouter2();
  const pathname = executeRewriteInput(router2.rewrite, url).pathname;
  const { matchedRoutes, foundRoute, routeParams } = router2.getMatchedRoutes(pathname);
  const isExactMatch = foundRoute && routeParams["**"] === void 0;
  const routeMiddlewares = [];
  for (const route of matchedRoutes) {
    const serverMiddleware = route.options.server?.middleware;
    if (serverMiddleware) {
      const flattened = flattenMiddlewares(serverMiddleware);
      for (const m of flattened) if (!executedRequestMiddlewares.has(m)) routeMiddlewares.push(m.options.server);
    }
  }
  const server2 = foundRoute?.options.server;
  if (server2?.handlers && isExactMatch) {
    const handlers = typeof server2.handlers === "function" ? server2.handlers({ createHandlers: (d) => d }) : server2.handlers;
    const handler = handlers[request.method.toUpperCase()] ?? handlers["ANY"];
    if (handler) {
      const mayDefer = !!foundRoute.options.component;
      if (typeof handler === "function") routeMiddlewares.push(handlerToMiddleware(handler, mayDefer));
      else {
        if (handler.middleware?.length) {
          const handlerMiddlewares = flattenMiddlewares(handler.middleware);
          for (const m of handlerMiddlewares) routeMiddlewares.push(m.options.server);
        }
        if (handler.handler) routeMiddlewares.push(handlerToMiddleware(handler.handler, mayDefer));
      }
    }
  }
  routeMiddlewares.push((ctx) => executeRouter(ctx.context, matchedRoutes));
  return (await executeMiddleware(routeMiddlewares, {
    request,
    context,
    params: routeParams,
    pathname
  })).response;
}
var fetch2 = createStartHandler(defaultStreamHandler);
function createServerEntry(entry) {
  return {
    async fetch(...args) {
      return await entry.fetch(...args);
    }
  };
}
var server = createServerEntry({ fetch: fetch2 });

// netlify/functions/server.mjs
var server_default = async (request, context) => {
  return await server(request);
};
var config = {
  path: "/*"
};
export {
  config,
  server_default as default
};
